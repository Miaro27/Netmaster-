package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.preferences.UserPreferencesRepository
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context and verify bilingual FR and EN resources`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("NetMaster", appName)

        val frContext = UserPreferencesRepository.createLocalizedContext(context, "fr")
        val enContext = UserPreferencesRepository.createLocalizedContext(context, "en")

        assertEquals("Cours", frContext.getString(R.string.courses))
        assertEquals("Courses", enContext.getString(R.string.courses))
        assertEquals("Outils", frContext.getString(R.string.tools))
        assertEquals("Tools", enContext.getString(R.string.tools))
    }
}
