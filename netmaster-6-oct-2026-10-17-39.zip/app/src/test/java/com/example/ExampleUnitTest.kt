package com.example

import com.example.data.seed.CurriculumSeedData
import com.example.domain.NetworkCalculators
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun subnetCalculator_verifies192_168_1_10_slash24() {
        val res = NetworkCalculators.calculateSubnet("192.168.1.10", 24, "en")
        assertTrue(res.isValid)
        assertEquals("192.168.1.0", res.networkAddress)
        assertEquals("192.168.1.255", res.broadcastAddress)
        assertEquals("192.168.1.1", res.firstHost)
        assertEquals("192.168.1.254", res.lastHost)
        assertEquals(254L, res.usableHosts)
        assertEquals("255.255.255.0", res.subnetMaskDec)
        assertEquals("0.0.0.255", res.wildcardMaskDec)
    }

    @Test
    fun curriculumSeedData_hasAll13BilingualModulesAnd65Quizzes() {
        assertEquals(13, CurriculumSeedData.allModules.size)
        assertEquals(65, CurriculumSeedData.allQuizQuestions.size)
        CurriculumSeedData.allModules.forEach { mod ->
            assertTrue(mod.titleFr.isNotBlank())
            assertTrue(mod.titleEn.isNotBlank())
            val modQuizzes = CurriculumSeedData.allQuizQuestions.filter { it.moduleId == mod.id }
            assertEquals(5, modQuizzes.size)
        }
    }
}
