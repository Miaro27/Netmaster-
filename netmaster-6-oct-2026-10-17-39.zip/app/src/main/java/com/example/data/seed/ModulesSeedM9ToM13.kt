package com.example.data.seed

import com.example.data.local.LessonEntity
import com.example.data.local.ModuleEntity
import com.example.data.local.QuizQuestionEntity

object ModulesSeedM9ToM13 {

    val modules = listOf(
        ModuleEntity(
            id = 9,
            number = 9,
            level = 2,
            iconType = "SWITCHING_STP",
            titleFr = "Commutation, STP, EtherChannel & Port Security",
            titleEn = "Switching, STP, EtherChannel & Port Security",
            descriptionFr = "Table MAC (CAM), Spanning Tree (802.1D, RSTP, PVST+), EtherChannel (LACP/PAgP), Port Security et Storm Control.",
            descriptionEn = "MAC (CAM) table, Spanning Tree (802.1D, RSTP, PVST+), EtherChannel (LACP/PAgP), Port Security, and Storm Control."
        ),
        ModuleEntity(
            id = 10,
            number = 10,
            level = 3,
            iconType = "SECURITY_SHIELD",
            titleFr = "Sécurité Réseau, ACL, VPN & Pare-feu",
            titleEn = "Network Security, ACLs, VPN & Firewalls",
            descriptionFr = "ACL standard/étendue, pare-feu, VPN (IPsec/TLS), SSH, AAA (RADIUS/TACACS+) et attaques (MITM, DoS, Spoofing).",
            descriptionEn = "Standard/Extended ACLs, Firewalls, VPN (Site-to-Site/Remote), SSH, AAA, and attacks (MITM, DoS, ARP/DHCP Spoofing)."
        ),
        ModuleEntity(
            id = 11,
            number = 11,
            level = 2,
            iconType = "WIRELESS_WIFI",
            titleFr = "Réseaux Sans-Fil Wi-Fi (802.11) & WPA3",
            titleEn = "Wireless Networks (802.11) & WPA3 Security",
            descriptionFr = "Normes 802.11 a/b/g/n/ac/ax (Wi-Fi 6), SSID/BSSID, canaux 2.4 & 5 GHz, sécurité WEP/WPA/WPA2/WPA3 et configuration AP.",
            descriptionEn = "802.11 a/b/g/n/ac/ax (Wi-Fi 6) standards, SSID/BSSID, 2.4/5 GHz channels, WEP/WPA/WPA2/WPA3 security, and AP setup."
        ),
        ModuleEntity(
            id = 12,
            number = 12,
            level = 2,
            iconType = "NETWORK_SERVICES",
            titleFr = "Services Réseau : DNS, DHCP, NAT, NTP, SNMP & QoS",
            titleEn = "Network Services: DNS, DHCP, NAT, NTP, SNMP & QoS",
            descriptionFr = "Enregistrements DNS (A, AAAA, MX, CNAME), cycle DHCP DORA, NAT/PAT, NTP, Syslog, SNMP et bases de la QoS.",
            descriptionEn = "DNS records (A, AAAA, MX, CNAME), DHCP DORA process, Static/Dynamic NAT & PAT, NTP, Syslog, SNMP, and QoS basics."
        ),
        ModuleEntity(
            id = 13,
            number = 13,
            level = 3,
            iconType = "CLOUD_SDN",
            titleFr = "Cloud Computing, SDN, NFV & Conteneurs",
            titleEn = "Cloud Computing, SDN, NFV & Virtualization",
            descriptionFr = "Modèles Cloud (IaaS, PaaS, SaaS), SDN (plan de contrôle vs données), NFV et Conteneurs (Docker/K8s) vs Machines Virtuelles.",
            descriptionEn = "Cloud service models (IaaS, PaaS, SaaS), SDN (Control vs Data plane), NFV, and Containers vs Virtual Machines (VMs)."
        )
    )

    val lessons = listOf(
        // MODULE 9 LESSON
        LessonEntity(
            id = 901,
            moduleId = 9,
            orderIndex = 1,
            titleFr = "1. Table CAM, STP (802.1D/RSTP/PVST+), EtherChannel & Port Security",
            titleEn = "1. CAM Table, STP (802.1D/RSTP/PVST+), EtherChannel & Port Security",
            contentFr = """
• Fonctionnement d'un Switch & Table MAC (CAM) :
1. Apprentissage (Learn) : Lit l'adresse MAC SOURCE de chaque trame entrante et l'associe au port dans sa table CAM (durée de vie par défaut : 300 s).
2. Diffusion (Flood) : Si la MAC DESTINATION est inconnue ou est un broadcast (`FF:FF:FF:FF:FF:FF`), envoie sur tous les ports du VLAN sauf celui d'entrée.
3. Transfert (Forward) : Si la MAC destination est connue dans la table CAM, commute la trame uniquement vers le port cible.

• STP (Spanning Tree Protocol) — Élimination des boucles de couche 2 :
Les boucles physiques entre switches provoquent des tempêtes de broadcast. STP bloque logiquement les liens redondants :
- Élit un **Root Bridge** (switch ayant le plus petit Bridge ID = Priorité [32768 par défaut] + MAC).
- Versions : **802.1D** (STP classique, convergence 30–50 s), **802.1w RSTP** (Rapid STP, convergence < 2 s), **PVST+ / Rapid-PVST+** (Cisco : une instance STP par VLAN).

• EtherChannel (Agrégation de liens — LACP vs PAgP) :
Regroupe 2 à 8 liens physiques en un seul lien logique `Port-channel` pour augmenter la bande passante et la redondance :
- **LACP (IEEE 802.3ad — Standard ouvert)** : Modes `Active` / `Passive`.
- **PAgP (Propriétaire Cisco)** : Modes `Desirable` / `Auto`.

• Port Security & Storm Control :
- **Port Security** : Limite le nombre d'adresses MAC autorisées sur un port Access (`switchport port-security mac-address sticky`). Modes de violation : `Protect`, `Restrict`, `Shutdown` (err-disabled par défaut).
- **Storm Control** : Surveille et limite le débit des tempêtes de Broadcast, Multicast ou Unicast inconnu.
            """.trimIndent(),
            contentEn = """
• How a Switch Works & MAC (CAM) Table:
1. Learn: Inspects the SOURCE MAC address of incoming frames and records the port in the CAM table (default aging: 300s).
2. Flood: If the DESTINATION MAC is unknown or a broadcast (`FF:FF:FF:FF:FF:FF`), floods out all ports in the VLAN except the ingress port.
3. Forward: If the destination MAC is found in the CAM table, forwards exclusively out that single interface.

• Spanning Tree Protocol (STP) — Loop Prevention:
Redundant Layer 2 links cause broadcast storms and MAC table instability. STP blocks redundant paths logically:
- Elects a **Root Bridge** (lowest Bridge ID = Priority [default 32768] + MAC address).
- Variants: **802.1D** (Classic STP, 30–50s convergence), **802.1w RSTP** (Rapid STP, sub-second convergence), **PVST+ / Rapid-PVST+** (Cisco per-VLAN STP instance).

• EtherChannel (Link Aggregation — LACP vs PAgP):
Bundles 2 to 8 physical links into one logical `Port-channel` interface:
- **LACP (IEEE 802.3ad — Open Standard)**: Uses `Active` and `Passive` modes.
- **PAgP (Cisco Proprietary)**: Uses `Desirable` and `Auto` modes.

• Port Security & Storm Control:
- **Port Security**: Restricts which MAC addresses can use an access port (`sticky` learning). Violation actions: `Protect`, `Restrict`, `Shutdown` (default puts port in `err-disabled`).
- **Storm Control**: Throttles excessive Broadcast, Multicast, or Unknown Unicast traffic spikes.
            """.trimIndent(),
            diagramType = "STP_ETHERCHANNEL",
            commandsBlock = "Switch(config)# spanning-tree mode rapid-pvst\nSwitch(config)# interface range g0/1 - 2\nSwitch(config-if-range)# channel-group 1 mode active\nSwitch(config-if)# switchport port-security\nSwitch(config-if)# switchport port-security violation shutdown"
        ),

        // MODULE 10 LESSON
        LessonEntity(
            id = 1001,
            moduleId = 10,
            orderIndex = 1,
            titleFr = "1. ACLs (Standard/Étendue), Pare-feu, VPN, AAA & Attaques Réseau",
            titleEn = "1. ACLs (Standard/Extended), Firewalls, VPN, AAA & Network Attacks",
            contentFr = """
• ACL (Access Control Lists — Filtrage de paquets Cisco) :
Les ACLs sont lues séquentiellement du haut vers le bas et se terminent toujours par un `deny any` implicite :
1. **ACL Standard (1 à 99)** : Filtre UNIQUEMENT sur l'adresse IPv4 SOURCE. Règle : Placer le plus près possible de la **DESTINATION**.
2. **ACL Étendue (100 à 199)** : Filtre sur IP Source, IP Destination, Protocole (TCP/UDP/ICMP) et Ports. Règle : Placer le plus près possible de la **SOURCE**.

• Pare-feu (Firewalls) & VPN :
- **Pare-feu Stateful / NGFW** : Maintient une table d'état des connexions et inspecte jusqu'à la couche 7 (IPS, filtrage applicatif).
- **VPN (Virtual Private Network)** : Crée un tunnel chiffré sur Internet :
  • VPN Site-à-Site (IPsec IKEv2) : Relie deux agences en permanence.
  • VPN Accès Distant (TLS / Client VPN) : Pour les télétravailleurs.

• AAA (Authentication, Authorization, Accounting) & SSH :
- **Authentication** : Qui êtes-vous ? | **Authorization** : Que pouvez-vous faire ? | **Accounting** : Traçabilité des actions (via serveurs **RADIUS** ou **TACACS+**).

• Attaques Courantes & Contre-mesures :
- **MITM (Man-in-the-Middle) / ARP Spoofing** : Paré par **DAI (Dynamic ARP Inspection)**.
- **DHCP Spoofing / Starvation** : Paré par **DHCP Snooping** + Port Security.
- **DoS / DDoS** : Saturation des ressources par un flot massif de requêtes.
            """.trimIndent(),
            contentEn = """
• Access Control Lists (ACLs):
Evaluated top-to-bottom; every ACL ends with an unseen implicit `deny any`:
1. **Standard ACL (1–99)**: Filters ONLY by SOURCE IPv4 address. Best practice: Place as close to the **DESTINATION** as possible.
2. **Extended ACL (100–199)**: Filters by Source IP, Destination IP, Protocol (TCP/UDP/ICMP), and Port numbers. Best practice: Place as close to the **SOURCE** as possible.

• Firewalls & VPNs:
- **Stateful & Next-Gen Firewalls (NGFW)**: Track active connection states and inspect Layer 7 payloads.
- **VPN (Virtual Private Network)**: Encrypts traffic over untrusted public networks:
  • Site-to-Site VPN (IPsec): Connects corporate branch routers permanently.
  • Remote Access VPN (TLS/SSL or IPsec client): Connects remote workers.

• AAA Framework (RADIUS & TACACS+):
- **Authentication** (Who are you?), **Authorization** (What commands are allowed?), **Accounting** (Audit logging).

• Common Attacks & Defenses:
- **MITM / ARP Poisoning**: Mitigated using **Dynamic ARP Inspection (DAI)**.
- **Rogue DHCP / Starvation**: Mitigated using **DHCP Snooping** and Port Security.
- **DoS / DDoS**: Exhausting bandwidth or server CPU via botnets.
            """.trimIndent(),
            diagramType = "SECURITY_ACL",
            commandsBlock = "Router(config)# access-list 10 permit 192.168.1.0 0.0.0.255\nRouter(config)# access-list 100 permit tcp 192.168.1.0 0.0.0.255 any eq 443\nSwitch(config)# ip dhcp snooping\nSwitch(config)# ip arp inspection vlan 10"
        ),

        // MODULE 11 LESSON
        LessonEntity(
            id = 1101,
            moduleId = 11,
            orderIndex = 1,
            titleFr = "1. Normes Wi-Fi 802.11 (a/b/g/n/ac/ax), Canaux & Sécurité WPA2/WPA3",
            titleEn = "1. Wi-Fi 802.11 Standards (a/b/g/n/ac/ax), Channels & WPA2/WPA3",
            contentFr = """
• Les Normes IEEE 802.11 :
- 802.11a : 5 GHz, jusqu'à 54 Mbps | 802.11b : 2.4 GHz, 11 Mbps | 802.11g : 2.4 GHz, 54 Mbps
- **802.11n (Wi-Fi 4)** : 2.4 & 5 GHz, MIMO, jusqu'à 600 Mbps
- **802.11ac (Wi-Fi 5)** : 5 GHz uniquement, MU-MIMO descendant, jusqu'à 3,5+ Gbps
- **802.11ax (Wi-Fi 6 / 6E)** : 2.4, 5 & 6 GHz, OFDMA, MU-MIMO bidirectionnel, jusqu'à 9,6 Gbps.

• Identifiants & Canaux :
- **SSID** : Nom public du réseau Wi-Fi | **BSSID** : Adresse MAC de la radio du Point d'Accès (AP).
- Bande **2.4 GHz** : Portée plus grande mais encombrée ; seuls les canaux **1, 6 et 11** ne se chevauchent pas !
- Bande **5 GHz** : Débit supérieur et nombreux canaux sans chevauchement (ex. 36, 40, 44, 48).
- Évitement des collisions radio : **CSMA/CA** (Collision Avoidance avec RTS/CTS).

• Évolution de la Sécurité Sans-Fil :
- **WEP** : Obsolète et cassé en quelques secondes (RC4).
- **WPA** : Transitionnel (TKIP).
- **WPA2 (IEEE 802.11i)** : Chiffrement robuste **AES-CCMP** (Mode Personnel PSK ou Entreprise 802.1X RADIUS).
- **WPA3** : Remplace le handshake PSK par **SAE (Simultaneous Authentication of Equals)** résistant aux attaques par dictionnaire hors-ligne et impose les trames de gestion protégées (PMF).
            """.trimIndent(),
            contentEn = """
• IEEE 802.11 Standards:
- 802.11a: 5 GHz (54 Mbps) | 802.11b: 2.4 GHz (11 Mbps) | 802.11g: 2.4 GHz (54 Mbps)
- **802.11n (Wi-Fi 4)**: Dual-band 2.4 & 5 GHz, MIMO (up to 600 Mbps)
- **802.11ac (Wi-Fi 5)**: 5 GHz only, wider channels & MU-MIMO (up to 3.5+ Gbps)
- **802.11ax (Wi-Fi 6 / 6E)**: 2.4, 5, and 6 GHz, OFDMA, high-density efficiency (up to 9.6 Gbps).

• SSID, BSSID & Non-Overlapping Channels:
- **SSID**: Human-readable network name | **BSSID**: Physical MAC address of the Access Point radio.
- **2.4 GHz Band**: Longer range but crowded; only channels **1, 6, and 11** do NOT overlap!
- **5 GHz Band**: Higher throughput and many non-overlapping 20 MHz channels (36, 40, 44, 48...).
- Wireless media access uses **CSMA/CA** (Carrier Sense Multiple Access with Collision Avoidance).

• Wireless Security Evolution:
- **WEP**: Broken legacy RC4 encryption (never use).
- **WPA**: Legacy TKIP encryption.
- **WPA2**: Strong **AES-CCMP** encryption (Personal PSK or Enterprise 802.1X with RADIUS).
- **WPA3**: Uses **SAE (Simultaneous Authentication of Equals)** to prevent offline dictionary attacks and mandates Protected Management Frames (PMF).
            """.trimIndent(),
            diagramType = "WIFI_CHANNELS",
            commandsBlock = "2.4 GHz Non-Overlapping Channels: 1, 6, 11\nWPA2 Encryption: AES-CCMP | WPA3 Key Exchange: SAE"
        ),

        // MODULE 12 LESSON
        LessonEntity(
            id = 1201,
            moduleId = 12,
            orderIndex = 1,
            titleFr = "1. DNS, DHCP (Processus DORA), NAT/PAT, NTP, Syslog, SNMP & QoS",
            titleEn = "1. DNS, DHCP (DORA Process), NAT/PAT, NTP, Syslog, SNMP & QoS",
            contentFr = """
• DNS (Domain Name System — Port 53) :
Traduit les noms de domaine en adresses IP :
- **A** : Nom → Adresse IPv4 | **AAAA** : Nom → Adresse IPv6
- **CNAME** : Alias vers un autre nom canonique | **MX** : Serveur de messagerie | **PTR** : Recherche inversée (IP → Nom).

• DHCP (Dynamic Host Configuration Protocol — Ports UDP 67/68) :
Attribue automatiquement IP, masque, passerelle et DNS en 4 étapes (**DORA**) :
1. **D**iscover (Broadcast Client) → 2. **O**ffer (Serveur) → 3. **R**equest (Client) → 4. **A**cknowledge (Serveur).
Si le serveur DHCP est sur un autre sous-réseau, on configure `ip helper-address <ip-serveur>` sur le routeur (DHCP Relay).

• NAT / PAT (Network Address Translation) :
- **NAT Statique** : Correspondance 1-pour-1 fixe (pour héberger un serveur interne).
- **NAT Dynamique** : Pool d'adresses publiques.
- **PAT (NAT Overload)** : Des centaines d'hôtes privés partagent UNE SEULE adresse IPv4 publique grâce aux numéros de ports TCP/UDP sources uniques !

• NTP, Syslog, SNMP & QoS :
- **NTP (UDP 123)** : Synchronise les horloges (Stratum 0 = horloge atomique).
- **Syslog (UDP 514)** : Centralise les journaux d'événements (8 niveaux de gravité de 0 Emergency à 7 Debugging).
- **SNMP (UDP 161/162)** : Supervision des équipements via MIB/OID (SNMPv3 ajoute le chiffrement et l'authentification).
- **QoS (Quality of Service)** : Priorise la voix (EF — Expedited Forwarding, DSCP 46) avec des files LLQ (Low Latency Queuing) pour éviter la gigue (Jitter) et la perte.
            """.trimIndent(),
            contentEn = """
• DNS (Domain Name System — Port 53):
Resolves domain names to IP addresses:
- **A**: Hostname → IPv4 | **AAAA**: Hostname → IPv6
- **CNAME**: Alias record | **MX**: Mail Exchange server | **PTR**: Reverse DNS lookup.

• DHCP (Dynamic Host Configuration Protocol — UDP Ports 67/68):
Dynamically assigns IP, mask, default gateway, and DNS via the 4-step **DORA** process:
1. **D**iscover (Client Broadcast) → 2. **O**ffer (Server) → 3. **R**equest (Client) → 4. **A**cknowledge (Server).
Cross-subnet DHCP requires configuring `ip helper-address <dhcp-server-ip>` on the router interface.

• NAT & PAT (Port Address Translation):
- **Static NAT**: One-to-one mapping between an Inside Local and Inside Global IP.
- **Dynamic NAT**: Maps private IPs to a pool of public IPs.
- **PAT (NAT Overload)**: Maps hundreds of private Inside Local IPs to a SINGLE public Inside Global IP by tracking unique source TCP/UDP port numbers.

• NTP, Syslog, SNMP & QoS:
- **NTP (UDP 123)**: Synchronizes network clocks for accurate logs and certificates.
- **Syslog (UDP 514)**: Centralizes logs across 8 severity levels (0 Emergencies to 7 Debugging).
- **SNMP (UDP 161/162)**: Monitors devices via Manager, Agent, and MIB (use **SNMPv3** for encryption).
- **QoS**: Prioritizes real-time VoIP traffic (DSCP EF / 46) using Low Latency Queuing (LLQ).
            """.trimIndent(),
            diagramType = "DHCP_DORA",
            commandsBlock = "Router(config-if)# ip helper-address 10.10.10.5\nRouter(config)# ip nat inside source list 1 interface g0/1 overload\nRouter(config)# ntp server 216.239.35.0"
        ),

        // MODULE 13 LESSON
        LessonEntity(
            id = 1301,
            moduleId = 13,
            orderIndex = 1,
            titleFr = "1. Cloud (IaaS, PaaS, SaaS), SDN, NFV & Conteneurs vs VMs",
            titleEn = "1. Cloud (IaaS, PaaS, SaaS), SDN, NFV & Containers vs VMs",
            contentFr = """
• Les 3 Modèles de Services Cloud :
1. **IaaS (Infrastructure as a Service)** : Le fournisseur gère les serveurs physiques, le réseau et la virtualisation ; vous gérez l'OS et vos applications (ex. AWS EC2, Google Compute Engine, Azure VMs).
2. **PaaS (Platform as a Service)** : Le fournisseur gère aussi l'OS et l'environnement d'exécution ; vous déployez uniquement votre code (ex. Google App Engine, Heroku).
3. **SaaS (Software as a Service)** : Application complète prête à l'emploi accessible via navigateur (ex. Google Workspace, Microsoft 365).

• SDN (Software-Defined Networking) :
Dans un réseau traditionnel, chaque routeur possède son propre Plan de Contrôle (cerveau) et Plan de Données (transfert).
Le **SDN** sépare le **Plan de Contrôle (Control Plane)** du **Plan de Données (Data Plane)** en centralisant l'intelligence dans un **Contrôleur SDN** :
- **Southbound API (ex. OpenFlow, NETCONF)** : Du contrôleur vers les switches/routeurs.
- **Northbound API (REST API / JSON)** : Du contrôleur vers les applications d'orchestration et d'automatisation.

• NFV (Network Functions Virtualization) :
Remplace les boîtiers matériels dédiés (pare-feu, load-balancers, routeurs) par des fonctions réseau virtualisées (VNF) tournant sur des serveurs standards x86.

• Machines Virtuelles (VMs) vs Conteneurs (Docker / Kubernetes) :
- **VM** : S'exécute sur un Hyperviseur (VMware ESXi, KVM) et embarque un système d'exploitation (Guest OS) complet (lourd, en Go).
- **Conteneur** : Partage le noyau (Kernel) de l'OS hôte et n'isole que l'application et ses bibliothèques (démarrage en millisecondes, très léger en Mo).
            """.trimIndent(),
            contentEn = """
• The 3 Cloud Service Models:
1. **IaaS (Infrastructure as a Service)**: Provider manages physical hardware, storage, and hypervisor; you manage the OS, middleware, and apps (e.g., Compute Engine, AWS EC2).
2. **PaaS (Platform as a Service)**: Provider manages hardware, OS, and runtime; you only deploy your application code (e.g., App Engine).
3. **SaaS (Software as a Service)**: Complete turnkey software delivered over the web (e.g., Google Workspace, Salesforce).

• SDN (Software-Defined Networking):
Decouples the **Control Plane** (routing intelligence) from the **Data Plane** (packet forwarding) and centralizes control into an **SDN Controller**:
- **Southbound APIs (OpenFlow, NETCONF, RESTCONF)**: Controller communicates down to switches/routers.
- **Northbound APIs (REST APIs)**: Automation apps communicate with the controller.

• NFV (Network Functions Virtualization):
Virtualizes hardware appliances (firewalls, load balancers, WAN optimizers) into software VNFs running on standard servers.

• Virtual Machines (VMs) vs Containers (Docker / Kubernetes):
- **Virtual Machine**: Runs on a Hypervisor and bundles a full Guest OS per instance (gigabytes, slower boot).
- **Container**: Shares the host OS kernel and packages only the app and dependencies (megabytes, starts in milliseconds).
            """.trimIndent(),
            diagramType = "SDN_CLOUD",
            commandsBlock = "SDN Architecture:\n[Automation Apps] <-- Northbound REST API --> [SDN Controller] <-- Southbound OpenFlow/NETCONF --> [Switches/Data Plane]"
        )
    )

    val quizzes = listOf(
        // MODULE 9 QUIZ
        QuizQuestionEntity(
            id = 9001, moduleId = 9,
            questionFr = "Que fait un Switch lorsqu'il reçoit une trame dont l'adresse MAC de destination est absente de sa table CAM ?",
            questionEn = "What does a Switch do when it receives a frame with an unknown destination MAC address?",
            optionsFr = "Il détruit la trame immédiatement|Il inonde (Flood) la trame sur tous les ports du VLAN sauf le port d'entrée|Il l'envoie uniquement au routeur|Il envoie une requête DNS",
            optionsEn = "Drops the frame immediately|Floods the frame out all ports in the VLAN except the ingress port|Sends it only to the router|Sends a DNS query",
            correctIndex = 1,
            explanationFr = "Face à un Unicast inconnu, le switch diffuse (Flood) la trame sur tous les autres ports du même VLAN pour localiser le destinataire.",
            explanationEn = "For an unknown unicast MAC, the switch floods the frame out all other ports in the same VLAN."
        ),
        QuizQuestionEntity(
            id = 9002, moduleId = 9,
            questionFr = "Quel est le rôle principal du protocole Spanning Tree (STP / RSTP) ?",
            questionEn = "What is the primary purpose of Spanning Tree Protocol (STP / RSTP)?",
            optionsFr = "Chiffrer les trames Ethernet|Empêcher les boucles de commutation de couche 2|Attribuer des adresses IP|Augmenter le débit Wi-Fi",
            optionsEn = "Encrypt Ethernet frames|Prevent Layer 2 switching loops|Assign IP addresses|Increase Wi-Fi speed",
            correctIndex = 1,
            explanationFr = "STP bloque logiquement les ports redondants afin d'éviter les tempêtes de broadcast causées par les boucles de couche 2.",
            explanationEn = "STP prevents Layer 2 broadcast storms by logically blocking redundant switch paths."
        ),
        QuizQuestionEntity(
            id = 9003, moduleId = 9,
            questionFr = "Quel protocole standard ouvert permet d'agréger plusieurs liens physiques en un EtherChannel ?",
            questionEn = "Which open-standard protocol bundles multiple physical links into an EtherChannel?",
            optionsFr = "PAgP|LACP (IEEE 802.3ad)|VTP|STP",
            optionsEn = "PAgP|LACP (IEEE 802.3ad)|VTP|STP",
            correctIndex = 1,
            explanationFr = "LACP (IEEE 802.3ad) est le protocole standard d'agrégation de liens (modes Active/Passive), tandis que PAgP est propriétaire Cisco.",
            explanationEn = "LACP (IEEE 802.3ad) is the vendor-neutral link aggregation protocol (Active/Passive modes)."
        ),
        QuizQuestionEntity(
            id = 9004, moduleId = 9,
            questionFr = "Quel est le mode de violation par défaut de Port Security sur un switch Cisco ?",
            questionEn = "What is the default Port Security violation mode on a Cisco switch?",
            optionsFr = "Protect|Restrict|Shutdown (err-disabled)|Ignore",
            optionsEn = "Protect|Restrict|Shutdown (err-disabled)|Ignore",
            correctIndex = 2,
            explanationFr = "Par défaut, une violation Port Security place immédiatement le port en état `err-disabled` (Shutdown).",
            explanationEn = "By default, Port Security uses the `Shutdown` mode, placing the port into an `err-disabled` state."
        ),
        QuizQuestionEntity(
            id = 9005, moduleId = 9,
            questionFr = "Comment STP choisit-il le Root Bridge (Pont Racine) du réseau ?",
            questionEn = "How does STP elect the Root Bridge of a switched network?",
            optionsFr = "Le switch avec la plus grande adresse IP|Le switch avec le plus petit Bridge ID (Priorité + MAC)|Le switch ayant le plus de ports|Le switch le plus récent",
            optionsEn = "Switch with the highest IP|Switch with the lowest Bridge ID (Priority + MAC)|Switch with the most ports|Newest switch",
            correctIndex = 1,
            explanationFr = "Le switch possédant le plus petit Bridge ID (Priorité par défaut 32768 + adresse MAC la plus basse) devient Root Bridge.",
            explanationEn = "The switch with the lowest Bridge ID (Priority + MAC address) wins the Root Bridge election."
        ),

        // MODULE 10 QUIZ
        QuizQuestionEntity(
            id = 10001, moduleId = 10,
            questionFr = "Où doit-on placer une ACL Standard et une ACL Étendue selon les bonnes pratiques Cisco ?",
            questionEn = "Where should Standard and Extended ACLs be placed according to Cisco best practices?",
            optionsFr = "Standard près de la source, Étendue près de la destination|Standard près de la destination, Étendue près de la source|Les deux au cœur du réseau|Uniquement sur les switches",
            optionsEn = "Standard near source, Extended near destination|Standard near destination, Extended near source|Both in the core|Only on switches",
            correctIndex = 1,
            explanationFr = "L'ACL Standard ne filtrant que l'IP source, on la place près de la destination. L'ACL Étendue étant précise, on la place près de la source.",
            explanationEn = "Place Standard ACLs close to the destination, and Extended ACLs close to the source to block unwanted traffic early."
        ),
        QuizQuestionEntity(
            id = 10002, moduleId = 10,
            questionFr = "Quelle fonctionnalité de sécurité switch protège contre les serveurs DHCP pirates (DHCP Spoofing) ?",
            questionEn = "Which switch security feature blocks rogue DHCP servers (DHCP Spoofing)?",
            optionsFr = "PortFast|DHCP Snooping|STP Root Guard|VTP Pruning",
            optionsEn = "PortFast|DHCP Snooping|STP Root Guard|VTP Pruning",
            correctIndex = 1,
            explanationFr = "DHCP Snooping distingue les ports Trusted (vers le vrai serveur DHCP) des ports Untrusted (clients) et bloque les offres DHCP illégitimes.",
            explanationEn = "DHCP Snooping classifies ports as Trusted or Untrusted and drops DHCP Offer messages coming from untrusted ports."
        ),
        QuizQuestionEntity(
            id = 10003, moduleId = 10,
            questionFr = "Quelle règle invisible se trouve toujours à la toute fin de chaque ACL Cisco ?",
            questionEn = "What unseen rule automatically exists at the very end of every Cisco ACL?",
            optionsFr = "permit ip any any|deny any (Implicite)|log all packets|reset connection",
            optionsEn = "permit ip any any|Implicit deny any|log all packets|reset connection",
            correctIndex = 1,
            explanationFr = "Toute ACL se termine par un `deny any` implicite : une ACL doit donc contenir au moins une instruction `permit`.",
            explanationEn = "Every ACL ends with an implicit `deny any`, dropping any traffic not explicitly permitted."
        ),
        QuizQuestionEntity(
            id = 10004, moduleId = 10,
            questionFr = "Dans le modèle AAA, quelle étape détermine quelles commandes un utilisateur déjà connecté a le droit d'exécuter ?",
            questionEn = "In the AAA security framework, which component determines what commands an authenticated user is allowed to run?",
            optionsFr = "Authentication|Authorization|Accounting|Encryption",
            optionsEn = "Authentication|Authorization|Accounting|Encryption",
            correctIndex = 1,
            explanationFr = "L'Authorization définit les privilèges et permissions accordés à l'utilisateur après son authentification.",
            explanationEn = "Authorization controls what resources and commands a user is permitted to access after Authentication."
        ),
        QuizQuestionEntity(
            id = 10005, moduleId = 10,
            questionFr = "Quel type de VPN relie de façon permanente et transparente deux routeurs d'agences distantes via Internet ?",
            questionEn = "Which VPN type permanently connects two branch office routers over the public Internet?",
            optionsFr = "VPN Site-à-Site (IPsec)|VPN SSL Navigateur|VLAN Trunk|Port Mirroring",
            optionsEn = "Site-to-Site IPsec VPN|Browser SSL VPN|VLAN Trunk|Port Mirroring",
            correctIndex = 0,
            explanationFr = "Un VPN Site-à-Site IPsec chiffre le trafic de bout en bout entre deux passerelles/routeurs d'entreprise.",
            explanationEn = "A Site-to-Site IPsec VPN creates a permanent encrypted tunnel between two gateway routers."
        ),

        // MODULE 11 QUIZ
        QuizQuestionEntity(
            id = 11001, moduleId = 11,
            questionFr = "Quels sont les trois canaux Wi-Fi de la bande 2.4 GHz qui ne se chevauchent pas ?",
            questionEn = "Which three channels in the 2.4 GHz Wi-Fi band are non-overlapping?",
            optionsFr = "Canaux 1, 2 et 3|Canaux 1, 6 et 11|Canaux 2, 7 et 12|Canaux 36, 40 et 44",
            optionsEn = "Channels 1, 2, and 3|Channels 1, 6, and 11|Channels 2, 7, and 12|Channels 36, 40, and 44",
            correctIndex = 1,
            explanationFr = "En 2.4 GHz, chaque canal occupe 22 MHz : seuls les canaux 1, 6 et 11 sont espacés sans interférence mutuelle.",
            explanationEn = "In the 2.4 GHz band, channels 1, 6, and 11 are the standard three non-overlapping 20/22 MHz channels."
        ),
        QuizQuestionEntity(
            id = 11002, moduleId = 11,
            questionFr = "Quelle norme IEEE correspond au Wi-Fi 6 utilisant OFDMA sur les bandes 2.4 et 5 GHz ?",
            questionEn = "Which IEEE standard corresponds to Wi-Fi 6 using OFDMA across 2.4 GHz and 5 GHz?",
            optionsFr = "802.11g|802.11n|802.11ac|802.11ax",
            optionsEn = "802.11g|802.11n|802.11ac|802.11ax",
            correctIndex = 3,
            explanationFr = "802.11ax est la norme Wi-Fi 6 (et 6E en 6 GHz), tandis que 802.11ac est le Wi-Fi 5 et 802.11n le Wi-Fi 4.",
            explanationEn = "IEEE 802.11ax is Wi-Fi 6 (802.11ac is Wi-Fi 5, and 802.11n is Wi-Fi 4)."
        ),
        QuizQuestionEntity(
            id = 11003, moduleId = 11,
            questionFr = "Quel protocole d'échange de clés remplace le PSK dans WPA3-Personal pour bloquer les attaques par dictionnaire ?",
            questionEn = "Which key exchange protocol replaces PSK in WPA3-Personal to resist offline dictionary attacks?",
            optionsFr = "WEP-RC4|TKIP|SAE (Simultaneous Authentication of Equals)|MD5",
            optionsEn = "WEP-RC4|TKIP|SAE (Simultaneous Authentication of Equals)|MD5",
            correctIndex = 2,
            explanationFr = "WPA3 utilise SAE (Dragonfly handshake) qui empêche le cassage hors-ligne du mot de passe Wi-Fi.",
            explanationEn = "WPA3-Personal uses SAE (Simultaneous Authentication of Equals) for forward secrecy and dictionary attack resistance."
        ),
        QuizQuestionEntity(
            id = 11004, moduleId = 11,
            questionFr = "Que désigne le BSSID dans un réseau sans-fil 802.11 ?",
            questionEn = "What does the BSSID represent in an 802.11 wireless network?",
            optionsFr = "Le mot de passe du Wi-Fi|L'adresse MAC physique de la radio du Point d'Accès (AP)|L'adresse IP du routeur|Le numéro du canal",
            optionsEn = "The Wi-Fi password|The physical MAC address of the Access Point radio|The router IP address|The channel number",
            correctIndex = 1,
            explanationFr = "Le SSID est le nom textuel du réseau, tandis que le BSSID est l'adresse MAC de l'interface radio du point d'accès.",
            explanationEn = "While SSID is the network name, BSSID is the Layer 2 MAC address of the Access Point's radio interface."
        ),
        QuizQuestionEntity(
            id = 11005, moduleId = 11,
            questionFr = "Quelle méthode d'accès au support est utilisée par le Wi-Fi 802.11 pour éviter les collisions radio ?",
            questionEn = "Which media access control method is used by 802.11 Wi-Fi to avoid radio collisions?",
            optionsFr = "CSMA/CD|CSMA/CA (Collision Avoidance)|Token Passing|Full-Duplex TDM",
            optionsEn = "CSMA/CD|CSMA/CA (Collision Avoidance)|Token Passing|Full-Duplex TDM",
            correctIndex = 1,
            explanationFr = "Une antenne radio ne pouvant pas détecter les collisions pendant qu'elle émet, le Wi-Fi utilise CSMA/CA (Collision Avoidance).",
            explanationEn = "Wireless radios operate half-duplex and use CSMA/CA (Collision Avoidance) rather than Ethernet's CSMA/CD."
        ),

        // MODULE 12 QUIZ
        QuizQuestionEntity(
            id = 12001, moduleId = 12,
            questionFr = "Quel type d'enregistrement DNS associe un nom de domaine à une adresse IPv6 (128 bits) ?",
            questionEn = "Which DNS record type maps a hostname to a 128-bit IPv6 address?",
            optionsFr = "Enregistrement A|Enregistrement AAAA|Enregistrement CNAME|Enregistrement MX",
            optionsEn = "A Record|AAAA Record|CNAME Record|MX Record",
            correctIndex = 1,
            explanationFr = "L'enregistrement A pointe vers une IPv4 (32 bits) et l'enregistrement AAAA (Quad-A) vers une IPv6 (128 bits).",
            explanationEn = "An A record maps to a 32-bit IPv4 address, whereas a AAAA (Quad-A) record maps to a 128-bit IPv6 address."
        ),
        QuizQuestionEntity(
            id = 12002, moduleId = 12,
            questionFr = "Quel est l'ordre exact des 4 messages échangés lors de l'attribution d'une IP par DHCP ?",
            questionEn = "What is the exact 4-step message sequence used by DHCP to assign an IP address?",
            optionsFr = "Request -> Offer -> Discover -> Ack|Discover -> Offer -> Request -> Acknowledge (DORA)|Syn -> Offer -> Ack -> Fin|Query -> Response -> Confirm -> Done",
            optionsEn = "Request -> Offer -> Discover -> Ack|Discover -> Offer -> Request -> Acknowledge (DORA)|Syn -> Offer -> Ack -> Fin|Query -> Response -> Confirm -> Done",
            correctIndex = 1,
            explanationFr = "Le cycle DHCP suit l'acronyme DORA : DHCP Discover, DHCP Offer, DHCP Request, DHCP Acknowledge.",
            explanationEn = "DHCP follows the DORA sequence: Discover, Offer, Request, Acknowledge."
        ),
        QuizQuestionEntity(
            id = 12003, moduleId = 12,
            questionFr = "Quelle forme de NAT permet à des centaines d'hôtes privés de partager une seule IP publique grâce aux numéros de ports ?",
            questionEn = "Which type of NAT allows hundreds of private hosts to share a single public IP using unique port numbers?",
            optionsFr = "NAT Statique|NAT Dynamique sans surcharge|PAT (NAT Overload)|ARP Proxy",
            optionsEn = "Static NAT|Dynamic NAT Pool|PAT (Port Address Translation / NAT Overload)|Proxy ARP",
            correctIndex = 2,
            explanationFr = "Le PAT (Port Address Translation ou NAT Overload) différencie chaque session interne par son port TCP/UDP source.",
            explanationEn = "PAT (NAT Overload) multiplexes multiple private Inside Local IPs onto one Inside Global IP using unique port numbers."
        ),
        QuizQuestionEntity(
            id = 12004, moduleId = 12,
            questionFr = "Quel protocole sur le port UDP 123 synchronise les horloges des routeurs et serveurs ?",
            questionEn = "Which protocol running on UDP port 123 synchronizes clocks across routers and servers?",
            optionsFr = "SNMP|Syslog|NTP (Network Time Protocol)|TFTP",
            optionsEn = "SNMP|Syslog|NTP (Network Time Protocol)|TFTP",
            correctIndex = 2,
            explanationFr = "NTP (Network Time Protocol, UDP 123) assure la synchronisation horaire indispensable à la corrélation des journaux Syslog.",
            explanationEn = "NTP (Network Time Protocol, UDP 123) synchronizes system clocks across network devices."
        ),
        QuizQuestionEntity(
            id = 12005, moduleId = 12,
            questionFr = "Quelle version de SNMP offre à la fois l'authentification des messages et le chiffrement des paquets ?",
            questionEn = "Which version of SNMP provides both strong authentication and packet encryption?",
            optionsFr = "SNMPv1|SNMPv2c|SNMPv3|SNMP-Basic",
            optionsEn = "SNMPv1|SNMPv2c|SNMPv3|SNMP-Basic",
            correctIndex = 2,
            explanationFr = "SNMPv1 et v2c utilisent des chaînes de communauté en clair ; SNMPv3 introduit l'authentification et le chiffrement.",
            explanationEn = "SNMPv3 adds cryptographic authentication and encryption, unlike plaintext community strings in SNMPv1/v2c."
        ),

        // MODULE 13 QUIZ
        QuizQuestionEntity(
            id = 13001, moduleId = 13,
            questionFr = "Quel principe fondamental définit l'architecture SDN (Software-Defined Networking) ?",
            questionEn = "What is the core architectural principle of Software-Defined Networking (SDN)?",
            optionsFr = "Remplacer la fibre par du cuivre|Séparer le Plan de Contrôle (Control Plane) du Plan de Données (Data Plane)|Supprimer les adresses IP|Utiliser uniquement des hubs",
            optionsEn = "Replace fiber with copper|Decouple the Control Plane from the Data Plane|Eliminate IP addresses|Use only hubs",
            correctIndex = 1,
            explanationFr = "Le SDN extrait le plan de contrôle hors des équipements individuels pour le centraliser dans un Contrôleur SDN.",
            explanationEn = "SDN decouples the Control Plane from the Data Plane, centralizing network intelligence in an SDN Controller."
        ),
        QuizQuestionEntity(
            id = 13002, moduleId = 13,
            questionFr = "Dans quel modèle Cloud l'utilisateur loue des machines virtuelles et gère lui-même le système d'exploitation (OS) ?",
            questionEn = "In which Cloud model does the customer rent virtual machines and manage the Operating System themselves?",
            optionsFr = "SaaS|PaaS|IaaS (Infrastructure as a Service)|FaaS",
            optionsEn = "SaaS|PaaS|IaaS (Infrastructure as a Service)|FaaS",
            correctIndex = 2,
            explanationFr = "En IaaS, le fournisseur gère le matériel et la virtualisation tandis que le client contrôle l'OS, le stockage et ses applications.",
            explanationEn = "In IaaS (Infrastructure as a Service), the cloud provider supplies virtualized hardware while the user manages the OS and apps."
        ),
        QuizQuestionEntity(
            id = 13003, moduleId = 13,
            questionFr = "Quelle est la différence principale entre un Conteneur (Docker) et une Machine Virtuelle (VM) ?",
            questionEn = "What is the main architectural difference between a Container (Docker) and a Virtual Machine (VM)?",
            optionsFr = "Un conteneur partage le noyau (Kernel) de l'OS hôte au lieu d'embarquer un OS complet|Un conteneur nécessite plus de RAM qu'une VM|Une VM ne peut pas avoir d'adresse IP|Un conteneur ne fonctionne que sous Windows",
            optionsEn = "A container shares the host OS kernel instead of running a full Guest OS|A container requires more RAM than a VM|A VM cannot have an IP address|A container only runs on Windows",
            correctIndex = 0,
            explanationFr = "Les conteneurs partagent le noyau de l'hôte, ce qui les rend beaucoup plus légers et rapides à démarrer que des VMs complètes.",
            explanationEn = "Containers share the host OS kernel and isolate only the application process, making them much lighter and faster than VMs."
        ),
        QuizQuestionEntity(
            id = 13004, moduleId = 13,
            questionFr = "Quelle interface SDN permet au contrôleur de programmer directement les tables de flux des switches (ex. OpenFlow) ?",
            questionEn = "Which SDN interface allows the controller to program forwarding tables on switches (e.g., via OpenFlow)?",
            optionsFr = "Northbound API|Southbound API|East-West Cable|Console Port",
            optionsEn = "Northbound API|Southbound API|East-West Cable|Console Port",
            correctIndex = 1,
            explanationFr = "L'API Southbound (OpenFlow, NETCONF) relie le contrôleur SDN aux équipements du plan de données situés en dessous.",
            explanationEn = "Southbound APIs (like OpenFlow and NETCONF) connect the SDN Controller downward to switches and routers."
        ),
        QuizQuestionEntity(
            id = 13005, moduleId = 13,
            questionFr = "Que signifie le concept NFV (Network Functions Virtualization) ?",
            questionEn = "What does NFV (Network Functions Virtualization) accomplish?",
            optionsFr = "Exécuter des fonctions réseau (pare-feu, routeur, load-balancer) sous forme logicielle sur des serveurs standards|Augmenter la tension des câbles PoE|Remplacer le Wi-Fi par le Bluetooth|Désactiver le chiffrement TLS",
            optionsEn = "Runs network functions (firewalls, routers, load balancers) as software on standard servers|Increases PoE voltage|Replaces Wi-Fi with Bluetooth|Disables TLS encryption",
            correctIndex = 0,
            explanationFr = "La NFV remplace les équipements matériels propriétaires dédiés par des appliances virtuelles (VNF) déployées à la demande.",
            explanationEn = "NFV replaces dedicated hardware appliances with Virtualized Network Functions (VNFs) running on standard x86 servers."
        )
    )
}
