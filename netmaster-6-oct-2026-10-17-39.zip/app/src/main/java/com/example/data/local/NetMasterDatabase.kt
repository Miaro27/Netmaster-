package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ModuleEntity::class,
        LessonEntity::class,
        QuizQuestionEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class NetMasterDatabase : RoomDatabase() {
    abstract fun netMasterDao(): NetMasterDao

    companion object {
        @Volatile
        private var INSTANCE: NetMasterDatabase? = null

        fun getInstance(context: Context): NetMasterDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NetMasterDatabase::class.java,
                    "netmaster_offline.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
