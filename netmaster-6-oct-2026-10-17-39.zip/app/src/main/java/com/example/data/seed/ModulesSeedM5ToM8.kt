package com.example.data.seed

import com.example.data.local.LessonEntity
import com.example.data.local.ModuleEntity
import com.example.data.local.QuizQuestionEntity

object ModulesSeedM5ToM8 {

    val modules = listOf(
        ModuleEntity(
            id = 5,
            number = 5,
            level = 1,
            iconType = "HARDWARE_DEVICES",
            titleFr = "Équipements Réseau & Câblage",
            titleEn = "Network Devices & Cabling",
            descriptionFr = "NIC, Hub, Switch, Routeur, Pare-feu, câbles droits/croisés/fibre, normes Ethernet et domaines de collision/broadcast.",
            descriptionEn = "NIC, Hub, Switch, Router, Firewall, straight/crossover/fiber cables, Ethernet standards, and collision/broadcast domains."
        ),
        ModuleEntity(
            id = 6,
            number = 6,
            level = 2,
            iconType = "VLAN_TRUNK",
            titleFr = "VLAN, Trunking 802.1Q & Routage Inter-VLAN",
            titleEn = "VLANs, 802.1Q Trunking & Inter-VLAN Routing",
            descriptionFr = "VLAN Data/Voice/Natif, ports Access vs Trunk, étiquetage 802.1Q, Router-on-a-Stick, Switch L3 (SVI), VTP et commandes Cisco.",
            descriptionEn = "Data/Voice/Native VLANs, Access vs Trunk ports, 802.1Q tagging, Router-on-a-Stick, Layer 3 Switch (SVI), VTP, and Cisco CLI."
        ),
        ModuleEntity(
            id = 7,
            number = 7,
            level = 2,
            iconType = "PROTOCOLS_PORTS",
            titleFr = "Protocoles TCP/UDP, Ports & Services",
            titleEn = "TCP/UDP Protocols, Ports & Core Services",
            descriptionFr = "Comparaison TCP vs UDP, Three-Way Handshake, ports connus (80, 443, 22, 53), ARP, DHCP, DNS, ICMP, HTTP, FTP, SMTP/IMAP.",
            descriptionEn = "TCP vs UDP comparison, Three-Way Handshake, well-known ports, ARP, DHCP, DNS, ICMP, NAT, HTTP/HTTPS, FTP, SMTP, and IMAP."
        ),
        ModuleEntity(
            id = 8,
            number = 8,
            level = 3,
            iconType = "ROUTING_TABLE",
            titleFr = "Routage Statique & Dynamique (OSPF, EIGRP, BGP)",
            titleEn = "Static & Dynamic Routing (OSPF, EIGRP, BGP)",
            descriptionFr = "Table de routage, routes statiques, RIP, OSPF, EIGRP, BGP, métriques et distances administratives (AD).",
            descriptionEn = "Routing tables, static routes, dynamic protocols (RIP, OSPF, EIGRP, BGP), metrics, and Administrative Distance (AD)."
        )
    )

    val lessons = listOf(
        LessonEntity(
            id = 501,
            moduleId = 5,
            orderIndex = 1,
            titleFr = "1. NIC, Hub, Switch, Routeur, Pare-feu & Domaines",
            titleEn = "1. NIC, Hub, Switch, Router, Firewall & Domains",
            contentFr = """
• Les Équipements Réseau par couche OSI :
- NIC (Carte Réseau — Couches 1/2) : Possède une adresse MAC unique de 48 bits gravée (OUI 24 bits + ID 24 bits).
- Hub (Concentrateur — Couche 1) : Répéteur multiport obsolète qui renvoie le signal électrique sur TOUS les ports (Half-Duplex).
  → Tous les ports d'un Hub forment 1 seul domaine de collision et 1 seul domaine de broadcast.
- Switch (Commutateur — Couche 2) : Analyse l'adresse MAC destination grâce à sa table CAM et transmet la trame uniquement au port concerné (Full-Duplex).
  → Chaque port d'un Switch est un domaine de collision SÉPARÉ, mais tous les ports d'un même VLAN partagent le MÊME domaine de broadcast.
- Routeur (Couche 3) : Interconnecte des réseaux IP différents et choisit le meilleur chemin via sa table de routage.
  → Chaque interface d'un Routeur divise à la fois les domaines de collision ET les domaines de broadcast !
- Modem, Firewall (Pare-feu L3-L7) & Access Point Wi-Fi (Pont L2 entre 802.3 et 802.11).
            """.trimIndent(),
            contentEn = """
• Network Devices by OSI Layer:
- NIC (Network Interface Card — L1/L2): Has a globally unique 48-bit MAC address (24-bit OUI + 24-bit device ID).
- Hub (Layer 1): Legacy multiport repeater that floods electrical signals out ALL ports (Half-Duplex).
  → All ports on a Hub share 1 single collision domain and 1 broadcast domain.
- Switch (Layer 2): Learns source MAC addresses in its CAM table and forwards frames solely to the destination port (Full-Duplex).
  → Every Switch port is its OWN separate collision domain, while all ports in the same VLAN share 1 broadcast domain.
- Router (Layer 3): Connects different IP networks and routes packets using its routing table.
  → Every Router interface breaks BOTH collision domains AND broadcast domains!
- Modem, Firewall (L3–L7 stateful inspection), and Wireless Access Point (L2 bridge between 802.3 and 802.11).
            """.trimIndent(),
            diagramType = "DEVICES_DOMAINS",
            commandsBlock = "Hub: 1 Collision Domain, 1 Broadcast Domain\nSwitch (24 ports): 24 Collision Domains, 1 Broadcast Domain\nRouter: Breaks Broadcast Domains on every interface"
        ),
        LessonEntity(
            id = 502,
            moduleId = 5,
            orderIndex = 2,
            titleFr = "2. Câblage (Droit, Croisé, Console, Fibre) & Normes Ethernet",
            titleEn = "2. Cabling (Straight, Crossover, Console, Fiber) & Ethernet Standards",
            contentFr = """
• Types de Câbles :
1. Câble Droit (Straight-Through — T568B/T568B) : Relie des équipements différents (PC ↔ Switch, Routeur ↔ Switch).
2. Câble Croisé (Crossover — T568A/T568B) : Relie des équipements de même couche (Switch ↔ Switch, Routeur ↔ Routeur, PC ↔ PC). Auto-MDIX croise automatiquement sur les switches récents.
3. Câble Console (Rollover) : Relie un PC au port Console d'un routeur/switch (9600 bauds, 8N1).
4. Fibre Optique : Multimode (MMF, cœur 50/62,5 µm, courte distance < 550m) vs Monomode (SMF, cœur 9 µm laser, longue distance jusqu'à 100 km).

• Normes Ethernet IEEE 802.3 (distance cuivre max = 100 m) :
- 10BASE-T (10 Mbps), 100BASE-TX FastEthernet (100 Mbps), 1000BASE-T GigabitEthernet (1 Gbps Cat 5e/6), 10GBASE-T (10 Gbps Cat 6A/7).
            """.trimIndent(),
            contentEn = """
• Cable Types:
1. Straight-Through (T568B–T568B): Connects unlike devices (PC ↔ Switch, Router ↔ Switch).
2. Crossover (T568A–T568B): Connects like devices (Switch ↔ Switch, Router ↔ Router, PC ↔ PC). Modern switches feature Auto-MDIX.
3. Console (Rollover): Connects a PC to a router/switch Console port for CLI management (9600 baud, 8N1).
4. Fiber Optic: Multimode (MMF, 50/62.5 µm core, LED/VCSEL, <550m) vs Single-Mode (SMF, 9 µm core, Laser, 10–100 km).

• IEEE 802.3 Ethernet Standards (Max copper length = 100m):
- 10BASE-T (10 Mbps), 100BASE-TX (100 Mbps), 1000BASE-T (1 Gbps over Cat5e/Cat6), 10GBASE-T (10 Gbps over Cat6A/Cat7).
            """.trimIndent(),
            diagramType = "DEVICES_DOMAINS",
            commandsBlock = "Copper UTP Max Segment = 100m\n1000BASE-T = 1 Gbps | 10GBASE-T = 10 Gbps"
        ),
        LessonEntity(
            id = 601,
            moduleId = 6,
            orderIndex = 1,
            titleFr = "1. VLANs, Ports Access vs Trunk (802.1Q) & VTP",
            titleEn = "1. VLANs, Access vs Trunk Ports (802.1Q) & VTP",
            contentFr = """
• Qu'est-ce qu'un VLAN ?
Segmente logiquement un switch physique en plusieurs domaines de broadcast isolés (Sécurité, Performance, Gestion).
• Types : Data VLAN, Voice VLAN (VoIP QoS), Management VLAN (SSH/SNMP), Native VLAN (trafic non étiqueté sur un Trunk, par défaut VLAN 1 — recommandé de le changer vers un VLAN inutilisé comme 99).
• Access vs Trunk :
- Port Access : 1 seul VLAN vers un poste final (non étiqueté).
- Port Trunk (IEEE 802.1Q) : Transporte plusieurs VLANs entre switches avec un tag de 4 octets (ID VLAN sur 12 bits : 1 à 4094).
• VTP (VLAN Trunking Protocol) : Modes Server (crée/diffuse), Client (synchronise sans modifier) et Transparent (autonome localement + relaye les annonces).
            """.trimIndent(),
            contentEn = """
• What is a VLAN?
Logically partitions a physical switch into multiple isolated broadcast domains (Security, Performance, Management).
• Types: Data VLAN, Voice VLAN (VoIP QoS), Management VLAN (SSH/SNMP), Native VLAN (untagged traffic on a trunk, default VLAN 1 — best practice is changing it to an unused VLAN like 99).
• Access vs Trunk:
- Access Port: Carries a single VLAN to an endpoint (untagged).
- Trunk Port (IEEE 802.1Q): Multiplexes multiple VLANs across switches using a 4-byte tag (12-bit VLAN ID: 1–4094).
• VTP (VLAN Trunking Protocol): Server (creates/advertises), Client (syncs read-only), Transparent (local VLANs + forwards VTP frames).
            """.trimIndent(),
            diagramType = "VLAN_TRUNK",
            commandsBlock = "Switch(config)# vlan 10\nSwitch(config-vlan)# name DATA\nSwitch(config)# interface g0/1\nSwitch(config-if)# switchport mode trunk\nSwitch(config-if)# switchport trunk native vlan 99"
        ),
        LessonEntity(
            id = 602,
            moduleId = 6,
            orderIndex = 2,
            titleFr = "2. Routage Inter-VLAN : Router-on-a-Stick vs Switch Couche 3 (SVI)",
            titleEn = "2. Inter-VLAN Routing: Router-on-a-Stick vs Layer 3 Switch (SVI)",
            contentFr = """
• 1. Router-on-a-Stick (ROAS) :
Un lien Trunk unique relie le switch au routeur. Le routeur utilise des sous-interfaces logiques (`g0/0.10`, `g0/0.20`) avec `encapsulation dot1Q 10` et l'IP de passerelle de chaque VLAN.
• 2. Switch de Couche 3 (SVI — Switched Virtual Interface) :
Le routage matériel s'effectue dans le switch multicouche : on active `ip routing` puis on configure `interface Vlan 10` et `interface Vlan 20` avec leurs adresses IP.
            """.trimIndent(),
            contentEn = """
• 1. Router-on-a-Stick (ROAS):
A single physical trunk connects the switch to a router configured with logical subinterfaces (`g0/0.10`, `g0/0.20`) using `encapsulation dot1Q <vlan>` and gateway IPs.
• 2. Layer 3 Switch with SVIs (Switched Virtual Interfaces):
Hardware ASIC routing inside the multilayer switch: enable `ip routing` globally and configure `interface Vlan 10` and `interface Vlan 20` with gateway IPs.
            """.trimIndent(),
            diagramType = "VLAN_TRUNK",
            commandsBlock = "Router(config)# interface g0/0.10\nRouter(config-subif)# encapsulation dot1Q 10\nRouter(config-subif)# ip address 192.168.10.1 255.255.255.0\n\nL3Switch(config)# ip routing\nL3Switch(config)# interface vlan 10"
        ),
        LessonEntity(
            id = 701,
            moduleId = 7,
            orderIndex = 1,
            titleFr = "1. TCP vs UDP, Three-Way Handshake, Ports Connus & Protocoles",
            titleEn = "1. TCP vs UDP, Three-Way Handshake, Well-Known Ports & Protocols",
            contentFr = """
• TCP vs UDP :
- TCP : Orienté connexion, fiable (ACK, numéros de séquence, retransmission, fenêtrage). Ex: HTTP/HTTPS, SSH, FTP, SMTP, IMAP.
- UDP : Sans connexion, léger (en-tête 8 octets), faible latence. Ex: DNS, DHCP, VoIP, Streaming, SNMP, TFTP.
• Three-Way Handshake TCP : 1. SYN → 2. SYN-ACK → 3. ACK.
• Ports Connus : FTP (20/21), SSH (22), Telnet (23), SMTP (25), DNS (53), DHCP (67/68), TFTP (69), HTTP (80), POP3 (110), IMAP (143), SNMP (161), HTTPS (443).
• ARP (résout IP → MAC), ICMP (ping/traceroute), SMTP (envoi mail) vs POP3/IMAP (réception mail).
            """.trimIndent(),
            contentEn = """
• TCP vs UDP:
- TCP: Connection-oriented, reliable delivery (ACKs, sequence numbers, retransmission, windowing). Used by HTTP/HTTPS, SSH, FTP, SMTP, IMAP.
- UDP: Connectionless, low 8-byte header overhead, minimal latency. Used by DNS, DHCP, VoIP, Streaming, SNMP, TFTP.
• TCP Three-Way Handshake: 1. SYN → 2. SYN-ACK → 3. ACK.
• Well-Known Ports: FTP (20/21), SSH (22), Telnet (23), SMTP (25), DNS (53), DHCP (67/68), TFTP (69), HTTP (80), POP3 (110), IMAP (143), SNMP (161), HTTPS (443).
• ARP (resolves IPv4 → MAC), ICMP (ping/traceroute), SMTP (sending mail) vs POP3/IMAP (retrieving mail).
            """.trimIndent(),
            diagramType = "TCP_HANDSHAKE",
            commandsBlock = "Client --- [1. SYN] ---> Server\nClient <-- [2. SYN-ACK] --- Server\nClient --- [3. ACK] ---> Server"
        ),
        LessonEntity(
            id = 801,
            moduleId = 8,
            orderIndex = 1,
            titleFr = "1. Table de Routage, Routes Statiques, RIP, OSPF, EIGRP & BGP",
            titleEn = "1. Routing Table, Static Routes, RIP, OSPF, EIGRP & BGP",
            contentFr = """
• Décision de routage : Le routeur choisit toujours le **Plus Long Préfixe (Longest Prefix Match)** (ex. /26 bat /24).
• Distance Administrative (AD) : En cas d'égalité de préfixe, la plus petite AD gagne :
  Connecté = 0 | Statique = 1 | eBGP = 20 | EIGRP = 90 | OSPF = 110 | IS-IS = 115 | RIP = 120.
• Routage Statique : `ip route <réseau> <masque> <next-hop>` ; route par défaut : `ip route 0.0.0.0 0.0.0.0 <next-hop>`.
• Protocoles Dynamiques :
  - RIPv2 : Vecteur de distance, métrique = sauts (max 15).
  - OSPF : État de liens, algorithme Dijkstra SPF, métrique = Coût (bande passante), hiérarchie Area 0.
  - EIGRP : Algorithme DUAL (Successor / Feasible Successor), métrique Bande passante + Délai.
  - BGP (TCP 179) : Vecteur de chemin (EGP) interconnectant les Systèmes Autonomes (AS) d'Internet.
            """.trimIndent(),
            contentEn = """
• Forwarding Decision: Routers always prefer the **Longest Prefix Match** (e.g., /26 beats /24).
• Administrative Distance (AD): Tie-breaker for identical prefixes (lowest wins):
  Connected = 0 | Static = 1 | eBGP = 20 | EIGRP = 90 | OSPF = 110 | IS-IS = 115 | RIP = 120.
• Static Routing: `ip route <net> <mask> <next-hop>`; Default route: `ip route 0.0.0.0 0.0.0.0 <next-hop>`.
• Dynamic Routing Protocols:
  - RIPv2: Distance-Vector, metric = Hop Count (max 15).
  - OSPF: Link-State, Dijkstra SPF algorithm, metric = Cost (bandwidth), Area 0 backbone.
  - EIGRP: DUAL algorithm (Successor / Feasible Successor), Bandwidth + Delay metric.
  - BGP (TCP 179): Path-Vector EGP routing between Autonomous Systems (AS) across the Internet.
            """.trimIndent(),
            diagramType = "ROUTING_TOPOLOGY",
            commandsBlock = "Router(config)# ip route 0.0.0.0 0.0.0.0 203.0.113.1\nRouter(config)# router ospf 1\nRouter(config-router)# network 192.168.1.0 0.0.0.255 area 0"
        )
    )

    val quizzes = listOf(
        // MODULE 5 QUIZ
        QuizQuestionEntity(
            id = 5001, moduleId = 5,
            questionFr = "Combien de domaines de collision et de broadcast possède un Switch 24 ports (dans un seul VLAN) ?",
            questionEn = "How many collision domains and broadcast domains exist on a 24-port Switch (single VLAN)?",
            optionsFr = "1 collision, 1 broadcast|24 collision, 1 broadcast|1 collision, 24 broadcast|24 collision, 24 broadcast",
            optionsEn = "1 collision, 1 broadcast|24 collision, 1 broadcast|1 collision, 24 broadcast|24 collision, 24 broadcast",
            correctIndex = 1,
            explanationFr = "Chaque port d'un Switch isole son propre domaine de collision (24), tandis que le VLAN unique forme 1 seul domaine de broadcast.",
            explanationEn = "Every switch port is a separate collision domain (24), while a single VLAN shares 1 broadcast domain."
        ),
        QuizQuestionEntity(
            id = 5002, moduleId = 5,
            questionFr = "Quel équipement réseau divise les domaines de broadcast sur chacune de ses interfaces ?",
            questionEn = "Which device separates broadcast domains on every interface?",
            optionsFr = "Hub|Switch Couche 2|Routeur|Répéteur",
            optionsEn = "Hub|Layer 2 Switch|Router|Repeater",
            correctIndex = 2,
            explanationFr = "Un routeur (Couche 3) bloque les diffusions de couche 2 et sépare les domaines de broadcast.",
            explanationEn = "A Router (Layer 3) does not forward Layer 2 broadcasts, isolating broadcast domains per interface."
        ),
        QuizQuestionEntity(
            id = 5003, moduleId = 5,
            questionFr = "Quelle est la distance maximale d'un câble cuivre Ethernet UTP (Cat 5e / Cat 6) ?",
            questionEn = "What is the maximum segment length for copper UTP Ethernet (Cat 5e / Cat 6)?",
            optionsFr = "50 mètres|100 mètres|500 mètres|1000 mètres",
            optionsEn = "50 meters|100 meters|500 meters|1000 meters",
            correctIndex = 1,
            explanationFr = "La norme IEEE 802.3 limite le câble cuivre UTP à 100 mètres maximum.",
            explanationEn = "IEEE 802.3 limits twisted-pair copper segments to 100 meters."
        ),
        QuizQuestionEntity(
            id = 5004, moduleId = 5,
            questionFr = "Quel type de fibre optique utilise un laser sur un cœur de 9 µm pour les très longues distances WAN ?",
            questionEn = "Which fiber optic cable uses a laser over a 9 µm core for long-haul WAN links?",
            optionsFr = "Fibre Multimode (MMF)|Fibre Monomode (SMF)|Câble Coaxial|Câble Console",
            optionsEn = "Multimode Fiber (MMF)|Single-Mode Fiber (SMF)|Coaxial Cable|Console Cable",
            correctIndex = 1,
            explanationFr = "La fibre Monomode (SMF) permet d'atteindre plusieurs dizaines de kilomètres sans répéteur.",
            explanationEn = "Single-Mode Fiber (SMF) supports long-distance transmission up to 40–100 km."
        ),
        QuizQuestionEntity(
            id = 5005, moduleId = 5,
            questionFr = "Sans Auto-MDIX, quel câble relie un PC à un Switch ?",
            questionEn = "Without Auto-MDIX, which cable connects a PC to a Switch?",
            optionsFr = "Câble Droit (Straight-Through)|Câble Croisé (Crossover)|Câble Console|Fibre Monomode",
            optionsEn = "Straight-Through Cable|Crossover Cable|Console Cable|Single-Mode Fiber",
            correctIndex = 0,
            explanationFr = "Un PC et un Switch sont des équipements de couches différentes : on utilise un câble droit.",
            explanationEn = "A PC and a Switch are unlike devices and connect via a Straight-Through cable."
        ),

        // MODULE 6 QUIZ
        QuizQuestionEntity(
            id = 6001, moduleId = 6,
            questionFr = "Quel protocole standard IEEE ajoute un tag de 4 octets sur un lien Trunk ?",
            questionEn = "Which IEEE protocol adds a 4-byte VLAN tag on a Trunk link?",
            optionsFr = "802.11|802.1D|802.1Q|802.3af",
            optionsEn = "802.11|802.1D|802.1Q|802.3af",
            correctIndex = 2,
            explanationFr = "IEEE 802.1Q est le standard d'étiquetage de trames VLAN sur les liens Trunk.",
            explanationEn = "IEEE 802.1Q is the standard trunking protocol that inserts a 4-byte VLAN tag."
        ),
        QuizQuestionEntity(
            id = 6002, moduleId = 6,
            questionFr = "Comment circulent les trames du VLAN Natif sur un lien Trunk 802.1Q ?",
            questionEn = "How do Native VLAN frames travel across an 802.1Q Trunk link?",
            optionsFr = "Chiffrées en AES|Sans étiquette (Untagged)|Avec deux étiquettes|Elles sont bloquées",
            optionsEn = "Encrypted with AES|Untagged (without a VLAN tag)|Double-tagged|Dropped",
            correctIndex = 1,
            explanationFr = "Les trames du VLAN Natif traversent le lien Trunk sans tag 802.1Q.",
            explanationEn = "Frames in the Native VLAN travel across an 802.1Q trunk without any VLAN tag."
        ),
        QuizQuestionEntity(
            id = 6003, moduleId = 6,
            questionFr = "Quel mode VTP permet de gérer des VLANs locaux tout en relayant les annonces VTP ?",
            questionEn = "Which VTP mode allows local VLAN creation while forwarding VTP advertisements?",
            optionsFr = "Server|Client|Transparent|Off",
            optionsEn = "Server|Client|Transparent|Off",
            correctIndex = 2,
            explanationFr = "Le mode VTP Transparent maintient une base VLAN locale indépendante et relaye les trames VTP.",
            explanationEn = "VTP Transparent mode keeps its VLAN database local while forwarding VTP messages."
        ),
        QuizQuestionEntity(
            id = 6004, moduleId = 6,
            questionFr = "Quelle commande globale active le routage inter-VLAN sur un Switch de couche 3 ?",
            questionEn = "Which global command enables inter-VLAN routing on a Layer 3 Switch?",
            optionsFr = "switchport trunk|ip routing|router vlan|vlan routing",
            optionsEn = "switchport trunk|ip routing|router vlan|vlan routing",
            correctIndex = 1,
            explanationFr = "La commande `ip routing` active le routage IPv4 entre les interfaces SVI d'un switch L3.",
            explanationEn = "`ip routing` enables Layer 3 routing across Switched Virtual Interfaces (SVIs)."
        ),
        QuizQuestionEntity(
            id = 6005, moduleId = 6,
            questionFr = "En Router-on-a-Stick, où configure-t-on l'adresse IP de passerelle de chaque VLAN ?",
            questionEn = "In Router-on-a-Stick, where is each VLAN's default gateway IP configured?",
            optionsFr = "Sur les ports Access|Sur les sous-interfaces du routeur (ex. G0/0.10)|Dans VTP|Sur le câble console",
            optionsEn = "On Access ports|On router subinterfaces (e.g. G0/0.10)|In VTP|On the console cable",
            correctIndex = 1,
            explanationFr = "Chaque VLAN est associé à une sous-interface logique du routeur avec `encapsulation dot1Q <vlan>`.",
            explanationEn = "Each VLAN uses a logical router subinterface configured with `encapsulation dot1Q <vlan>`."
        ),

        // MODULE 7 QUIZ
        QuizQuestionEntity(
            id = 7001, moduleId = 7,
            questionFr = "Quelle est la séquence du Three-Way Handshake TCP ?",
            questionEn = "What is the sequence of the TCP Three-Way Handshake?",
            optionsFr = "ACK -> SYN -> SYN-ACK|SYN -> SYN-ACK -> ACK|SYN -> FIN -> ACK|REQ -> REP -> ACK",
            optionsEn = "ACK -> SYN -> SYN-ACK|SYN -> SYN-ACK -> ACK|SYN -> FIN -> ACK|REQ -> REP -> ACK",
            correctIndex = 1,
            explanationFr = "La connexion TCP s'établit en 3 étapes : SYN, SYN-ACK, puis ACK.",
            explanationEn = "TCP establishes a session using SYN, SYN-ACK, and ACK."
        ),
        QuizQuestionEntity(
            id = 7002, moduleId = 7,
            questionFr = "Quel port TCP est utilisé par le protocole sécurisé SSH ?",
            questionEn = "Which TCP port is used by Secure Shell (SSH)?",
            optionsFr = "Port 21|Port 22|Port 23|Port 80",
            optionsEn = "Port 21|Port 22|Port 23|Port 80",
            correctIndex = 1,
            explanationFr = "SSH utilise le port TCP 22 (tandis que Telnet utilise 23 et FTP 21).",
            explanationEn = "SSH operates over TCP port 22 (Telnet uses 23 and FTP uses 21)."
        ),
        QuizQuestionEntity(
            id = 7003, moduleId = 7,
            questionFr = "Quel protocole découvre l'adresse MAC associée à une adresse IPv4 sur le LAN ?",
            questionEn = "Which protocol resolves a known IPv4 address to a MAC address on a LAN?",
            optionsFr = "DNS|DHCP|ARP|ICMP",
            optionsEn = "DNS|DHCP|ARP|ICMP",
            correctIndex = 2,
            explanationFr = "ARP (Address Resolution Protocol) diffuse une requête ARP pour obtenir l'adresse MAC cible.",
            explanationEn = "ARP (Address Resolution Protocol) maps Layer 3 IPv4 addresses to Layer 2 MAC addresses."
        ),
        QuizQuestionEntity(
            id = 7004, moduleId = 7,
            questionFr = "Quel protocole de transport est privilégié pour la VoIP et le streaming temps réel ?",
            questionEn = "Which transport protocol is preferred for real-time VoIP and live video?",
            optionsFr = "TCP|UDP|ICMP|ARP",
            optionsEn = "TCP|UDP|ICMP|ARP",
            correctIndex = 1,
            explanationFr = "UDP offre une latence minimale sans délai de retransmission.",
            explanationEn = "UDP avoids retransmission delays and connection overhead, minimizing latency."
        ),
        QuizQuestionEntity(
            id = 7005, moduleId = 7,
            questionFr = "Quel protocole permet l'envoi des emails depuis le client vers le serveur de messagerie ?",
            questionEn = "Which protocol is used to send outgoing emails from a client to a mail server?",
            optionsFr = "POP3|IMAP|SMTP|SNMP",
            optionsEn = "POP3|IMAP|SMTP|SNMP",
            correctIndex = 2,
            explanationFr = "SMTP (port TCP 25/587) gère l'envoi et le transfert des courriels.",
            explanationEn = "SMTP (Simple Mail Transfer Protocol, TCP port 25/587) handles outgoing email delivery."
        ),

        // MODULE 8 QUIZ
        QuizQuestionEntity(
            id = 8001, moduleId = 8,
            questionFr = "Quelle est la Distance Administrative (AD) par défaut d'OSPF ?",
            questionEn = "What is the default Administrative Distance (AD) of OSPF?",
            optionsFr = "1|90|110|120",
            optionsEn = "1|90|110|120",
            correctIndex = 2,
            explanationFr = "AD par défaut : Statique = 1, EIGRP = 90, OSPF = 110, RIP = 120.",
            explanationEn = "Default AD values: Static = 1, EIGRP = 90, OSPF = 110, RIP = 120."
        ),
        QuizQuestionEntity(
            id = 8002, moduleId = 8,
            questionFr = "Entre les routes 10.0.0.0/8 (EIGRP), 10.1.0.0/16 (OSPF) et 10.1.1.0/24 (RIP), laquelle est choisie pour 10.1.1.5 ?",
            questionEn = "Given routes 10.0.0.0/8 (EIGRP), 10.1.0.0/16 (OSPF), and 10.1.1.0/24 (RIP), which is chosen for 10.1.1.5?",
            optionsFr = "10.0.0.0/8 (EIGRP)|10.1.0.0/16 (OSPF)|10.1.1.0/24 (RIP) par Longest Prefix Match|Aucune",
            optionsEn = "10.0.0.0/8 (EIGRP)|10.1.0.0/16 (OSPF)|10.1.1.0/24 (RIP) via Longest Prefix Match|None",
            correctIndex = 2,
            explanationFr = "Le Plus Long Préfixe (/24) l'emporte toujours sur la distance administrative.",
            explanationEn = "Longest Prefix Match (/24) always takes precedence over Administrative Distance."
        ),
        QuizQuestionEntity(
            id = 8003, moduleId = 8,
            questionFr = "Quel algorithme est utilisé par OSPF pour calculer l'arbre du plus court chemin ?",
            questionEn = "Which algorithm does OSPF use to compute the shortest path tree?",
            optionsFr = "DUAL|Dijkstra (SPF)|Bellman-Ford|RSA",
            optionsEn = "DUAL|Dijkstra (SPF)|Bellman-Ford|RSA",
            correctIndex = 1,
            explanationFr = "OSPF utilise l'algorithme SPF de Dijkstra sur sa base d'état de liens (LSDB).",
            explanationEn = "OSPF executes Dijkstra's Shortest Path First (SPF) algorithm on the LSDB."
        ),
        QuizQuestionEntity(
            id = 8004, moduleId = 8,
            questionFr = "Quelle commande configure une route par défaut IPv4 sur Cisco IOS ?",
            questionEn = "Which command configures an IPv4 default static route on Cisco IOS?",
            optionsFr = "ip route 255.255.255.255 0.0.0.0 10.0.0.1|ip route 0.0.0.0 0.0.0.0 10.0.0.1|default-router 10.0.0.1|route all 10.0.0.1",
            optionsEn = "ip route 255.255.255.255 0.0.0.0 10.0.0.1|ip route 0.0.0.0 0.0.0.0 10.0.0.1|default-router 10.0.0.1|route all 10.0.0.1",
            correctIndex = 1,
            explanationFr = "`ip route 0.0.0.0 0.0.0.0 <next-hop>` définit la passerelle de dernier recours.",
            explanationEn = "`ip route 0.0.0.0 0.0.0.0 <next-hop>` configures the Gateway of Last Resort."
        ),
        QuizQuestionEntity(
            id = 8005, moduleId = 8,
            questionFr = "Quel protocole de routage externe (EGP) relie les Systèmes Autonomes sur Internet ?",
            questionEn = "Which Exterior Gateway Protocol (EGP) interconnects Autonomous Systems across the Internet?",
            optionsFr = "OSPF|EIGRP|BGP|IS-IS",
            optionsEn = "OSPF|EIGRP|BGP|IS-IS",
            correctIndex = 2,
            explanationFr = "BGP (Border Gateway Protocol, TCP 179) est le protocole EGP d'Internet.",
            explanationEn = "BGP (Border Gateway Protocol, TCP 179) is the EGP of the global Internet."
        )
    )
}
