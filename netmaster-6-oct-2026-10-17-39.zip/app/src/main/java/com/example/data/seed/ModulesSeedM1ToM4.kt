package com.example.data.seed

import com.example.data.local.LessonEntity
import com.example.data.local.ModuleEntity
import com.example.data.local.QuizQuestionEntity

object ModulesSeedM1ToM4 {

    val modules = listOf(
        ModuleEntity(
            id = 1,
            number = 1,
            level = 1,
            iconType = "OSI_NETWORK",
            titleFr = "Introduction aux Réseaux",
            titleEn = "Introduction to Networks",
            descriptionFr = "Définition, types (LAN/WAN), topologies, modèle OSI 7 couches, TCP/IP, encapsulation et histoire d'Internet.",
            descriptionEn = "Definition, network types (LAN/WAN), topologies, 7-layer OSI model, TCP/IP, encapsulation, and Internet history."
        ),
        ModuleEntity(
            id = 2,
            number = 2,
            level = 1,
            iconType = "BINARY_MATH",
            titleFr = "Systèmes Numériques & Calcul Binaire",
            titleEn = "Number Systems & Binary Calculation",
            descriptionFr = "Binaire, décimal, hexadécimal, octal, conversions étape par étape, opérations logiques (AND, OR, XOR) et unités de données.",
            descriptionEn = "Binary, decimal, hexadecimal, octal, step-by-step base conversions, bitwise operations (AND, OR, XOR), and data units."
        ),
        ModuleEntity(
            id = 3,
            number = 3,
            level = 2,
            iconType = "IP_SUBNET",
            titleFr = "Adressage IPv4 & Sous-Réseaux (VLSM)",
            titleEn = "IPv4 Addressing & Subnetting (VLSM)",
            descriptionFr = "Structure IPv4, classes A-E, RFC 1918, CIDR, méthode classique, nombre magique et découpage VLSM.",
            descriptionEn = "IPv4 structure, classes A-E, RFC 1918 private ranges, CIDR, classic subnetting, magic number method, and VLSM."
        ),
        ModuleEntity(
            id = 4,
            number = 4,
            level = 2,
            iconType = "IPV6_GLOBE",
            titleFr = "Protocole IPv6 Nouvelle Génération",
            titleEn = "Next-Generation IPv6 Protocol",
            descriptionFr = "Format 128 bits hexadécimal, règles d'abréviation, Unicast/Multicast/Anycast, Link-Local et transition Dual-Stack.",
            descriptionEn = "128-bit hex format, abbreviation rules, Unicast/Multicast/Anycast, Link-Local/Global scopes, and Dual-Stack transition."
        )
    )

    val lessons = listOf(
        // MODULE 1 LESSONS
        LessonEntity(
            id = 101,
            moduleId = 1,
            orderIndex = 1,
            titleFr = "1. Qu'est-ce qu'un réseau ? Types (PAN, LAN, CAN, MAN, WAN)",
            titleEn = "1. What is a Network? Types (PAN, LAN, CAN, MAN, WAN)",
            contentFr = """
• Définition & Analogie Simple :
Un réseau informatique est un ensemble d'équipements (ordinateurs, serveurs, smartphones, routeurs) interconnectés afin d'échanger des données et de partager des ressources.
Analogie : Imaginez le système postal ou routier. Les maisons sont les ordinateurs (hôtes), leur adresse postale est l'adresse IP, les routes sont les câbles/ondes Wi-Fi, et les centres de tri postaux sont les routeurs qui orientent chaque colis (paquet) vers la bonne ville.

• Classification par étendue géographique :
1. PAN (Personal Area Network) : Réseau personnel sur quelques mètres (Bluetooth, AirDrop, montre connectée).
2. LAN (Local Area Network) : Réseau local à l'échelle d'une maison, d'un bureau ou d'un bâtiment (Ethernet IEEE 802.3, Wi-Fi). Très haut débit, faible latence.
3. CAN (Campus Area Network) : Interconnexion de plusieurs bâtiments d'une université ou d'une base industrielle.
4. MAN (Metropolitan Area Network) : Réseau métropolitain couvrant une ville entière (souvent en fibre optique opérateur).
5. WAN (Wide Area Network) : Réseau étendu à l'échelle d'un pays ou d'un continent. Internet est le plus grand WAN mondial.

• Brève Histoire d'Internet :
- 1969 : ARPANET (Département de la Défense US) connecte 4 universités américaines.
- 1974 : Vinton Cerf et Bob Kahn publient les spécifications de TCP/IP.
- 1983 : ARPANET adopte officiellement TCP/IP le 1er janvier (naissance d'Internet moderne).
- 1989-1991 : Tim Berners-Lee invente le World Wide Web (HTTP/HTML) au CERN.
            """.trimIndent(),
            contentEn = """
• Definition & Simple Analogy:
A computer network is a group of interconnected devices (computers, servers, smartphones, routers) that exchange data and share resources.
Analogy: Think of a postal system or highway network. Houses are computers (hosts), street addresses are IP addresses, roads are cables or Wi-Fi waves, and sorting centers are routers directing every parcel (packet) to its destination.

• Network Types by Geographic Scope:
1. PAN (Personal Area Network): Spans a few meters around a person (Bluetooth, USB, smartwatch).
2. LAN (Local Area Network): Covers a single home, office, or building floor (Ethernet 802.3, Wi-Fi). High speed and low latency.
3. CAN (Campus Area Network): Connects multiple buildings across a university campus or corporate park.
4. MAN (Metropolitan Area Network): Spans an entire city using metro fiber rings.
5. WAN (Wide Area Network): Spans countries or continents. The Internet is the world's largest public WAN.

• Brief History of the Internet:
- 1969: ARPANET connects four US universities using packet switching.
- 1974: Vint Cerf and Bob Kahn design the TCP/IP protocol suite.
- 1983: ARPANET officially switches to TCP/IP on January 1st, marking the birth of the modern Internet.
- 1989-1991: Tim Berners-Lee invents the World Wide Web (HTTP/HTML) at CERN.
            """.trimIndent(),
            diagramType = "TOPOLOGY_STAR",
            commandsBlock = "ping 8.8.8.8\ntraceroute 1.1.1.1\nshow version"
        ),
        LessonEntity(
            id = 102,
            moduleId = 1,
            orderIndex = 2,
            titleFr = "2. Topologies Réseau : Bus, Anneau, Étoile, Maillée, Hybride",
            titleEn = "2. Network Topologies: Bus, Ring, Star, Mesh, Hybrid",
            contentFr = """
La topologie définit l'agencement physique (câblage réel) et logique (circulation des données) d'un réseau :

• 1. Topologie en Bus :
Tous les hôtes sont reliés à un câble coaxial unique (dorsale).
- Avantage : Simple et peu coûteux en câble.
- Inconvénient : Si le câble principal est coupé, tout le réseau tombe en panne ; collisions fréquentes (CSMA/CD).

• 2. Topologie en Anneau (Ring) :
Chaque équipement est relié à deux voisins pour former une boucle fermée (ex. Token Ring, FDDI). Un jeton circule pour autoriser l'émission.

• 3. Topologie en Étoile (Star) — Standard LAN actuel :
Tous les postes sont reliés individuellement à un équipement central (Switch).
- Avantage : La panne d'un câble n'affecte qu'un seul poste ; facile à dépanner et à étendre.
- Inconvénient : Dépendance vis-à-vis du commutateur central (point unique de défaillance s'il n'est pas redondé).

• 4. Topologie Maillée (Full / Partial Mesh) :
Chaque routeur est connecté directement à tous les autres (maillage complet : N*(N-1)/2 liens) ou à plusieurs (maillage partiel).
- Avantage : Tolérance aux pannes maximale (utilisé dans les cœurs WAN et Data Centers).

• 5. Topologie Hybride (Star-Bus / Spine-Leaf) :
Combine plusieurs topologies (ex. plusieurs étoiles interconnectées par une dorsale fibre).
            """.trimIndent(),
            contentEn = """
Network topology defines both the physical layout (actual cabling) and logical flow of frames across the network:

• 1. Bus Topology:
All nodes share a single backbone coaxial cable terminated at both ends.
- Pros: Inexpensive and minimal cabling.
- Cons: A single cable break brings down the entire network; prone to collisions.

• 2. Ring Topology:
Each device connects to exactly two neighbors forming a closed loop (e.g., Token Ring, FDDI). Data travels unidirectionally or via dual counter-rotating rings.

• 3. Star Topology — Modern LAN Standard:
Every endpoint connects via its own dedicated cable to a central Switch.
- Pros: A cable failure isolates only one host; easy troubleshooting and scalability.
- Cons: Central switch is a single point of failure unless redundant switches are deployed.

• 4. Mesh Topology (Full or Partial Mesh):
Every node links directly to every other node. Formula for Full Mesh links = N × (N - 1) / 2.
- Pros: Maximum fault tolerance and zero single point of failure (used in WAN cores).

• 5. Hybrid Topology:
Combines two or more topologies, such as Star-Wired Bus or modern Spine-Leaf data center architectures.
            """.trimIndent(),
            diagramType = "TOPOLOGY_STAR",
            commandsBlock = "Full Mesh Links = N * (N - 1) / 2\nExample (6 routers) = 6 * 5 / 2 = 15 links"
        ),
        LessonEntity(
            id = 103,
            moduleId = 1,
            orderIndex = 3,
            titleFr = "3. Modèle OSI (7 Couches), TCP/IP (4 Couches) & Encapsulation",
            titleEn = "3. OSI Model (7 Layers), TCP/IP (4 Layers) & Encapsulation",
            contentFr = """
• Le Modèle OSI (Open Systems Interconnection — ISO) comporte 7 couches :
Couche 7 — Application : Interface avec les logiciels (HTTP, HTTPS, DNS, DHCP, SSH, FTP). PDU = Données (Data).
Couche 6 — Présentation : Formatage, chiffrement TLS/SSL, compression, encodage (UTF-8, JPEG).
Couche 5 — Session : Ouverture, maintien et fermeture des sessions de dialogue entre applications.
Couche 4 — Transport : Communication de bout en bout, ports logiques, fiabilité (TCP) ou rapidité (UDP). PDU = Segment (TCP) / Datagramme (UDP).
Couche 3 — Réseau : Adressage logique (IPv4/IPv6) et routage inter-réseaux (Routeur). PDU = Paquet (Packet).
Couche 2 — Liaison de données : Adressage physique MAC (48 bits), commutation (Switch), détection d'erreurs FCS/CRC (Ethernet 802.3, Wi-Fi 802.11). PDU = Trame (Frame).
Couche 1 — Physique : Transmission binaire sur le support (câble cuivre RJ45, fibre optique, radio). PDU = Bit.

• Le Modèle TCP/IP (DoD — 4 Couches) :
1. Application (regroupe OSI 5, 6, 7)
2. Transport (équivaut à OSI 4)
3. Internet (équivaut à OSI 3)
4. Accès Réseau / Liaison (regroupe OSI 1 et 2)

• Encapsulation et Désencapsulation :
Lors de l'envoi (descendant de 7 vers 1), chaque couche ajoute son propre en-tête (et une queue FCS en couche 2) :
Données → Segment (En-tête TCP + Données) → Paquet (En-tête IP + Segment) → Trame (En-tête MAC + Paquet + FCS) → Bits (010110...).
À la réception (remontant de 1 vers 7), l'hôte effectue la désencapsulation en retirant chaque en-tête pour livrer la donnée à l'application.
            """.trimIndent(),
            contentEn = """
• The 7-Layer OSI Reference Model (ISO):
Layer 7 — Application: Network services for user applications (HTTP, DNS, DHCP, SSH, SMTP). PDU = Data.
Layer 6 — Presentation: Data formatting, character encoding (UTF-8), compression, TLS/SSL encryption.
Layer 5 — Session: Establishes, manages, and terminates sessions between hosts.
Layer 4 — Transport: End-to-end delivery, port numbers, segmentation, flow control (TCP vs UDP). PDU = Segment / Datagram.
Layer 3 — Network: Logical IP addressing (IPv4/IPv6) and path determination across routers. PDU = Packet.
Layer 2 — Data Link: Physical MAC addressing (48-bit), switching, VLANs, error detection (FCS trailer). PDU = Frame.
Layer 1 — Physical: Electrical signals, light pulses, or radio waves over cables/fiber. PDU = Bits.

• The 4-Layer TCP/IP Model:
1. Application Layer (combines OSI Layers 5, 6, and 7)
2. Transport Layer (matches OSI Layer 4)
3. Internet Layer (matches OSI Layer 3)
4. Network Access / Link Layer (combines OSI Layers 1 and 2)

• Encapsulation & Decapsulation:
When sending data down the stack (L7 → L1), each layer wraps the payload with its own header:
Data → Segment (L4 TCP/UDP Header + Data) → Packet (L3 IP Header + Segment) → Frame (L2 Ethernet Header + Packet + FCS Trailer) → Bits (L1).
Upon arrival (L1 → L7), the receiver strips each header in reverse order (Decapsulation).
            """.trimIndent(),
            diagramType = "OSI_LAYERS",
            commandsBlock = "OSI Mnemonic (1->7): Please Do Not Throw Sausage Pizza Away\nPDUs: Bits (L1) -> Frame (L2) -> Packet (L3) -> Segment (L4) -> Data (L5-7)"
        ),

        // MODULE 2 LESSONS
        LessonEntity(
            id = 201,
            moduleId = 2,
            orderIndex = 1,
            titleFr = "1. Binaire, Décimal, Hexadécimal, Octal & Conversions",
            titleEn = "1. Binary, Decimal, Hexadecimal, Octal & Conversions",
            contentFr = """
• Les 4 Bases Numériques en Réseau :
- Décimal (Base 10, chiffres 0-9) : Utilisé pour la lecture humaine des adresses IPv4 (ex. 192.168.1.10).
- Binaire (Base 2, chiffres 0-1) : Langage natif des routeurs et commutateurs. Chaque octet IPv4 compte 8 bits (valeurs de 0 à 255).
- Octal (Base 8, chiffres 0-7) : Chaque chiffre octal représente exactement 3 bits binaires (utilisé notamment pour les permissions Unix/Linux chmod).
- Hexadécimal (Base 16, symboles 0-9 et A-F où A=10, B=11, C=12, D=13, E=14, F=15) : Chaque chiffre hexa représente exactement 4 bits (un quartet / nibble). Utilisé pour les adresses MAC (ex. 00:1A:2B:3C:4D:5E) et les adresses IPv6.

• Tableau des poids binaires sur 8 bits (1 Octet) :
| 128 | 64 | 32 | 16 | 8 | 4 | 2 | 1 |
Somme maximale = 128 + 64 + 32 + 16 + 8 + 4 + 2 + 1 = 255 (soit 11111111 en binaire, FF en hexa).

• Exemple de Conversion Décimal → Binaire (192) :
192 >= 128 ? Oui (bit = 1), reste 192 - 128 = 64.
64 >= 64 ? Oui (bit = 1), reste 64 - 64 = 0.
Tous les bits suivants (32, 16, 8, 4, 2, 1) valent 0.
Résultat : 192 = 11000000₂ = C0₁₆ = 300₈.
            """.trimIndent(),
            contentEn = """
• The 4 Core Number Systems in Networking:
- Decimal (Base 10, digits 0–9): Used for human-readable IPv4 dotted-decimal notation (e.g., 192.168.1.10).
- Binary (Base 2, digits 0–1): Native machine representation. Every IPv4 octet has 8 bits ranging from 0 to 255.
- Octal (Base 8, digits 0–7): Each octal digit maps to 3 binary bits (commonly seen in Linux permissions and legacy systems).
- Hexadecimal (Base 16, digits 0–9 and A–F where A=10, B=11, C=12, D=13, E=14, F=15): Each hex digit represents exactly 4 bits (a nibble). Used for 48-bit MAC addresses and 128-bit IPv6 addresses.

• 8-Bit Positional Weight Table (1 Byte / Octet):
| 128 | 64 | 32 | 16 | 8 | 4 | 2 | 1 |
Maximum 8-bit value = 128 + 64 + 32 + 16 + 8 + 4 + 2 + 1 = 255 (11111111₂ or 0xFF).

• Step-by-Step Conversion Example (Decimal 192 → Binary):
Is 192 >= 128? Yes (bit 128 = 1), remainder = 192 - 128 = 64.
Is 64 >= 64? Yes (bit 64 = 1), remainder = 64 - 64 = 0.
Remaining bits (32, 16, 8, 4, 2, 1) are all 0.
Result: 192₁₀ = 11000000₂ = C0₁₆ = 300₈.
            """.trimIndent(),
            diagramType = "BINARY_WEIGHTS",
            commandsBlock = "192.168.1.10 in Binary:\n192 = 11000000 | 168 = 10101000\n  1 = 00000001 |  10 = 00001010"
        ),
        LessonEntity(
            id = 202,
            moduleId = 2,
            orderIndex = 2,
            titleFr = "2. Opérations Binaires (AND, OR, XOR, NOT, Addition) & Unités",
            titleEn = "2. Binary Operations (AND, OR, XOR, NOT, Addition) & Data Units",
            contentFr = """
• Opérations Logiques Bit-à-Bit :
1. AND (ET logique) : Renvoie 1 uniquement si les DEUX bits valent 1 (1 AND 1 = 1, sinon 0).
   → Utilisé par les routeurs pour calculer l'adresse Réseau : IP AND Masque = Adresse Réseau.
2. OR (OU logique) : Renvoie 1 si AU MOINS UN des bits vaut 1 (0 OR 0 = 0, sinon 1).
   → Utilisé avec le masque Wildcard pour trouver l'adresse de Broadcast : IP OR Wildcard = Broadcast.
3. XOR (OU exclusif) : Renvoie 1 si les deux bits sont DIFFÉRENTS (1 XOR 0 = 1 ; 1 XOR 1 = 0).
   → Très utilisé en cryptographie et calcul de parité RAID.
4. NOT (Inversion) : Inverse chaque bit (0 devient 1, 1 devient 0).
   → NOT(Masque de sous-réseau) = Masque Wildcard.

• Addition et Soustraction Binaires :
0 + 0 = 0 | 0 + 1 = 1 | 1 + 0 = 1 | 1 + 1 = 0 (et retenue 1).
Exemple : 00000101 (5) + 00000011 (3) = 00001000 (8).

• Représentation des Données (Bits vs Octets) :
- 1 bit (b) = 0 ou 1 (les débits réseau s'expriment en bits/s : Mbps, Gbps).
- 1 Octet / Byte (B) = 8 bits (le stockage s'exprime en octets : Ko/KB, Mo/MB, Go/GB).
- 1 KB (Kilooctet décimal) = 1 000 octets (1 KiB binaire = 1 024 octets).
- 1 MB = 1 000 KB | 1 GB = 1 000 MB | 1 TB = 1 000 GB.
Astuce : Pour convertir un débit de 100 Mbps en Mo/s, divisez par 8 → 100 / 8 = 12,5 Mo/s.
            """.trimIndent(),
            contentEn = """
• Bitwise Logical Operations:
1. AND: Outputs 1 only when BOTH bits are 1 (1 AND 1 = 1; otherwise 0).
   → Used by routers to extract the Network Address: IP Address AND Subnet Mask = Network ID.
2. OR: Outputs 1 when AT LEAST ONE bit is 1 (0 OR 0 = 0; otherwise 1).
   → Used with the Wildcard mask to compute the Broadcast Address: IP OR Wildcard = Broadcast.
3. XOR (Exclusive OR): Outputs 1 when the two bits are DIFFERENT (1 XOR 0 = 1; 1 XOR 1 = 0).
   → Used in encryption ciphers and error detection.
4. NOT (Bitwise Inversion): Flips every bit (0 → 1, 1 → 0).
   → NOT(Subnet Mask) = Wildcard Mask.

• Binary Addition & Subtraction:
0 + 0 = 0 | 0 + 1 = 1 | 1 + 0 = 1 | 1 + 1 = 0 (carry 1).
Example: 00000101 (5) + 00000011 (3) = 00001000 (8).

• Data Representation (Bits vs Bytes):
- 1 bit (b) = a single 0 or 1 (network speeds are measured in bits per second: Mbps, Gbps).
- 1 Byte (B) = 8 bits (file sizes and memory are measured in Bytes: KB, MB, GB, TB).
- 1 KB = 1,000 Bytes (1 KiB = 1,024 Bytes) | 1 MB = 1,000 KB | 1 GB = 1,000 MB.
Rule of thumb: Divide network speed in Mbps by 8 to get transfer speed in MB/s (100 Mbps = 12.5 MB/s).
            """.trimIndent(),
            diagramType = "BINARY_WEIGHTS",
            commandsBlock = "192.168.1.10 AND 255.255.255.0 = 192.168.1.0 (Network)\nNOT(255.255.255.0) = 0.0.0.255 (Wildcard Mask)"
        ),

        // MODULE 3 LESSONS
        LessonEntity(
            id = 301,
            moduleId = 3,
            orderIndex = 1,
            titleFr = "1. Structure IPv4, Classes (A-E), RFC 1918 & CIDR",
            titleEn = "1. IPv4 Structure, Classes (A-E), RFC 1918 & CIDR",
            contentFr = """
• Structure d'une adresse IPv4 :
Une adresse IPv4 mesure 32 bits, divisée en 4 octets séparés par des points (ex. 192.168.1.10). Elle comporte une partie Réseau (Network ID) et une partie Hôte (Host ID) délimitées par le masque de sous-réseau.

• Les 5 Classes historiques d'adresses IPv4 :
- Classe A : 1.0.0.0 à 126.255.255.255 (1er bit = 0, masque par défaut /8 = 255.0.0.0). 127.0.0.0/8 est réservé au Loopback (127.0.0.1).
- Classe B : 128.0.0.0 à 191.255.255.255 (1ers bits = 10, masque par défaut /16 = 255.255.0.0).
- Classe C : 192.0.0.0 à 223.255.255.255 (1ers bits = 110, masque par défaut /24 = 255.255.255.0).
- Classe D : 224.0.0.0 à 239.255.255.255 (1ers bits = 1110) — Réservée au Multicast (OSPF utilise 224.0.0.5).
- Classe E : 240.0.0.0 à 255.255.255.255 — Expérimentale / Réservée.

• Adresses Privées (RFC 1918) vs Publiques :
Les adresses privées sont gratuites en LAN mais non routables sur Internet (nécessitent NAT) :
- Classe A privée : 10.0.0.0/8 (10.0.0.0 à 10.255.255.255)
- Classe B privée : 172.16.0.0/12 (172.16.0.0 à 172.31.255.255)
- Classe C privée : 192.168.0.0/16 (192.168.0.0 à 192.168.255.255)
            """.trimIndent(),
            contentEn = """
• IPv4 Address Structure:
An IPv4 address is a 32-bit number written as 4 decimal octets separated by dots (e.g., 192.168.1.10). It consists of a Network portion and a Host portion defined by the subnet mask.

• The 5 Address Classes:
- Class A: 1.0.0.0 to 126.255.255.255 (Leading bit 0, default mask /8 = 255.0.0.0). Note: 127.0.0.0/8 is reserved for Loopback testing (127.0.0.1).
- Class B: 128.0.0.0 to 191.255.255.255 (Leading bits 10, default mask /16 = 255.255.0.0).
- Class C: 192.0.0.0 to 223.255.255.255 (Leading bits 110, default mask /24 = 255.255.255.0).
- Class D: 224.0.0.0 to 239.255.255.255 (Leading bits 1110) — Multicast traffic.
- Class E: 240.0.0.0 to 255.255.255.255 — Experimental / Research.

• Private IP Ranges (RFC 1918) vs Public IPs:
Private addresses are used inside internal LANs and require NAT to reach the public Internet:
- Class A Private: 10.0.0.0/8 (10.0.0.0 – 10.255.255.255)
- Class B Private: 172.16.0.0/12 (172.16.0.0 – 172.31.255.255)
- Class C Private: 192.168.0.0/16 (192.168.0.0 – 192.168.255.255)
            """.trimIndent(),
            diagramType = "IPV4_SUBNET",
            commandsBlock = "RFC 1918 Private Blocks:\n10.0.0.0/8 | 172.16.0.0/12 | 192.168.0.0/16"
        ),
        LessonEntity(
            id = 302,
            moduleId = 3,
            orderIndex = 2,
            titleFr = "2. Subnetting : Méthode Classique, Nombre Magique & VLSM",
            titleEn = "2. Subnetting: Classic Method, Magic Number & VLSM",
            contentFr = """
• Les 3 Adresses clés d'un sous-réseau :
1. Adresse Réseau : Tous les bits hôtes sont à 0 (ex. 192.168.1.0/24). Identifie le sous-réseau.
2. Adresse de Broadcast : Tous les bits hôtes sont à 1 (ex. 192.168.1.255/24). Envoie à tous les hôtes du sous-réseau.
3. Adresses Hôtes utilisables : Toutes les adresses comprises entre Réseau+1 et Broadcast-1.
   Formule du nombre d'hôtes utilisables = 2^h - 2 (où h = 32 - CIDR est le nombre de bits hôtes).
   Exemple pour /24 : h = 32 - 24 = 8 bits → 2^8 - 2 = 256 - 2 = 254 hôtes utilisables (.1 à .254).

• Méthode du « Nombre Magique » (Pas d'incrément) :
Le Nombre Magique = 256 - (valeur décimale de l'octet intéressant du masque).
Exemple : 192.168.1.70/26.
- /26 correspond au masque 255.255.255.192.
- Nombre magique = 256 - 192 = 64.
- Les sous-réseaux avancent par pas de 64 : .0, .64, .128, .192.
- 70 se trouve dans le bloc [64 .. 127] :
  • Réseau = 192.168.1.64
  • 1er hôte = 192.168.1.65 | Dernier hôte = 192.168.1.126
  • Broadcast = 192.168.1.127 (62 hôtes utilisables).

• VLSM (Variable Length Subnet Mask) :
Permet d'attribuer des masques de tailles différentes selon les besoins réels de chaque service pour éviter le gaspillage d'IP :
Règle d'or VLSM : Toujours trier les besoins du PLUS GRAND au PLUS PETIT nombre d'hôtes avant de découper ! (ex. Direction 50 hôtes → /26, Compta 25 hôtes → /27, Lien WAN 2 hôtes → /30).
            """.trimIndent(),
            contentEn = """
• The 3 Key Addresses in Every Subnet:
1. Network Address: All host bits set to 0 (e.g., 192.168.1.0/24). Identifies the subnet itself.
2. Broadcast Address: All host bits set to 1 (e.g., 192.168.1.255/24). Reaches every host in the subnet.
3. Usable Host Range: From (Network + 1) to (Broadcast - 1).
   Usable Hosts Formula = 2^h - 2 (where h = 32 - CIDR is the number of host bits).
   Example for /24: h = 32 - 24 = 8 → 2^8 - 2 = 254 usable hosts (.1 through .254).

• The "Magic Number" Subnetting Method:
Magic Number (Block Size) = 256 - (interesting octet value of the subnet mask).
Example: 192.168.1.70/26.
- /26 equals mask 255.255.255.192.
- Magic Number = 256 - 192 = 64.
- Subnets increment by 64: .0, .64, .128, .192.
- Since 70 falls between 64 and 127:
  • Network ID = 192.168.1.64
  • First Host = 192.168.1.65 | Last Host = 192.168.1.126
  • Broadcast = 192.168.1.127 (62 usable hosts).

• VLSM (Variable Length Subnet Mask):
Allows subnetting a subnet using different prefix lengths tailored to each department's size.
Golden Rule of VLSM: Always sort subnets from LARGEST host requirement to SMALLEST before allocating blocks (e.g., 50 hosts → /26, 25 hosts → /27, point-to-point WAN 2 hosts → /30).
            """.trimIndent(),
            diagramType = "IPV4_SUBNET",
            commandsBlock = "/24 = 255.255.255.0 (254 hosts) | /25 = .128 (126 hosts)\n/26 = .192 (62 hosts) | /27 = .224 (30 hosts)\n/28 = .240 (14 hosts) | /29 = .248 (6 hosts) | /30 = .252 (2 hosts)"
        ),

        // MODULE 4 LESSONS
        LessonEntity(
            id = 401,
            moduleId = 4,
            orderIndex = 1,
            titleFr = "1. Format IPv6 (128 bits), Règles d'Abréviation & Types d'Adresses",
            titleEn = "1. IPv6 Format (128-bit), Abbreviation Rules & Address Types",
            contentFr = """
• Pourquoi IPv6 ?
IPv4 (32 bits) n'offre que 4,3 milliards d'adresses, aujourd'hui épuisées. IPv6 utilise 128 bits, soit 3,4 × 10^38 adresses (340 sextillions), éliminant le besoin de NAT et simplifiant l'en-tête pour un routage plus rapide.

• Format 128 bits en Hexadécimal :
Une adresse IPv6 s'écrit en 8 groupes (hextets) de 4 chiffres hexadécimaux séparés par deux-points `:`.
Exemple complet : 2001:0db8:0000:0000:0000:ff00:0042:8329

• Les 2 Règles d'Abréviation IPv6 :
1. Omission des zéros de tête (Leading zeros) : Dans chaque hextet, les 0 initiaux peuvent être supprimés (0db8 → db8, 0042 → 42, 0000 → 0).
2. Double deux-points `::` : UNE SEULE suite contiguë d'hextets à zéro peut être remplacée par `::`. (L'utiliser deux fois dans la même adresse est interdit car cela rendrait la longueur ambiguë).
Résultat abrégé : 2001:db8::ff00:42:8329

• Les 3 Types d'Adresses IPv6 (pas de Broadcast en IPv6 !) :
- Unicast : Identifie une seule interface.
  • Global Unicast (GUA) : Routable sur Internet, commence par `2000::/3` (ex. 2001:db8::/32).
  • Link-Local : Obligatoire sur chaque interface locale, non routable, commence par `fe80::/10`.
  • Loopback : `::1/128` (équivalent de 127.0.0.1).
- Multicast : Un vers plusieurs, commence par `ff00::/8` (remplace totalement le broadcast IPv4).
- Anycast : Adresse attribuée à plusieurs serveurs ; le routeur achemine le paquet vers le nœud le plus proche.

• Transition IPv4 → IPv6 :
1. Dual-Stack (Double pile) : Les équipements exécutent IPv4 et IPv6 simultanément (méthode recommandée).
2. Tunneling (6to4, GRE) : Encapsule le paquet IPv6 à l'intérieur d'un paquet IPv4 pour traverser un réseau IPv4.
3. NAT64 : Traduit les paquets entre hôtes IPv6 et serveurs IPv4.
            """.trimIndent(),
            contentEn = """
• Why IPv6?
IPv4's 32-bit space (4.3 billion addresses) is exhausted. IPv6 uses 128-bit addresses providing 3.4 × 10^38 addresses (340 undecillion), restoring end-to-end connectivity without NAT and featuring a streamlined header.

• 128-Bit Hexadecimal Format:
Written as 8 groups (hextets) of 4 hexadecimal digits separated by colons `:`.
Full example: 2001:0db8:0000:0000:0000:ff00:0042:8329

• The 2 IPv6 Abbreviation Rules:
1. Omit Leading Zeros: Remove leading 0s in any hextet (0db8 → db8, 0042 → 42, 0000 → 0).
2. Double Colon `::`: Replace ONE contiguous sequence of all-zero hextets with `::`. (Can only be used ONCE per address to prevent ambiguity).
Compressed result: 2001:db8::ff00:42:8329

• IPv6 Address Types (There is NO Broadcast in IPv6!):
- Unicast: One-to-one communication.
  • Global Unicast (GUA): Publicly routable, starts with `2000::/3` (e.g., 2001:db8::/32).
  • Link-Local: Auto-configured on every local link, non-routable, starts with `fe80::/10`.
  • Loopback: `::1/128`.
- Multicast: One-to-many, starts with `ff00::/8` (replaces IPv4 broadcast completely).
- Anycast: Assigned to multiple nodes; routers deliver packets to the topologically nearest instance.

• IPv4 → IPv6 Transition Mechanisms:
1. Dual-Stack: Devices run both IPv4 and IPv6 stacks natively side-by-side.
2. Tunneling: Encapsulates IPv6 packets inside IPv4 packets across IPv4-only backbones.
3. NAT64: Translates between IPv6-only clients and IPv4-only servers.
            """.trimIndent(),
            diagramType = "IPV6_HEADER",
            commandsBlock = "ipv6 unicast-routing\ninterface GigabitEthernet0/0\n ipv6 address 2001:db8:acad:1::1/64\n ipv6 address fe80::1 link-local"
        )
    )

    val quizzes = listOf(
        // MODULE 1 QUIZ (5 Questions)
        QuizQuestionEntity(
            id = 1001, moduleId = 1,
            questionFr = "Quelle couche du modèle OSI est responsable du routage logique et des adresses IP ?",
            questionEn = "Which layer of the OSI model is responsible for logical routing and IP addressing?",
            optionsFr = "Couche 2 (Liaison de données)|Couche 3 (Réseau)|Couche 4 (Transport)|Couche 7 (Application)",
            optionsEn = "Layer 2 (Data Link)|Layer 3 (Network)|Layer 4 (Transport)|Layer 7 (Application)",
            correctIndex = 1,
            explanationFr = "La couche 3 (Réseau) gère l'adressage logique (IPv4/IPv6) et la détermination du meilleur chemin par les routeurs. La PDU associée est le Paquet.",
            explanationEn = "Layer 3 (Network) handles logical addressing (IPv4/IPv6) and path determination via routers. Its PDU is the Packet."
        ),
        QuizQuestionEntity(
            id = 1002, moduleId = 1,
            questionFr = "Quel est le nom de l'unité de données (PDU) à la couche 2 (Liaison de données) du modèle OSI ?",
            questionEn = "What is the Protocol Data Unit (PDU) called at Layer 2 (Data Link) of the OSI model?",
            optionsFr = "Paquet|Segment|Trame (Frame)|Bit",
            optionsEn = "Packet|Segment|Frame|Bit",
            correctIndex = 2,
            explanationFr = "En couche 2 (Liaison de données), les données sont encapsulées dans une Trame (Frame) contenant les adresses MAC source et destination.",
            explanationEn = "At Layer 2 (Data Link), packets are encapsulated into a Frame containing source and destination MAC addresses."
        ),
        QuizQuestionEntity(
            id = 1003, moduleId = 1,
            questionFr = "Dans quelle topologie chaque équipement est-il relié individuellement à un commutateur (Switch) central ?",
            questionEn = "In which topology is every host individually connected to a central Switch?",
            optionsFr = "Topologie en Bus|Topologie en Anneau|Topologie en Étoile|Topologie Point-à-Point",
            optionsEn = "Bus Topology|Ring Topology|Star Topology|Point-to-Point Topology",
            correctIndex = 2,
            explanationFr = "La topologie en Étoile (Star) relie chaque hôte à un point central (Switch). Si un câble tombe en panne, seul ce poste est isolé.",
            explanationEn = "In a Star topology, every endpoint connects to a central switch. A single cable failure only affects that single host."
        ),
        QuizQuestionEntity(
            id = 1004, moduleId = 1,
            questionFr = "Combien de liens physiques sont nécessaires pour un maillage complet (Full Mesh) de 6 routeurs ?",
            questionEn = "How many physical links are required for a Full Mesh topology of 6 routers?",
            optionsFr = "6 liens|12 liens|15 liens|30 liens",
            optionsEn = "6 links|12 links|15 links|30 links",
            correctIndex = 2,
            explanationFr = "La formule du maillage complet est N × (N - 1) / 2. Pour 6 routeurs : 6 × 5 / 2 = 15 liens.",
            explanationEn = "The Full Mesh formula is N × (N - 1) / 2. For 6 routers: 6 × 5 / 2 = 15 links."
        ),
        QuizQuestionEntity(
            id = 1005, moduleId = 1,
            questionFr = "Quel type de réseau couvre un bâtiment ou un bureau sur une distance restreinte à très haut débit ?",
            questionEn = "Which network type covers a single office, home, or building at high speed?",
            optionsFr = "WAN|MAN|LAN|PAN",
            optionsEn = "WAN|MAN|LAN|PAN",
            correctIndex = 2,
            explanationFr = "Un LAN (Local Area Network) couvre un espace local (maison, entreprise, bâtiment) via Ethernet ou Wi-Fi.",
            explanationEn = "A LAN (Local Area Network) covers a localized area such as a home, office, or single building."
        ),

        // MODULE 2 QUIZ (5 Questions)
        QuizQuestionEntity(
            id = 2001, moduleId = 2,
            questionFr = "Quelle est la représentation binaire sur 8 bits du nombre décimal 192 ?",
            questionEn = "What is the 8-bit binary representation of the decimal number 192?",
            optionsFr = "11000000|10100000|11100000|10000001",
            optionsEn = "11000000|10100000|11100000|10000001",
            correctIndex = 0,
            explanationFr = "192 = 128 + 64. Les deux premiers bits (poids 128 et 64) sont donc à 1 et les 6 autres à 0 : 11000000.",
            explanationEn = "192 = 128 + 64, so the first two positional bits (128 and 64) are 1 and the remaining six bits are 0: 11000000."
        ),
        QuizQuestionEntity(
            id = 2002, moduleId = 2,
            questionFr = "Quelle est la valeur hexadécimale de l'octet binaire 11111111 (255 en décimal) ?",
            questionEn = "What is the hexadecimal value of the binary byte 11111111 (255 in decimal)?",
            optionsFr = "EE|FE|FF|F0",
            optionsEn = "EE|FE|FF|F0",
            correctIndex = 2,
            explanationFr = "En séparant en deux quartets de 4 bits : 1111 = 15 = F, et 1111 = 15 = F. Donc 255 = FF en hexadécimal.",
            explanationEn = "Splitting into two 4-bit nibbles: 1111 = 15 = F, and 1111 = 15 = F. Therefore 255 = 0xFF."
        ),
        QuizQuestionEntity(
            id = 2003, moduleId = 2,
            questionFr = "Quelle opération logique bit-à-bit est utilisée par un routeur entre l'adresse IP et le masque pour trouver l'adresse réseau ?",
            questionEn = "Which bitwise logical operation does a router perform between an IP address and Subnet Mask to find the Network Address?",
            optionsFr = "OR|XOR|AND|NOT",
            optionsEn = "OR|XOR|AND|NOT",
            correctIndex = 2,
            explanationFr = "L'opération logique AND (ET) conserve uniquement les bits de la partie réseau (1 AND 1 = 1) et met à 0 tous les bits hôtes.",
            explanationEn = "Bitwise AND preserves the network bits (where the mask is 1) and zeroes out all host bits (where the mask is 0)."
        ),
        QuizQuestionEntity(
            id = 2004, moduleId = 2,
            questionFr = "Quel est le résultat de l'opération binaire (1010 XOR 1100) ?",
            questionEn = "What is the result of the bitwise operation (1010 XOR 1100)?",
            optionsFr = "1000|1110|0110|0011",
            optionsEn = "1000|1110|0110|0011",
            correctIndex = 2,
            explanationFr = "XOR renvoie 1 lorsque les deux bits sont différents : (1^1=0)(0^1=1)(1^0=1)(0^0=0) → 0110.",
            explanationEn = "XOR outputs 1 when bits differ: (1^1=0)(0^1=1)(1^0=1)(0^0=0) → 0110."
        ),
        QuizQuestionEntity(
            id = 2005, moduleId = 2,
            questionFr = "À quelle vitesse maximale en Mo/s (Mégaoctets par seconde) correspond une connexion réseau de 800 Mbps ?",
            questionEn = "What is the theoretical maximum transfer rate in MB/s (Megabytes per second) of an 800 Mbps connection?",
            optionsFr = "80 Mo/s|100 Mo/s|640 Mo/s|800 Mo/s",
            optionsEn = "80 MB/s|100 MB/s|640 MB/s|800 MB/s",
            correctIndex = 1,
            explanationFr = "Puisqu'un octet (Byte) contient 8 bits, on divise le débit en Mbps par 8 : 800 Mbps / 8 = 100 Mo/s (MB/s).",
            explanationEn = "Since 1 Byte = 8 bits, divide the speed in Megabits per second by 8: 800 Mbps / 8 = 100 MB/s."
        ),

        // MODULE 3 QUIZ (5 Questions)
        QuizQuestionEntity(
            id = 3001, moduleId = 3,
            questionFr = "Pour l'adresse 192.168.1.10/24, combien d'hôtes utilisables et quelle adresse de broadcast obtient-on ?",
            questionEn = "For the address 192.168.1.10/24, how many usable hosts and what broadcast address do you get?",
            optionsFr = "254 hôtes, Broadcast 192.168.1.255|256 hôtes, Broadcast 192.168.1.255|254 hôtes, Broadcast 192.168.1.0|126 hôtes, Broadcast 192.168.1.127",
            optionsEn = "254 hosts, Broadcast 192.168.1.255|256 hosts, Broadcast 192.168.1.255|254 hosts, Broadcast 192.168.1.0|126 hosts, Broadcast 192.168.1.127",
            correctIndex = 0,
            explanationFr = "Avec /24 (255.255.255.0), il reste 8 bits hôtes : 2^8 - 2 = 254 hôtes utilisables (.1 à .254), réseau 192.168.1.0 et broadcast 192.168.1.255.",
            explanationEn = "With /24 (255.255.255.0), there are 8 host bits: 2^8 - 2 = 254 usable hosts (.1 to .254), network 192.168.1.0, and broadcast 192.168.1.255."
        ),
        QuizQuestionEntity(
            id = 3002, moduleId = 3,
            questionFr = "Laquelle de ces adresses IPv4 appartient à une plage privée RFC 1918 ?",
            questionEn = "Which of the following IPv4 addresses belongs to an RFC 1918 private range?",
            optionsFr = "172.32.10.1|11.0.0.1|172.20.15.5|192.169.1.1",
            optionsEn = "172.32.10.1|11.0.0.1|172.20.15.5|192.169.1.1",
            correctIndex = 2,
            explanationFr = "La plage privée de classe B couvre 172.16.0.0 à 172.31.255.255 (/12). 172.20.15.5 est donc bien privée (172.32 est publique).",
            explanationEn = "The Class B RFC 1918 private block spans 172.16.0.0 to 172.31.255.255 (/12). Thus 172.20.15.5 is private."
        ),
        QuizQuestionEntity(
            id = 3003, moduleId = 3,
            questionFr = "Quel masque CIDR offre exactement 2 adresses d'hôtes utilisables pour un lien point-à-point entre deux routeurs ?",
            questionEn = "Which CIDR prefix provides exactly 2 usable host addresses for a point-to-point router link?",
            optionsFr = "/28|/29|/30|/32",
            optionsEn = "/28|/29|/30|/32",
            correctIndex = 2,
            explanationFr = "Un préfixe /30 laisse 32 - 30 = 2 bits hôtes : 2^2 - 2 = 4 - 2 = 2 hôtes utilisables (masque 255.255.255.252).",
            explanationEn = "A /30 prefix leaves 32 - 30 = 2 host bits: 2^2 - 2 = 2 usable host addresses (mask 255.255.255.252)."
        ),
        QuizQuestionEntity(
            id = 3004, moduleId = 3,
            questionFr = "Avec la méthode du Nombre Magique, quelle est l'adresse réseau de l'hôte 192.168.10.130/26 ?",
            questionEn = "Using the Magic Number method, what is the network address for host 192.168.10.130/26?",
            optionsFr = "192.168.10.64|192.168.10.128|192.168.10.192|192.168.10.0",
            optionsEn = "192.168.10.64|192.168.10.128|192.168.10.192|192.168.10.0",
            correctIndex = 1,
            explanationFr = "/26 = 255.255.255.192. Nombre magique = 256 - 192 = 64. Les sous-réseaux sont .0, .64, .128, .192. 130 appartient au sous-réseau 192.168.10.128.",
            explanationEn = "/26 = 255.255.255.192. Magic number = 256 - 192 = 64. Multiples are .0, .64, .128, .192. Host .130 falls inside subnet 192.168.10.128."
        ),
        QuizQuestionEntity(
            id = 3005, moduleId = 3,
            questionFr = "En VLSM, dans quel ordre faut-il toujours attribuer les sous-réseaux ?",
            questionEn = "When designing a VLSM addressing plan, in what order must subnets be allocated?",
            optionsFr = "Du plus petit au plus grand besoin|Du plus grand au plus petit besoin en hôtes|Par ordre alphabétique des départements|De manière aléatoire",
            optionsEn = "Smallest to largest host requirement|Largest to smallest host requirement|Alphabetical order|Random order",
            correctIndex = 1,
            explanationFr = "En VLSM, on trie toujours du plus grand au plus petit besoin en hôtes afin d'aligner proprement les blocs binaires sans chevauchement.",
            explanationEn = "Always allocate VLSM blocks from largest host requirement to smallest to prevent block boundary overlap."
        ),

        // MODULE 4 QUIZ (5 Questions)
        QuizQuestionEntity(
            id = 4001, moduleId = 4,
            questionFr = "Quelle est la forme abrégée valide de l'adresse IPv6 2001:0db8:0000:0000:0042:0000:0000:0001 ?",
            questionEn = "What is the valid compressed form of IPv6 address 2001:0db8:0000:0000:0042:0000:0000:0001?",
            optionsFr = "2001:db8::42::1|2001:db8::42:0:0:1|2001:db8:0:0:42:1|2001:0db8::42::0001",
            optionsEn = "2001:db8::42::1|2001:db8::42:0:0:1|2001:db8:0:0:42:1|2001:0db8::42::0001",
            correctIndex = 1,
            explanationFr = "Le symbole :: ne peut être utilisé qu'une seule fois par adresse IPv6. On remplace un bloc par :: et l'autre par :0:0: → 2001:db8::42:0:0:1.",
            explanationEn = "The double colon :: can only appear ONCE in an IPv6 address. Compressing the first zero block yields 2001:db8::42:0:0:1."
        ),
        QuizQuestionEntity(
            id = 4002, moduleId = 4,
            questionFr = "Quel préfixe identifie une adresse IPv6 Link-Local ?",
            questionEn = "Which prefix identifies an IPv6 Link-Local address?",
            optionsFr = "2000::/3|FE80::/10|FF00::/8|FC00::/7",
            optionsEn = "2000::/3|FE80::/10|FF00::/8|FC00::/7",
            correctIndex = 1,
            explanationFr = "Les adresses Link-Local IPv6 commencent par FE80::/10 et servent aux communications sur le segment local sans jamais être routées.",
            explanationEn = "IPv6 Link-Local addresses start with FE80::/10 and are used exclusively on the local link (routers never forward them)."
        ),
        QuizQuestionEntity(
            id = 4003, moduleId = 4,
            questionFr = "Quel mode de communication IPv4 a été supprimé en IPv6 et remplacé par le Multicast ?",
            questionEn = "Which IPv4 communication type was eliminated in IPv6 and replaced by Multicast?",
            optionsFr = "Unicast|Anycast|Broadcast|Loopback",
            optionsEn = "Unicast|Anycast|Broadcast|Loopback",
            correctIndex = 2,
            explanationFr = "IPv6 ne comporte plus de Broadcast afin d'éviter les tempêtes de diffusion ; il utilise des groupes Multicast ciblés (FF00::/8).",
            explanationEn = "IPv6 eliminates Broadcast completely to prevent broadcast storms, using targeted Multicast groups (FF00::/8) instead."
        ),
        QuizQuestionEntity(
            id = 4004, moduleId = 4,
            questionFr = "Combien de bits compose une adresse IPv6 complète ?",
            questionEn = "How many bits make up a complete IPv6 address?",
            optionsFr = "32 bits|48 bits|64 bits|128 bits",
            optionsEn = "32 bits|48 bits|64 bits|128 bits",
            correctIndex = 3,
            explanationFr = "Une adresse IPv6 est codée sur 128 bits (8 hextets de 16 bits chacun).",
            explanationEn = "An IPv6 address is 128 bits long, divided into 8 hextets of 16 bits each."
        ),
        QuizQuestionEntity(
            id = 4005, moduleId = 4,
            questionFr = "Quelle technique de transition fait tourner IPv4 et IPv6 simultanément sur le même routeur ou poste ?",
            questionEn = "Which transition technique runs both IPv4 and IPv6 protocol stacks simultaneously on the same device?",
            optionsFr = "NAT64|Dual-Stack (Double pile)|Tunneling GRE|DHCPv6",
            optionsEn = "NAT64|Dual-Stack|GRE Tunneling|DHCPv6",
            correctIndex = 1,
            explanationFr = "Le Dual-Stack (Double pile) permet à chaque interface de posséder à la fois une adresse IPv4 et une adresse IPv6 nativement.",
            explanationEn = "Dual-Stack allows devices and routers to run IPv4 and IPv6 natively at the same time."
        )
    )
}
