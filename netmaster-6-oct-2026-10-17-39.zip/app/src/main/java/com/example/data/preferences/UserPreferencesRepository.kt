package com.example.data.preferences

import android.content.Context
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.Locale

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "netmaster_prefs")

data class UserPrefs(
    val language: String = "fr",
    val themeMode: String = "DARK",
    val onboardingDone: Boolean = false,
    val dailyReminder: Boolean = false,
    val bonusXp: Int = 0
)

class UserPreferencesRepository(private val context: Context) {

    companion object {
        private val KEY_LANGUAGE = stringPreferencesKey("language_code")
        private val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
        private val KEY_ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        private val KEY_DAILY_REMINDER = booleanPreferencesKey("daily_reminder")
        private val KEY_BONUS_XP = intPreferencesKey("bonus_xp")

        fun applyAppLocale(langCode: String) {
            val normalized = if (langCode.startsWith("en", ignoreCase = true)) "en" else "fr"
            val locale = Locale.forLanguageTag(normalized)
            Locale.setDefault(locale)
            AppCompatDelegate.setApplicationLocales(
                LocaleListCompat.forLanguageTags(normalized)
            )
        }

        fun createLocalizedContext(baseContext: Context, langCode: String): Context {
            val normalized = if (langCode.startsWith("en", ignoreCase = true)) "en" else "fr"
            val locale = Locale.forLanguageTag(normalized)
            val config = Configuration(baseContext.resources.configuration)
            config.setLocale(locale)
            config.setLayoutDirection(locale)
            return baseContext.createConfigurationContext(config)
        }
    }

    private fun getSystemDefaultLanguage(): String {
        val sysLang = Locale.getDefault().language.lowercase()
        return if (sysLang.startsWith("en")) "en" else "fr"
    }

    val userPrefsFlow: Flow<UserPrefs> = context.dataStore.data.map { prefs ->
        val defaultLang = getSystemDefaultLanguage()
        UserPrefs(
            language = prefs[KEY_LANGUAGE] ?: defaultLang,
            themeMode = prefs[KEY_THEME_MODE] ?: "DARK",
            onboardingDone = prefs[KEY_ONBOARDING_DONE] ?: false,
            dailyReminder = prefs[KEY_DAILY_REMINDER] ?: false,
            bonusXp = prefs[KEY_BONUS_XP] ?: 0
        )
    }

    suspend fun getSavedLanguageOrDefault(): String {
        val prefs = context.dataStore.data.first()
        return prefs[KEY_LANGUAGE] ?: getSystemDefaultLanguage()
    }

    suspend fun setLanguage(langCode: String) {
        val normalized = if (langCode.startsWith("en", ignoreCase = true)) "en" else "fr"
        context.dataStore.edit { prefs ->
            prefs[KEY_LANGUAGE] = normalized
        }
        applyAppLocale(normalized)
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_THEME_MODE] = mode
        }
    }

    suspend fun completeOnboarding() {
        context.dataStore.edit { prefs ->
            prefs[KEY_ONBOARDING_DONE] = true
        }
    }

    suspend fun setDailyReminder(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_DAILY_REMINDER] = enabled
        }
    }

    suspend fun addBonusXp(points: Int) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_BONUS_XP] ?: 0
            prefs[KEY_BONUS_XP] = current + points
        }
    }

    suspend fun resetBonusXp() {
        context.dataStore.edit { prefs ->
            prefs[KEY_BONUS_XP] = 0
        }
    }
}
