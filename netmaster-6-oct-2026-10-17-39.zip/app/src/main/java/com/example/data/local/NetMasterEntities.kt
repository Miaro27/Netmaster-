package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "modules")
data class ModuleEntity(
    @PrimaryKey val id: Int,
    val number: Int,
    val level: Int, // 1 = Beginner, 2 = Intermediate, 3 = Advanced
    val iconType: String,
    val titleFr: String,
    val titleEn: String,
    val descriptionFr: String,
    val descriptionEn: String,
    val bestQuizScore: Int = -1,
    val totalQuestions: Int = 5
) {
    fun getTitle(lang: String): String = if (lang == "en") titleEn else titleFr
    fun getDescription(lang: String): String = if (lang == "en") descriptionEn else descriptionFr
}

@Entity(tableName = "lessons")
data class LessonEntity(
    @PrimaryKey val id: Int,
    val moduleId: Int,
    val orderIndex: Int,
    val titleFr: String,
    val titleEn: String,
    val contentFr: String,
    val contentEn: String,
    val diagramType: String,
    val commandsBlock: String,
    val isCompleted: Boolean = false,
    val isBookmarked: Boolean = false,
    val personalNote: String = ""
) {
    fun getTitle(lang: String): String = if (lang == "en") titleEn else titleFr
    fun getContent(lang: String): String = if (lang == "en") contentEn else contentFr
}

@Entity(tableName = "quiz_questions")
data class QuizQuestionEntity(
    @PrimaryKey val id: Int,
    val moduleId: Int,
    val questionFr: String,
    val questionEn: String,
    val optionsFr: String, // Pipe-separated 4 choices
    val optionsEn: String, // Pipe-separated 4 choices
    val correctIndex: Int,
    val explanationFr: String,
    val explanationEn: String
) {
    fun getQuestion(lang: String): String = if (lang == "en") questionEn else questionFr
    fun getOptions(lang: String): List<String> =
        (if (lang == "en") optionsEn else optionsFr).split("|")
    fun getExplanation(lang: String): String = if (lang == "en") explanationEn else explanationFr
}
