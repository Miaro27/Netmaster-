package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface NetMasterDao {

    @Query("SELECT * FROM modules ORDER BY number ASC")
    fun getAllModules(): Flow<List<ModuleEntity>>

    @Query("SELECT * FROM lessons ORDER BY moduleId ASC, orderIndex ASC")
    fun getAllLessons(): Flow<List<LessonEntity>>

    @Query("SELECT * FROM lessons WHERE moduleId = :moduleId ORDER BY orderIndex ASC")
    fun getLessonsForModule(moduleId: Int): Flow<List<LessonEntity>>

    @Query("SELECT * FROM quiz_questions ORDER BY moduleId ASC, id ASC")
    fun getAllQuizQuestions(): Flow<List<QuizQuestionEntity>>

    @Query("SELECT * FROM quiz_questions WHERE moduleId = :moduleId ORDER BY id ASC")
    fun getQuizQuestionsForModule(moduleId: Int): Flow<List<QuizQuestionEntity>>

    @Query("SELECT COUNT(*) FROM modules")
    suspend fun getModuleCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertModules(modules: List<ModuleEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLessons(lessons: List<LessonEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuizQuestions(questions: List<QuizQuestionEntity>)

    @Query("UPDATE lessons SET isCompleted = :completed WHERE id = :lessonId")
    suspend fun setLessonCompleted(lessonId: Int, completed: Boolean)

    @Query("UPDATE lessons SET isBookmarked = :bookmarked WHERE id = :lessonId")
    suspend fun setLessonBookmarked(lessonId: Int, bookmarked: Boolean)

    @Query("UPDATE lessons SET personalNote = :note WHERE id = :lessonId")
    suspend fun updatePersonalNote(lessonId: Int, note: String)

    @Query("UPDATE modules SET bestQuizScore = :score WHERE id = :moduleId AND :score > bestQuizScore")
    suspend fun updateBestQuizScore(moduleId: Int, score: Int)

    @Query("UPDATE lessons SET isCompleted = 0")
    suspend fun resetAllLessonsCompletion()

    @Query("UPDATE modules SET bestQuizScore = -1")
    suspend fun resetAllQuizScores()
}
