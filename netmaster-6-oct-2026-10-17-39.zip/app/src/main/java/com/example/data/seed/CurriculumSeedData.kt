package com.example.data.seed

import com.example.data.local.LessonEntity
import com.example.data.local.ModuleEntity
import com.example.data.local.QuizQuestionEntity

data class FlashcardItem(
    val id: Int,
    val categoryFr: String,
    val categoryEn: String,
    val frontFr: String,
    val frontEn: String,
    val backFr: String,
    val backEn: String
) {
    fun getCategory(lang: String) = if (lang == "en") categoryEn else categoryFr
    fun getFront(lang: String) = if (lang == "en") frontEn else frontFr
    fun getBack(lang: String) = if (lang == "en") backEn else backFr
}

object CurriculumSeedData {

    val allModules: List<ModuleEntity> =
        ModulesSeedM1ToM4.modules +
        ModulesSeedM5ToM8.modules +
        ModulesSeedM9ToM13.modules

    val allLessons: List<LessonEntity> =
        ModulesSeedM1ToM4.lessons +
        ModulesSeedM5ToM8.lessons +
        ModulesSeedM9ToM13.lessons

    val allQuizQuestions: List<QuizQuestionEntity> =
        ModulesSeedM1ToM4.quizzes +
        ModulesSeedM5ToM8.quizzes +
        ModulesSeedM9ToM13.quizzes

    val flashcards: List<FlashcardItem> = listOf(
        FlashcardItem(
            id = 1,
            categoryFr = "Modèle OSI",
            categoryEn = "OSI Model",
            frontFr = "Quelles sont les 7 couches du modèle OSI (de 1 à 7) et leurs PDUs ?",
            frontEn = "What are the 7 layers of the OSI Model (1 to 7) and their PDUs?",
            backFr = "1. Physique (Bit)\n2. Liaison de données (Trame / Frame)\n3. Réseau (Paquet / Packet)\n4. Transport (Segment / Datagramme)\n5. Session (Données)\n6. Présentation (Données)\n7. Application (Données)",
            backEn = "1. Physical (Bit)\n2. Data Link (Frame)\n3. Network (Packet)\n4. Transport (Segment / Datagram)\n5. Session (Data)\n6. Presentation (Data)\n7. Application (Data)"
        ),
        FlashcardItem(
            id = 2,
            categoryFr = "Adressage IPv4",
            categoryEn = "IPv4 Addressing",
            frontFr = "Quelles sont les 3 plages d'adresses IPv4 privées définies par la RFC 1918 ?",
            frontEn = "What are the 3 private IPv4 address ranges defined in RFC 1918?",
            backFr = "• Classe A : 10.0.0.0/8 (10.0.0.0 – 10.255.255.255)\n• Classe B : 172.16.0.0/12 (172.16.0.0 – 172.31.255.255)\n• Classe C : 192.168.0.0/16 (192.168.0.0 – 192.168.255.255)",
            backEn = "• Class A: 10.0.0.0/8 (10.0.0.0 – 10.255.255.255)\n• Class B: 172.16.0.0/12 (172.16.0.0 – 172.31.255.255)\n• Class C: 192.168.0.0/16 (192.168.0.0 – 192.168.255.255)"
        ),
        FlashcardItem(
            id = 3,
            categoryFr = "Ports TCP/UDP",
            categoryEn = "TCP/UDP Ports",
            frontFr = "Quels sont les numéros de ports de FTP, SSH, Telnet, SMTP, DNS, DHCP, HTTP et HTTPS ?",
            frontEn = "What are the port numbers for FTP, SSH, Telnet, SMTP, DNS, DHCP, HTTP, and HTTPS?",
            backFr = "• FTP : TCP 20/21 | SSH : TCP 22 | Telnet : TCP 23\n• SMTP : TCP 25 | DNS : UDP/TCP 53\n• DHCP : UDP 67 (Serveur) / 68 (Client)\n• HTTP : TCP 80 | HTTPS : TCP 443",
            backEn = "• FTP: TCP 20/21 | SSH: TCP 22 | Telnet: TCP 23\n• SMTP: TCP 25 | DNS: UDP/TCP 53\n• DHCP: UDP 67 (Server) / 68 (Client)\n• HTTP: TCP 80 | HTTPS: TCP 443"
        ),
        FlashcardItem(
            id = 4,
            categoryFr = "Routage Cisco",
            categoryEn = "Cisco Routing",
            frontFr = "Quelles sont les Distances Administratives (AD) par défaut sur Cisco IOS ?",
            frontEn = "What are the default Administrative Distances (AD) on Cisco IOS?",
            backFr = "• Directement Connecté : 0\n• Route Statique : 1\n• eBGP Externe : 20\n• EIGRP Interne : 90\n• OSPF : 110\n• IS-IS : 115\n• RIPv2 : 120",
            backEn = "• Directly Connected: 0\n• Static Route: 1\n• External BGP (eBGP): 20\n• Internal EIGRP: 90\n• OSPF: 110\n• IS-IS: 115\n• RIPv2: 120"
        ),
        FlashcardItem(
            id = 5,
            categoryFr = "Subnetting",
            categoryEn = "Subnetting",
            frontFr = "Combien d'hôtes utilisables offrent les préfixes /24, /25, /26, /27, /28, /29 et /30 ?",
            frontEn = "How many usable hosts are in /24, /25, /26, /27, /28, /29, and /30 subnets?",
            backFr = "• /24 (.0) = 254 hôtes\n• /25 (.128) = 126 hôtes\n• /26 (.192) = 62 hôtes\n• /27 (.224) = 30 hôtes\n• /28 (.240) = 14 hôtes\n• /29 (.248) = 6 hôtes\n• /30 (.252) = 2 hôtes (Point-à-Point)",
            backEn = "• /24 (.0) = 254 hosts\n• /25 (.128) = 126 hosts\n• /26 (.192) = 62 hosts\n• /27 (.224) = 30 hosts\n• /28 (.240) = 14 hosts\n• /29 (.248) = 6 hosts\n• /30 (.252) = 2 hosts (Point-to-Point)"
        ),
        FlashcardItem(
            id = 6,
            categoryFr = "IPv6",
            categoryEn = "IPv6",
            frontFr = "Quels sont les préfixes IPv6 pour Global Unicast, Link-Local, Multicast et Loopback ?",
            frontEn = "What are the IPv6 prefixes for Global Unicast, Link-Local, Multicast, and Loopback?",
            backFr = "• Global Unicast (GUA) : 2000::/3\n• Link-Local : FE80::/10\n• Multicast : FF00::/8\n• Unique Local (ULA) : FC00::/7\n• Loopback : ::1/128",
            backEn = "• Global Unicast (GUA): 2000::/3\n• Link-Local: FE80::/10\n• Multicast: FF00::/8\n• Unique Local (ULA): FC00::/7\n• Loopback: ::1/128"
        ),
        FlashcardItem(
            id = 7,
            categoryFr = "Commutation & VLAN",
            categoryEn = "Switching & VLANs",
            frontFr = "Quelle est la différence entre LACP et PAgP pour EtherChannel ?",
            frontEn = "What is the difference between LACP and PAgP for EtherChannel?",
            backFr = "• LACP (IEEE 802.3ad) : Standard ouvert multi-constructeurs (Modes : Active / Passive).\n• PAgP : Protocole propriétaire Cisco (Modes : Desirable / Auto).",
            backEn = "• LACP (IEEE 802.3ad): Open industry standard (Modes: Active / Passive).\n• PAgP: Cisco proprietary protocol (Modes: Desirable / Auto)."
        ),
        FlashcardItem(
            id = 8,
            categoryFr = "Services & Sécurité",
            categoryEn = "Services & Security",
            frontFr = "Que signifie l'acronyme DORA en DHCP et comment sécuriser DHCP sur un switch ?",
            frontEn = "What does DORA stand for in DHCP, and how do you secure DHCP on a switch?",
            backFr = "• DORA : Discover → Offer → Request → Acknowledge.\n• Sécurité : Activer `ip dhcp snooping` sur le switch et marquer uniquement le port relié au vrai serveur comme `ip dhcp snooping trust`.",
            backEn = "• DORA: Discover → Offer → Request → Acknowledge.\n• Security: Enable `ip dhcp snooping` on the switch and configure only the legitimate uplink as `ip dhcp snooping trust`."
        )
    )
}
