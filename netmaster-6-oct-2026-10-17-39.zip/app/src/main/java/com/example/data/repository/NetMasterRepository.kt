package com.example.data.repository

import com.example.data.local.LessonEntity
import com.example.data.local.ModuleEntity
import com.example.data.local.NetMasterDao
import com.example.data.local.QuizQuestionEntity
import com.example.data.seed.CurriculumSeedData
import kotlinx.coroutines.flow.Flow

class NetMasterRepository(private val dao: NetMasterDao) {

    val allModules: Flow<List<ModuleEntity>> = dao.getAllModules()
    val allLessons: Flow<List<LessonEntity>> = dao.getAllLessons()
    val allQuizQuestions: Flow<List<QuizQuestionEntity>> = dao.getAllQuizQuestions()

    suspend fun ensureSeeded() {
        val count = dao.getModuleCount()
        if (count < CurriculumSeedData.allModules.size) {
            dao.insertModules(CurriculumSeedData.allModules)
            dao.insertLessons(CurriculumSeedData.allLessons)
            dao.insertQuizQuestions(CurriculumSeedData.allQuizQuestions)
        }
    }

    suspend fun toggleLessonCompleted(lessonId: Int, completed: Boolean) {
        dao.setLessonCompleted(lessonId, completed)
    }

    suspend fun toggleLessonBookmark(lessonId: Int, bookmarked: Boolean) {
        dao.setLessonBookmarked(lessonId, bookmarked)
    }

    suspend fun savePersonalNote(lessonId: Int, note: String) {
        dao.updatePersonalNote(lessonId, note)
    }

    suspend fun recordModuleQuizScore(moduleId: Int, score: Int) {
        dao.updateBestQuizScore(moduleId, score)
    }

    suspend fun resetAllProgress() {
        dao.resetAllLessonsCompletion()
        dao.resetAllQuizScores()
    }
}
