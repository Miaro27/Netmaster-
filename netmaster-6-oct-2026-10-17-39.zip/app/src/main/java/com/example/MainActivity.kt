package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.example.data.preferences.UserPreferencesRepository
import com.example.ui.screens.BaseConverterScreen
import com.example.ui.screens.CiscoCliSimulatorScreen
import com.example.ui.screens.FavoritesAndNotesScreen
import com.example.ui.screens.FlashcardsScreen
import com.example.ui.screens.GlobalSearchScreen
import com.example.ui.screens.HomeCoursesScreen
import com.example.ui.screens.InteractiveQuizScreen
import com.example.ui.screens.LessonDetailScreen
import com.example.ui.screens.ModuleDetailScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.ProgressAndProfileScreen
import com.example.ui.screens.QuizHubScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.SubnetCalculatorScreen
import com.example.ui.screens.ToolsHubScreen
import com.example.ui.screens.VlsmCalculatorScreen
import com.example.ui.screens.WildcardCalculatorScreen
import com.example.netmaster.di.AppModule
import com.example.netmaster.viewmodel.NetMasterViewModelFactory
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.NetMasterTheme
import com.example.ui.theme.TechBluePrimary
import com.example.ui.viewmodel.NetMasterUiState
import com.example.ui.viewmodel.NetMasterViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: NetMasterViewModel by viewModels {
        NetMasterViewModelFactory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Restore saved locale in onCreate()
        val prefsRepo = AppModule.provideUserPreferencesRepository(applicationContext)
        lifecycleScope.launch {
            val savedLang = prefsRepo.getSavedLanguageOrDefault()
            val savedLocale = LocaleListCompat.forLanguageTags(savedLang)
            AppCompatDelegate.setApplicationLocales(savedLocale)
        }

        enableEdgeToEdge()
        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val baseContext = LocalContext.current
            val lang = uiState.prefs.language
            val localizedContext = remember(baseContext, lang) {
                UserPreferencesRepository.createLocalizedContext(baseContext, lang)
            }

            CompositionLocalProvider(
                LocalContext provides localizedContext,
                LocalConfiguration provides localizedContext.resources.configuration
            ) {
                NetMasterTheme(themeMode = uiState.prefs.themeMode) {
                    NetMasterAppRoot(
                        uiState = uiState,
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}

sealed class ActiveSubScreen {
    data object None : ActiveSubScreen()
    data class ModuleDetail(val moduleId: Int) : ActiveSubScreen()
    data class LessonDetail(val lessonId: Int) : ActiveSubScreen()
    data class ModuleQuiz(val moduleId: Int) : ActiveSubScreen()
    data object RandomQuiz : ActiveSubScreen()
    data object TimedExam : ActiveSubScreen()
    data class ToolScreen(val toolId: String) : ActiveSubScreen()
    data object GlobalSearch : ActiveSubScreen()
    data object FavoritesNotes : ActiveSubScreen()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetMasterAppRoot(
    uiState: NetMasterUiState,
    viewModel: NetMasterViewModel
) {
    var showSplash by rememberSaveable { mutableStateOf(true) }
    var currentTab by rememberSaveable { mutableIntStateOf(0) }
    var subScreen by remember { mutableStateOf<ActiveSubScreen>(ActiveSubScreen.None) }

    val lang = uiState.prefs.language

    if (showSplash) {
        SplashScreen(onFinished = { showSplash = false })
        return
    }

    if (!uiState.prefs.onboardingDone) {
        OnboardingScreen(
            currentLanguage = lang,
            onSelectLanguage = { viewModel.switchLanguage(it) },
            onCompleteOnboarding = { viewModel.completeOnboarding() }
        )
        return
    }

    BackHandler(enabled = subScreen != ActiveSubScreen.None || currentTab != 0) {
        when (val current = subScreen) {
            is ActiveSubScreen.LessonDetail -> {
                val lesson = uiState.lessons.find { it.id == current.lessonId }
                subScreen = if (lesson != null) {
                    ActiveSubScreen.ModuleDetail(lesson.moduleId)
                } else {
                    ActiveSubScreen.None
                }
            }
            is ActiveSubScreen.None -> {
                currentTab = 0
            }
            else -> {
                subScreen = ActiveSubScreen.None
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Router,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.app_name),
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { subScreen = ActiveSubScreen.GlobalSearch },
                        modifier = Modifier.testTag("top_bar_search_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = stringResource(R.string.search_title)
                        )
                    }
                    IconButton(
                        onClick = { subScreen = ActiveSubScreen.FavoritesNotes },
                        modifier = Modifier.testTag("top_bar_favorites_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bookmark,
                            contentDescription = stringResource(R.string.favorites_and_notes)
                        )
                    }
                    // Instant Language Switcher Pill (Globe Icon + FR/EN)
                    Row(
                        modifier = Modifier
                            .padding(end = 10.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(TechBluePrimary.copy(alpha = 0.18f))
                            .border(1.dp, CyanAccent.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                            .clickable { viewModel.toggleLanguageInstant() }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("top_bar_lang_switcher"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = stringResource(R.string.switch_language_desc),
                            tint = CyanAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (lang == "en") {
                                stringResource(R.string.english_code)
                            } else {
                                stringResource(R.string.french_code)
                            },
                            style = MaterialTheme.typography.labelLarge,
                            color = CyanAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar {
                val tabs = listOf(
                    Triple(0, R.string.courses, Icons.Default.MenuBook),
                    Triple(1, R.string.quiz, Icons.Default.Quiz),
                    Triple(2, R.string.tools, Icons.Default.Build),
                    Triple(3, R.string.progress, Icons.Default.BarChart),
                    Triple(4, R.string.settings, Icons.Default.Settings)
                )
                tabs.forEach { (idx, labelRes, icon) ->
                    NavigationBarItem(
                        selected = currentTab == idx && subScreen == ActiveSubScreen.None,
                        onClick = {
                            subScreen = ActiveSubScreen.None
                            currentTab = idx
                        },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = stringResource(labelRes)
                            )
                        },
                        label = { Text(stringResource(labelRes)) },
                        modifier = Modifier.testTag("bottom_nav_$idx")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val active = subScreen) {
                is ActiveSubScreen.ModuleDetail -> {
                    val module = uiState.modules.find { it.id == active.moduleId }
                    val modLessons = uiState.lessons.filter { it.moduleId == active.moduleId }
                    if (module != null) {
                        ModuleDetailScreen(
                            module = module,
                            lessons = modLessons,
                            lang = lang,
                            onBack = { subScreen = ActiveSubScreen.None },
                            onOpenLesson = { lessonId -> subScreen = ActiveSubScreen.LessonDetail(lessonId) },
                            onStartModuleQuiz = { modId -> subScreen = ActiveSubScreen.ModuleQuiz(modId) }
                        )
                    }
                }
                is ActiveSubScreen.LessonDetail -> {
                    val lesson = uiState.lessons.find { it.id == active.lessonId }
                    if (lesson != null) {
                        val modLessons = uiState.lessons.filter { it.moduleId == lesson.moduleId }
                        LessonDetailScreen(
                            lesson = lesson,
                            moduleLessons = modLessons,
                            lang = lang,
                            onBack = { subScreen = ActiveSubScreen.ModuleDetail(lesson.moduleId) },
                            onToggleComplete = { done -> viewModel.toggleLessonCompleted(lesson.id, done) },
                            onToggleBookmark = { saved -> viewModel.toggleLessonBookmark(lesson.id, saved) },
                            onSaveNote = { note -> viewModel.savePersonalNote(lesson.id, note) },
                            onNavigateLesson = { nextId -> subScreen = ActiveSubScreen.LessonDetail(nextId) }
                        )
                    }
                }
                is ActiveSubScreen.ModuleQuiz -> {
                    val module = uiState.modules.find { it.id == active.moduleId }
                    val questions = uiState.quizQuestions.filter { it.moduleId == active.moduleId }
                    InteractiveQuizScreen(
                        title = module?.getTitle(lang) ?: stringResource(R.string.quiz),
                        questions = questions,
                        isExamMode = false,
                        lang = lang,
                        onFinishScore = { score -> viewModel.recordQuizResult(active.moduleId, score) },
                        onBack = { subScreen = ActiveSubScreen.None }
                    )
                }
                is ActiveSubScreen.RandomQuiz -> {
                    val randomQuestions = remember(uiState.quizQuestions) {
                        uiState.quizQuestions.shuffled().take(10)
                    }
                    InteractiveQuizScreen(
                        title = stringResource(R.string.random_quiz_card_title),
                        questions = randomQuestions,
                        isExamMode = false,
                        lang = lang,
                        onFinishScore = { score -> viewModel.recordQuizResult(null, score) },
                        onBack = { subScreen = ActiveSubScreen.None }
                    )
                }
                is ActiveSubScreen.TimedExam -> {
                    val examQuestions = remember(uiState.quizQuestions) {
                        uiState.quizQuestions.shuffled().take(15)
                    }
                    InteractiveQuizScreen(
                        title = stringResource(R.string.exam_mode_card_title),
                        questions = examQuestions,
                        isExamMode = true,
                        lang = lang,
                        onFinishScore = { score -> viewModel.recordQuizResult(null, score) },
                        onBack = { subScreen = ActiveSubScreen.None }
                    )
                }
                is ActiveSubScreen.ToolScreen -> {
                    when (active.toolId) {
                        "SUBNET" -> SubnetCalculatorScreen(lang = lang, onBack = { subScreen = ActiveSubScreen.None })
                        "BASE" -> BaseConverterScreen(onBack = { subScreen = ActiveSubScreen.None })
                        "VLSM" -> VlsmCalculatorScreen(onBack = { subScreen = ActiveSubScreen.None })
                        "WILDCARD" -> WildcardCalculatorScreen(onBack = { subScreen = ActiveSubScreen.None })
                        "CLI" -> CiscoCliSimulatorScreen(lang = lang, onBack = { subScreen = ActiveSubScreen.None })
                        "FLASHCARDS" -> FlashcardsScreen(
                            flashcards = uiState.flashcards,
                            lang = lang,
                            onBack = { subScreen = ActiveSubScreen.None }
                        )
                        "RANDOM_QUIZ" -> {
                            subScreen = ActiveSubScreen.RandomQuiz
                        }
                    }
                }
                is ActiveSubScreen.GlobalSearch -> {
                    GlobalSearchScreen(
                        lessons = uiState.lessons,
                        questions = uiState.quizQuestions,
                        lang = lang,
                        onBack = { subScreen = ActiveSubScreen.None },
                        onOpenLesson = { lessonId -> subScreen = ActiveSubScreen.LessonDetail(lessonId) }
                    )
                }
                is ActiveSubScreen.FavoritesNotes -> {
                    FavoritesAndNotesScreen(
                        lessons = uiState.lessons,
                        lang = lang,
                        onBack = { subScreen = ActiveSubScreen.None },
                        onOpenLesson = { lessonId -> subScreen = ActiveSubScreen.LessonDetail(lessonId) }
                    )
                }
                is ActiveSubScreen.None -> {
                    when (currentTab) {
                        0 -> HomeCoursesScreen(
                            modules = uiState.modules,
                            lessons = uiState.lessons,
                            lang = lang,
                            totalXp = uiState.totalXp,
                            userLevel = uiState.userLevel,
                            onSelectModule = { modId -> subScreen = ActiveSubScreen.ModuleDetail(modId) },
                            onOpenExamMode = { subScreen = ActiveSubScreen.TimedExam },
                            onOpenFlashcards = { subScreen = ActiveSubScreen.ToolScreen("FLASHCARDS") },
                            onOpenFavoritesNotes = { subScreen = ActiveSubScreen.FavoritesNotes }
                        )
                        1 -> QuizHubScreen(
                            modules = uiState.modules,
                            lang = lang,
                            onStartModuleQuiz = { modId -> subScreen = ActiveSubScreen.ModuleQuiz(modId) },
                            onStartRandomQuiz = { subScreen = ActiveSubScreen.RandomQuiz },
                            onStartExamMode = { subScreen = ActiveSubScreen.TimedExam }
                        )
                        2 -> ToolsHubScreen(
                            onOpenTool = { toolId -> subScreen = ActiveSubScreen.ToolScreen(toolId) }
                        )
                        3 -> ProgressAndProfileScreen(
                            modules = uiState.modules,
                            lessons = uiState.lessons,
                            totalXp = uiState.totalXp,
                            userLevel = uiState.userLevel
                        )
                        4 -> SettingsScreen(
                            currentLanguage = lang,
                            currentThemeMode = uiState.prefs.themeMode,
                            dailyReminderEnabled = uiState.prefs.dailyReminder,
                            onSelectLanguage = { viewModel.switchLanguage(it) },
                            onSelectThemeMode = { viewModel.setThemeMode(it) },
                            onToggleDailyReminder = { viewModel.setDailyReminder(it) },
                            onResetProgress = { viewModel.resetAllProgress() }
                        )
                    }
                }
            }
        }
    }
}
