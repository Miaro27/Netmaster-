package com.example.netmaster.model

import com.example.data.local.LessonEntity
import com.example.data.local.ModuleEntity
import com.example.data.local.QuizQuestionEntity
import com.example.data.preferences.UserPrefs
import com.example.data.seed.FlashcardItem
import com.example.domain.SubnetCalculationResult
import com.example.domain.VlsmAllocatedBlock

/**
 * Core MVVM domain and model definitions for NetMaster (`com.example.netmaster.model`).
 */
typealias CourseModule = ModuleEntity
typealias CourseLesson = LessonEntity
typealias QuizQuestion = QuizQuestionEntity
typealias Flashcard = FlashcardItem
typealias UserPreferences = UserPrefs
typealias SubnetResult = SubnetCalculationResult
typealias VlsmSubnetBlock = VlsmAllocatedBlock

enum class DifficultyLevel(val code: Int) {
    BEGINNER(1),
    INTERMEDIATE(2),
    ADVANCED(3);

    companion object {
        fun fromCode(code: Int): DifficultyLevel = entries.find { it.code == code } ?: BEGINNER
    }
}

data class UserProgressSummary(
    val completedLessons: Int,
    val totalLessons: Int,
    val passedModules: Int,
    val totalModules: Int,
    val totalXp: Int,
    val level: Int
) {
    val completionRatio: Float
        get() = if (totalLessons > 0) completedLessons.toFloat() / totalLessons.toFloat() else 0f
}
