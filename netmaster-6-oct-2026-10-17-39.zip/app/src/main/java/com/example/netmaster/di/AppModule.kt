package com.example.netmaster.di

import android.content.Context
import com.example.data.local.NetMasterDatabase
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.NetMasterRepository
import com.example.netmaster.data.NetMasterDataSource

/**
 * Dependency Injection module (`com.example.netmaster.di`) providing singleton
 * instances of the Room database, repositories, and preferences for MVVM architecture.
 */
object AppModule {

    @Volatile
    private var dataSourceInstance: NetMasterDataSource? = null

    fun provideDataSource(context: Context): NetMasterDataSource {
        return dataSourceInstance ?: synchronized(this) {
            val instance = NetMasterDataSource(context.applicationContext)
            dataSourceInstance = instance
            instance
        }
    }

    fun provideDatabase(context: Context): NetMasterDatabase =
        provideDataSource(context).database

    fun provideNetMasterRepository(context: Context): NetMasterRepository =
        provideDataSource(context).repository

    fun provideUserPreferencesRepository(context: Context): UserPreferencesRepository =
        provideDataSource(context).preferencesRepository
}
