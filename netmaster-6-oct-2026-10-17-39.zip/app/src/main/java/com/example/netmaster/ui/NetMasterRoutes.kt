package com.example.netmaster.ui

/**
 * UI Navigation routes and screen identifiers for NetMaster (`com.example.netmaster.ui`).
 */
object NetMasterRoutes {
    const val ROUTE_SPLASH = "splash"
    const val ROUTE_ONBOARDING = "onboarding"
    const val ROUTE_HOME = "home_courses"
    const val ROUTE_MODULE_DETAIL = "module_detail"
    const val ROUTE_LESSON = "lesson_detail"
    const val ROUTE_QUIZ = "quiz_screen"
    const val ROUTE_EXAM_MODE = "exam_mode"
    const val ROUTE_TOOLS = "tools_hub"
    const val ROUTE_SUBNET_CALC = "subnet_calculator"
    const val ROUTE_BASE_CONVERTER = "base_converter"
    const val ROUTE_VLSM_CALC = "vlsm_calculator"
    const val ROUTE_WILDCARD_CALC = "wildcard_calculator"
    const val ROUTE_CLI_SIMULATOR = "cisco_cli_simulator"
    const val ROUTE_FLASHCARDS = "flashcards"
    const val ROUTE_PROGRESS = "progress_dashboard"
    const val ROUTE_PROFILE = "profile"
    const val ROUTE_SETTINGS = "settings"
    const val ROUTE_SEARCH = "global_search"
    const val ROUTE_FAVORITES_NOTES = "favorites_and_notes"
}
