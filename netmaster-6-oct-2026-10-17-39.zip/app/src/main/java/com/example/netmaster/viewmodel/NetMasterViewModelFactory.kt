package com.example.netmaster.viewmodel

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.netmaster.di.AppModule
import com.example.ui.viewmodel.NetMasterUiState
import com.example.ui.viewmodel.NetMasterViewModel

/**
 * MVVM ViewModel package (`com.example.netmaster.viewmodel`) providing factory
 * and state accessors backed by [AppModule].
 */
typealias CoreNetMasterViewModel = NetMasterViewModel
typealias CoreNetMasterUiState = NetMasterUiState

class NetMasterViewModelFactory(
    private val application: Application
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NetMasterViewModel::class.java)) {
            val repo = AppModule.provideNetMasterRepository(application)
            val prefs = AppModule.provideUserPreferencesRepository(application)
            return NetMasterViewModel(application, repo, prefs) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
