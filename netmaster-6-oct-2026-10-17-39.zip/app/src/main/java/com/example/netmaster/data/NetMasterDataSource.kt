package com.example.netmaster.data

import android.content.Context
import com.example.data.local.NetMasterDao
import com.example.data.local.NetMasterDatabase
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.NetMasterRepository
import com.example.data.seed.CurriculumSeedData

/**
 * Data layer entry point for NetMaster (`com.example.netmaster.data`).
 * Coordinates Room offline persistence, DataStore preferences, and bilingual seed data.
 */
class NetMasterDataSource(context: Context) {

    val database: NetMasterDatabase = NetMasterDatabase.getInstance(context)
    val dao: NetMasterDao = database.netMasterDao()
    val repository: NetMasterRepository = NetMasterRepository(dao)
    val preferencesRepository: UserPreferencesRepository = UserPreferencesRepository(context)

    fun getTotalSeededModulesCount(): Int = CurriculumSeedData.allModules.size
    fun getTotalSeededLessonsCount(): Int = CurriculumSeedData.allLessons.size
    fun getTotalSeededQuestionsCount(): Int = CurriculumSeedData.allQuizQuestions.size
}
