package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.ModuleEntity
import com.example.data.local.QuizQuestionEntity
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TechBluePrimary
import com.example.ui.theme.WarningAmber
import kotlinx.coroutines.delay

@Composable
fun QuizHubScreen(
    modules: List<ModuleEntity>,
    lang: String,
    onStartModuleQuiz: (Int) -> Unit,
    onStartRandomQuiz: () -> Unit,
    onStartExamMode: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("quiz_hub_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = stringResource(R.string.quiz_hub_title),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = stringResource(R.string.quiz_hub_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Timed Exam Mode Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = TechBluePrimary.copy(alpha = 0.16f)
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Timer, contentDescription = null, tint = CyanAccent)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.exam_mode_card_title),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = stringResource(R.string.exam_mode_card_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onStartExamMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("start_exam_mode_btn"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TechBluePrimary)
                    ) {
                        Text(stringResource(R.string.start_exam_btn), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Random Quiz Generator Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shuffle, contentDescription = null, tint = TechBluePrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.random_quiz_card_title),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = stringResource(R.string.random_quiz_card_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    FilledTonalButton(
                        onClick = onStartRandomQuiz,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("start_random_quiz_btn"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(stringResource(R.string.start_random_quiz_btn), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        item {
            Text(
                text = stringResource(R.string.quiz_by_module_header),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        items(modules, key = { it.id }) { module ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onStartModuleQuiz(module.id) }
                    .testTag("quiz_module_item_${module.id}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.module_number_prefix, module.number),
                            style = MaterialTheme.typography.labelMedium,
                            color = CyanAccent
                        )
                        Text(
                            text = module.getTitle(lang),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    val scoreLabel = if (module.bestQuizScore >= 0) {
                        stringResource(R.string.quiz_best_score_format, module.bestQuizScore, module.totalQuestions)
                    } else {
                        stringResource(R.string.quiz_not_taken)
                    }
                    Text(
                        text = scoreLabel,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (module.bestQuizScore >= 4) SuccessGreen else TechBluePrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun InteractiveQuizScreen(
    title: String,
    questions: List<QuizQuestionEntity>,
    isExamMode: Boolean,
    lang: String,
    onFinishScore: (Int) -> Unit,
    onBack: () -> Unit
) {
    if (questions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            OutlinedButton(onClick = onBack) {
                Text(stringResource(R.string.back))
            }
        }
        return
    }

    var currentIdx by remember { mutableIntStateOf(0) }
    var selectedOption by remember { mutableIntStateOf(-1) }
    var isAnswerValidated by remember { mutableStateOf(false) }
    var score by remember { mutableIntStateOf(0) }
    var isQuizFinished by remember { mutableStateOf(false) }
    val userAnswers = remember { mutableStateListOf<Int>() }
    var remainingSeconds by remember { mutableIntStateOf(if (isExamMode) 600 else 0) }

    LaunchedEffect(isExamMode, isQuizFinished) {
        if (isExamMode && !isQuizFinished) {
            while (remainingSeconds > 0 && !isQuizFinished) {
                delay(1000L)
                remainingSeconds--
            }
            if (remainingSeconds <= 0 && !isQuizFinished) {
                isQuizFinished = true
                onFinishScore(score)
            }
        }
    }

    if (isQuizFinished) {
        val total = questions.size.coerceAtLeast(1)
        val pct = (score * 100) / total
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.EmojiEvents,
                contentDescription = null,
                tint = if (pct >= 70) SuccessGreen else WarningAmber,
                modifier = Modifier.size(72.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = stringResource(R.string.quiz_result_title),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.quiz_score_format, score, total, pct),
                style = MaterialTheme.typography.titleLarge,
                color = if (pct >= 70) SuccessGreen else WarningAmber,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = stringResource(R.string.quiz_xp_earned_format, score * 20),
                style = MaterialTheme.typography.titleMedium,
                color = CyanAccent
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (pct >= 70) stringResource(R.string.exam_passed) else stringResource(R.string.exam_failed),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(20.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        currentIdx = 0
                        selectedOption = -1
                        isAnswerValidated = false
                        score = 0
                        userAnswers.clear()
                        remainingSeconds = if (isExamMode) 600 else 0
                        isQuizFinished = false
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.retry_quiz))
                }
                Button(
                    onClick = onBack,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(stringResource(R.string.back_to_list))
                }
            }

            // Detailed Question Review
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = stringResource(R.string.exam_review_answers),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(10.dp))
            questions.forEachIndexed { idx, q ->
                val userChoice = userAnswers.getOrNull(idx) ?: -1
                val options = q.getOptions(lang)
                val correct = userChoice == q.correctIndex
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "${idx + 1}. ${q.getQuestion(lang)}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "✓ ${options.getOrElse(q.correctIndex) { "" }}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (correct) SuccessGreen else CyanAccent,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = q.getExplanation(lang),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
        return
    }

    val currentQuestion = questions[currentIdx]
    val options = currentQuestion.getOptions(lang)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("quiz_back_btn")) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            if (isExamMode) {
                val mins = remainingSeconds / 60
                val secs = remainingSeconds % 60
                Text(
                    text = stringResource(R.string.exam_time_remaining, mins, secs),
                    style = MaterialTheme.typography.labelLarge,
                    color = if (remainingSeconds < 60) ErrorRed else CyanAccent,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.question_progress_format, currentIdx + 1, questions.size),
            style = MaterialTheme.typography.labelLarge,
            color = TechBluePrimary
        )
        Spacer(modifier = Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = { (currentIdx + 1).toFloat() / questions.size.toFloat() },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = TechBluePrimary
        )

        Spacer(modifier = Modifier.height(18.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Text(
                text = currentQuestion.getQuestion(lang),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(18.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        options.forEachIndexed { idx, optText ->
            val isSelected = selectedOption == idx
            val showCorrection = isAnswerValidated && !isExamMode
            val isCorrectOption = idx == currentQuestion.correctIndex

            val borderColor = when {
                showCorrection && isCorrectOption -> SuccessGreen
                showCorrection && isSelected && !isCorrectOption -> ErrorRed
                isSelected -> CyanAccent
                else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
            }
            val bgColor = when {
                showCorrection && isCorrectOption -> SuccessGreen.copy(alpha = 0.16f)
                showCorrection && isSelected && !isCorrectOption -> ErrorRed.copy(alpha = 0.16f)
                isSelected -> TechBluePrimary.copy(alpha = 0.18f)
                else -> MaterialTheme.colorScheme.surface
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(bgColor)
                    .border(width = 1.5.dp, color = borderColor, shape = RoundedCornerShape(14.dp))
                    .clickable(enabled = !isAnswerValidated) { selectedOption = idx }
                    .padding(16.dp)
                    .testTag("quiz_option_$idx"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .background(borderColor.copy(alpha = 0.25f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = ('A' + idx).toString(),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = optText,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        if (isAnswerValidated && !isExamMode) {
            Spacer(modifier = Modifier.height(14.dp))
            val isCorrect = selectedOption == currentQuestion.correctIndex
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isCorrect) SuccessGreen.copy(alpha = 0.14f) else ErrorRed.copy(alpha = 0.14f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isCorrect) Icons.Default.CheckCircle else Icons.Default.Error,
                            contentDescription = null,
                            tint = if (isCorrect) SuccessGreen else ErrorRed
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isCorrect) {
                                stringResource(R.string.correct_answer_badge)
                            } else {
                                stringResource(R.string.wrong_answer_badge)
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isCorrect) SuccessGreen else ErrorRed
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.explanation_title),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = currentQuestion.getExplanation(lang),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                if (!isAnswerValidated && !isExamMode) {
                    isAnswerValidated = true
                    userAnswers.add(selectedOption)
                    if (selectedOption == currentQuestion.correctIndex) {
                        score++
                    }
                } else {
                    if (isExamMode) {
                        userAnswers.add(selectedOption)
                        if (selectedOption == currentQuestion.correctIndex) {
                            score++
                        }
                    }
                    if (currentIdx < questions.size - 1) {
                        currentIdx++
                        selectedOption = -1
                        isAnswerValidated = false
                    } else {
                        isQuizFinished = true
                        onFinishScore(score)
                    }
                }
            },
            enabled = selectedOption != -1,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("quiz_primary_action_btn"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = TechBluePrimary)
        ) {
            val btnLabel = when {
                !isAnswerValidated && !isExamMode -> stringResource(R.string.validate_answer)
                currentIdx < questions.size - 1 -> stringResource(R.string.next_question)
                else -> stringResource(R.string.finish_quiz)
            }
            Text(text = btnLabel, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}
