package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core NetMaster Tech Blue (#0A84FF) & Cyan Accents
val TechBluePrimary = Color(0xFF0A84FF)
val TechBlueDark = Color(0xFF0060DF)
val TechBlueLight = Color(0xFF5AC8FA)
val CyanAccent = Color(0xFF00E5FF)
val CyanAccentDark = Color(0xFF00B8D4)

// Dark Theme Surfaces (Deep Cyber Navy)
val DarkBackground = Color(0xFF071126)
val DarkSurface = Color(0xFF0E1D38)
val DarkSurfaceVariant = Color(0xFF172B4D)
val DarkOnSurface = Color(0xFFEAF2FF)
val DarkOnSurfaceVariant = Color(0xFF9EB3D6)

// Light Theme Surfaces (Crisp Lab White/Blue)
val LightBackground = Color(0xFFF3F7FD)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE3EDF9)
val LightOnSurface = Color(0xFF0B192C)
val LightOnSurfaceVariant = Color(0xFF425675)

// Status & Semantic Colors
val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)
val TerminalBg = Color(0xFF060B14)
val TerminalGreen = Color(0xFF4ADE80)
