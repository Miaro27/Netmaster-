package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.LessonEntity
import com.example.data.local.ModuleEntity
import com.example.data.local.QuizQuestionEntity
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.preferences.UserPrefs
import com.example.data.repository.NetMasterRepository
import com.example.data.seed.CurriculumSeedData
import com.example.data.seed.FlashcardItem
import com.example.netmaster.di.AppModule
import com.example.worker.DailyReminderWorker
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class NetMasterUiState(
    val isLoading: Boolean = true,
    val prefs: UserPrefs = UserPrefs(),
    val modules: List<ModuleEntity> = emptyList(),
    val lessons: List<LessonEntity> = emptyList(),
    val quizQuestions: List<QuizQuestionEntity> = emptyList(),
    val flashcards: List<FlashcardItem> = CurriculumSeedData.flashcards,
    val totalXp: Int = 0,
    val userLevel: Int = 1
)

class NetMasterViewModel(
    application: Application,
    private val repository: NetMasterRepository = AppModule.provideNetMasterRepository(application),
    private val prefsRepo: UserPreferencesRepository = AppModule.provideUserPreferencesRepository(application)
) : AndroidViewModel(application) {

    val uiState: StateFlow<NetMasterUiState> = combine(
        prefsRepo.userPrefsFlow,
        repository.allModules,
        repository.allLessons,
        repository.allQuizQuestions
    ) { prefs, modules, lessons, questions ->
        val completedLessonsCount = lessons.count { it.isCompleted }
        val quizPoints = modules.filter { it.bestQuizScore > 0 }.sumOf { it.bestQuizScore * 20 }
        val totalXp = (completedLessonsCount * 25) + quizPoints + prefs.bonusXp
        val level = (totalXp / 150) + 1

        NetMasterUiState(
            isLoading = false,
            prefs = prefs,
            modules = modules,
            lessons = lessons,
            quizQuestions = questions,
            flashcards = CurriculumSeedData.flashcards,
            totalXp = totalXp,
            userLevel = level
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = NetMasterUiState()
    )

    init {
        viewModelScope.launch {
            val savedLang = prefsRepo.getSavedLanguageOrDefault()
            UserPreferencesRepository.applyAppLocale(savedLang)
            repository.ensureSeeded()
        }
    }

    fun switchLanguage(langCode: String) {
        viewModelScope.launch {
            prefsRepo.setLanguage(langCode)
        }
    }

    fun toggleLanguageInstant() {
        val current = uiState.value.prefs.language
        val next = if (current == "en") "fr" else "en"
        switchLanguage(next)
    }

    fun setThemeMode(mode: String) {
        viewModelScope.launch {
            prefsRepo.setThemeMode(mode)
        }
    }

    fun completeOnboarding() {
        viewModelScope.launch {
            prefsRepo.completeOnboarding()
        }
    }

    fun setDailyReminder(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepo.setDailyReminder(enabled)
            DailyReminderWorker.scheduleOrCancel(getApplication(), enabled)
        }
    }

    fun toggleLessonCompleted(lessonId: Int, completed: Boolean) {
        viewModelScope.launch {
            repository.toggleLessonCompleted(lessonId, completed)
        }
    }

    fun toggleLessonBookmark(lessonId: Int, bookmarked: Boolean) {
        viewModelScope.launch {
            repository.toggleLessonBookmark(lessonId, bookmarked)
        }
    }

    fun savePersonalNote(lessonId: Int, note: String) {
        viewModelScope.launch {
            repository.savePersonalNote(lessonId, note)
        }
    }

    fun recordQuizResult(moduleId: Int?, score: Int) {
        viewModelScope.launch {
            if (moduleId != null && moduleId in 1..13) {
                repository.recordModuleQuizScore(moduleId, score)
            } else {
                prefsRepo.addBonusXp(score * 15)
            }
        }
    }

    fun resetAllProgress() {
        viewModelScope.launch {
            repository.resetAllProgress()
            prefsRepo.resetBonusXp()
        }
    }
}
