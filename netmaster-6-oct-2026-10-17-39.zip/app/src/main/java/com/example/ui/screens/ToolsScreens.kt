package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.seed.FlashcardItem
import com.example.domain.NetworkCalculators
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.RobotoMonoFontFamily
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TechBluePrimary
import com.example.ui.theme.TerminalBg
import com.example.ui.theme.TerminalGreen

data class ToolMenuItem(
    val id: String,
    val titleRes: Int,
    val descRes: Int,
    val icon: ImageVector
)

@Composable
fun ToolsHubScreen(
    onOpenTool: (String) -> Unit
) {
    val tools = listOf(
        ToolMenuItem("SUBNET", R.string.tool_subnet_title, R.string.tool_subnet_desc, Icons.Default.Lan),
        ToolMenuItem("BASE", R.string.tool_base_title, R.string.tool_base_desc, Icons.Default.Memory),
        ToolMenuItem("VLSM", R.string.tool_vlsm_title, R.string.tool_vlsm_desc, Icons.Default.AccountTree),
        ToolMenuItem("WILDCARD", R.string.tool_wildcard_title, R.string.tool_wildcard_desc, Icons.Default.Security),
        ToolMenuItem("CLI", R.string.tool_cli_title, R.string.tool_cli_desc, Icons.Default.Terminal),
        ToolMenuItem("FLASHCARDS", R.string.tool_flashcards_title, R.string.tool_flashcards_desc, Icons.Default.Style),
        ToolMenuItem("RANDOM_QUIZ", R.string.tool_random_quiz_title, R.string.tool_random_quiz_desc, Icons.Default.Shuffle)
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("tools_hub_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = stringResource(R.string.tools_hub_title),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = stringResource(R.string.tools_hub_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        items(tools, key = { it.id }) { tool ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .clickable { onOpenTool(tool.id) }
                    .testTag("tool_card_${tool.id}"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .background(TechBluePrimary.copy(alpha = 0.16f), RoundedCornerShape(14.dp))
                            .border(1.dp, CyanAccent.copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(tool.icon, contentDescription = null, tint = TechBluePrimary, modifier = Modifier.size(26.dp))
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(tool.titleRes),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stringResource(tool.descRes),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SubnetCalculatorScreen(
    lang: String,
    onBack: () -> Unit
) {
    var ipText by remember { mutableStateOf("192.168.1.10") }
    var cidrSlider by remember { mutableFloatStateOf(24f) }
    val cidr = cidrSlider.toInt()
    val result = remember(ipText, cidr, lang) {
        NetworkCalculators.calculateSubnet(ipText, cidr, lang)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("subnet_back_btn")) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
            }
            Text(
                text = stringResource(R.string.tool_subnet_title),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
            value = ipText,
            onValueChange = { ipText = it },
            label = { Text(stringResource(R.string.subnet_ip_label)) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("subnet_ip_input"),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SuggestionChip(
                onClick = { ipText = "192.168.1.10"; cidrSlider = 24f },
                label = { Text(stringResource(R.string.subnet_preset_test)) }
            )
            SuggestionChip(
                onClick = { ipText = "172.16.45.12"; cidrSlider = 20f },
                label = { Text(stringResource(R.string.subnet_preset_class_b)) }
            )
            SuggestionChip(
                onClick = { ipText = "10.0.0.5"; cidrSlider = 30f },
                label = { Text(stringResource(R.string.subnet_preset_p2p)) }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.subnet_cidr_label, cidr),
            style = MaterialTheme.typography.titleMedium,
            color = CyanAccent,
            fontWeight = FontWeight.Bold
        )
        Slider(
            value = cidrSlider,
            onValueChange = { cidrSlider = it },
            valueRange = 1f..32f,
            steps = 30,
            modifier = Modifier.testTag("subnet_cidr_slider")
        )

        Spacer(modifier = Modifier.height(12.dp))
        if (!result.isValid) {
            Text(
                text = stringResource(R.string.subnet_invalid_ip),
                color = ErrorRed,
                style = MaterialTheme.typography.bodyMedium
            )
        } else {
            val rows = listOf(
                stringResource(R.string.subnet_network_addr) to "${result.networkAddress}/${result.cidr}",
                stringResource(R.string.subnet_broadcast_addr) to result.broadcastAddress,
                stringResource(R.string.subnet_first_host) to result.firstHost,
                stringResource(R.string.subnet_last_host) to result.lastHost,
                stringResource(R.string.subnet_total_hosts) to result.usableHosts.toString(),
                stringResource(R.string.subnet_mask_dec) to result.subnetMaskDec,
                stringResource(R.string.subnet_wildcard) to result.wildcardMaskDec,
                stringResource(R.string.subnet_ip_class) to result.ipClassAndScope
            )
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    rows.forEach { (label, value) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = value,
                                fontFamily = RobotoMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = stringResource(R.string.subnet_mask_bin),
                        style = MaterialTheme.typography.labelLarge,
                        color = CyanAccent
                    )
                    Text(
                        text = result.subnetMaskBin,
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 12.sp,
                        color = TerminalGreen,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalBg, RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun BaseConverterScreen(onBack: () -> Unit) {
    var decText by remember { mutableStateOf("192") }
    var binText by remember { mutableStateOf("11000000") }
    var hexText by remember { mutableStateOf("C0") }
    var octText by remember { mutableStateOf("300") }
    var hasError by remember { mutableStateOf(false) }

    fun updateFromValue(v: Long?) {
        if (v == null || v < 0) {
            hasError = true
            return
        }
        hasError = false
        decText = v.toString(10)
        binText = v.toString(2)
        hexText = v.toString(16).uppercase()
        octText = v.toString(8)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("base_back_btn")) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
            }
            Text(
                text = stringResource(R.string.tool_base_title),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SuggestionChip(
                onClick = { updateFromValue(255L) },
                label = { Text(stringResource(R.string.base_preset_255)) }
            )
            SuggestionChip(
                onClick = { updateFromValue(192L) },
                label = { Text(stringResource(R.string.base_preset_192)) }
            )
            SuggestionChip(
                onClick = { updateFromValue(128L) },
                label = { Text(stringResource(R.string.base_preset_128)) }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
            value = decText,
            onValueChange = {
                decText = it
                if (it.isEmpty()) {
                    binText = ""; hexText = ""; octText = ""; hasError = false
                } else {
                    updateFromValue(it.trim().toLongOrNull(10))
                }
            },
            label = { Text(stringResource(R.string.base_decimal_label)) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("base_dec_input"),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
            value = binText,
            onValueChange = {
                binText = it
                if (it.isEmpty()) {
                    decText = ""; hexText = ""; octText = ""; hasError = false
                } else {
                    updateFromValue(it.trim().toLongOrNull(2))
                }
            },
            label = { Text(stringResource(R.string.base_binary_label)) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("base_bin_input"),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
            value = hexText,
            onValueChange = {
                hexText = it.uppercase()
                if (it.isEmpty()) {
                    decText = ""; binText = ""; octText = ""; hasError = false
                } else {
                    updateFromValue(it.trim().toLongOrNull(16))
                }
            },
            label = { Text(stringResource(R.string.base_hex_label)) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("base_hex_input"),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
            value = octText,
            onValueChange = {
                octText = it
                if (it.isEmpty()) {
                    decText = ""; binText = ""; hexText = ""; hasError = false
                } else {
                    updateFromValue(it.trim().toLongOrNull(8))
                }
            },
            label = { Text(stringResource(R.string.base_octal_label)) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("base_oct_input"),
            singleLine = true
        )

        if (hasError) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.base_invalid_input),
                color = ErrorRed,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        val lowByte = (decText.toLongOrNull() ?: 0L) and 0xFFL
        val paddedBin = lowByte.toString(2).padStart(8, '0')
        val weights = listOf(128, 64, 32, 16, 8, 4, 2, 1)

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.base_bit_Breakdown),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    weights.forEachIndexed { idx, w ->
                        val bitChar = paddedBin[idx]
                        val isOne = bitChar == '1'
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 2.dp)
                                .background(
                                    if (isOne) TechBluePrimary.copy(alpha = 0.22f)
                                    else MaterialTheme.colorScheme.surfaceVariant,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    val toggled = lowByte xor (1L shl (7 - idx))
                                    updateFromValue(toggled)
                                }
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = w.toString(), fontSize = 10.sp, fontFamily = RobotoMonoFontFamily)
                            Text(
                                text = bitChar.toString(),
                                fontFamily = RobotoMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                color = if (isOne) CyanAccent else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VlsmCalculatorScreen(onBack: () -> Unit) {
    var baseIp by remember { mutableStateOf("192.168.10.0") }
    var baseCidrText by remember { mutableStateOf("24") }
    var hostsInput by remember { mutableStateOf("50, 25, 10, 2") }

    val parsedNeeds = hostsInput.split(",", ";", " ")
        .mapNotNull { it.trim().toIntOrNull() }
    val baseCidr = baseCidrText.toIntOrNull() ?: 24
    val (success, blocks) = remember(baseIp, baseCidr, parsedNeeds) {
        NetworkCalculators.calculateVlsm(baseIp, baseCidr, parsedNeeds)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
            }
            Text(
                text = stringResource(R.string.tool_vlsm_title),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = baseIp,
                onValueChange = { baseIp = it },
                label = { Text(stringResource(R.string.vlsm_base_network_label)) },
                modifier = Modifier.weight(2f),
                singleLine = true
            )
            OutlinedTextField(
                value = baseCidrText,
                onValueChange = { baseCidrText = it },
                label = { Text(stringResource(R.string.vlsm_base_cidr_label)) },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
            value = hostsInput,
            onValueChange = { hostsInput = it },
            label = { Text(stringResource(R.string.vlsm_hosts_input_label)) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))
        if (!success && blocks.isNotEmpty()) {
            Text(
                text = stringResource(R.string.vlsm_error_overflow),
                color = ErrorRed,
                fontWeight = FontWeight.Bold
            )
        }

        blocks.forEach { b ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(R.string.vlsm_subnet_index, b.index, b.neededHosts),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TechBluePrimary
                        )
                        Text(
                            text = "${b.networkAddress}/${b.cidr}",
                            fontFamily = RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.vlsm_allocated_size, b.allocatedHosts, "/${b.cidr}"),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = stringResource(R.string.vlsm_range_format, b.firstHost, b.lastHost),
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 12.sp
                    )
                    Text(
                        text = stringResource(R.string.vlsm_broadcast_format, b.broadcastAddress, b.subnetMask),
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun WildcardCalculatorScreen(onBack: () -> Unit) {
    var networkIp by remember { mutableStateOf("192.168.1.0") }
    var cidrSlider by remember { mutableFloatStateOf(24f) }
    val cidr = cidrSlider.toInt()
    val calc = remember(networkIp, cidr) {
        NetworkCalculators.calculateSubnet(networkIp, cidr, "en")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
            }
            Text(
                text = stringResource(R.string.tool_wildcard_title),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
            value = networkIp,
            onValueChange = { networkIp = it },
            label = { Text(stringResource(R.string.wildcard_network_input)) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = stringResource(R.string.wildcard_cidr_slider, cidr),
            style = MaterialTheme.typography.titleMedium,
            color = CyanAccent,
            fontWeight = FontWeight.Bold
        )
        Slider(
            value = cidrSlider,
            onValueChange = { cidrSlider = it },
            valueRange = 8f..32f,
            steps = 23
        )

        if (calc.isValid) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(stringResource(R.string.wildcard_subnet_mask))
                        Text(calc.subnetMaskDec, fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(stringResource(R.string.wildcard_mask_result), color = CyanAccent)
                        Text(
                            calc.wildcardMaskDec,
                            fontFamily = RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                    }
                    Text(
                        text = stringResource(R.string.wildcard_binary_mask),
                        style = MaterialTheme.typography.labelLarge
                    )
                    Text(
                        text = calc.wildcardMaskBin,
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 12.sp,
                        color = TerminalGreen,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalBg, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    )
                    Text(
                        text = stringResource(R.string.wildcard_cisco_acl),
                        style = MaterialTheme.typography.labelLarge,
                        color = TechBluePrimary
                    )
                    Text(
                        text = "access-list 10 permit ${calc.networkAddress} ${calc.wildcardMaskDec}",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 12.sp,
                        color = TerminalGreen,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalBg, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    )
                    Text(
                        text = stringResource(R.string.wildcard_cisco_ext_acl),
                        style = MaterialTheme.typography.labelLarge,
                        color = TechBluePrimary
                    )
                    Text(
                        text = "access-list 100 permit ip ${calc.networkAddress} ${calc.wildcardMaskDec} any",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 12.sp,
                        color = TerminalGreen,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalBg, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun CiscoCliSimulatorScreen(
    lang: String,
    onBack: () -> Unit
) {
    var hostname by remember { mutableStateOf("NetMaster-R1") }
    var mode by remember { mutableStateOf("USER") }
    var commandInput by remember { mutableStateOf("") }
    val terminalLines = remember {
        mutableStateListOf(
            "Cisco IOS XE Software, Version 17.09.04a — NetMaster Offline Lab",
            "Type 'help' or '?' to list available commands."
        )
    }

    val promptPrefix = when (mode) {
        "PRIV" -> "$hostname#"
        "CONFIG" -> "$hostname(config)#"
        else -> "$hostname>"
    }

    fun runCommand(cmd: String) {
        terminalLines.add("$promptPrefix $cmd")
        val (output, newHost, newMode) = NetworkCalculators.executeCiscoCliCommand(cmd, hostname, mode, lang)
        hostname = newHost
        mode = newMode
        if (output.isNotBlank()) {
            terminalLines.add(output)
        }
    }

    val quickCmds = listOf(
        "enable",
        "show ip interface brief",
        "show ip route",
        "show vlan brief",
        "show mac address-table",
        "ping 192.168.1.1",
        "conf t",
        "help"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                }
                Text(
                    text = stringResource(R.string.tool_cli_title),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
            OutlinedButton(onClick = { terminalLines.clear() }) {
                Text(stringResource(R.string.cli_clear_btn))
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = stringResource(R.string.cli_quick_cmds),
            style = MaterialTheme.typography.labelLarge,
            color = CyanAccent
        )
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(vertical = 6.dp)
        ) {
            items(quickCmds) { qCmd ->
                SuggestionChip(
                    onClick = { runCommand(qCmd) },
                    label = { Text(qCmd, fontFamily = RobotoMonoFontFamily, fontSize = 11.sp) }
                )
            }
        }

        // Terminal Output Window
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(TerminalBg, RoundedCornerShape(16.dp))
                .border(1.dp, TechBluePrimary.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .padding(14.dp)
                .testTag("cli_terminal_output"),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(terminalLines) { line ->
                Text(
                    text = line,
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 12.sp,
                    color = if (line.startsWith("%")) ErrorRed else TerminalGreen
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = commandInput,
                onValueChange = { commandInput = it },
                placeholder = { Text(stringResource(R.string.cli_input_hint)) },
                prefix = { Text("$promptPrefix ", fontFamily = RobotoMonoFontFamily, color = CyanAccent) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("cli_command_input"),
                singleLine = true
            )
            Button(
                onClick = {
                    if (commandInput.isNotBlank()) {
                        runCommand(commandInput)
                        commandInput = ""
                    }
                },
                modifier = Modifier.testTag("cli_send_btn"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(stringResource(R.string.cli_send_btn))
            }
        }
    }
}

@Composable
fun FlashcardsScreen(
    flashcards: List<FlashcardItem>,
    lang: String,
    onBack: () -> Unit
) {
    var currentIndex by remember { mutableIntStateOf(0) }
    var isFlipped by remember { mutableStateOf(false) }
    val card = flashcards.getOrElse(currentIndex) { flashcards.first() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
            }
            Text(
                text = stringResource(R.string.tool_flashcards_title),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = stringResource(R.string.flashcard_counter, currentIndex + 1, flashcards.size),
                style = MaterialTheme.typography.labelLarge,
                color = CyanAccent
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = stringResource(R.string.flashcard_tap_to_flip),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(24.dp))
                .clickable { isFlipped = !isFlipped }
                .testTag("flashcard_flip_card"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isFlipped) TechBluePrimary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = card.getCategory(lang),
                    style = MaterialTheme.typography.labelLarge,
                    color = CyanAccent
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isFlipped) {
                        stringResource(R.string.flashcard_answer_side)
                    } else {
                        stringResource(R.string.flashcard_question_side)
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = if (isFlipped) SuccessGreen else TechBluePrimary
                )
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = if (isFlipped) card.getBack(lang) else card.getFront(lang),
                    style = if (isFlipped) MaterialTheme.typography.bodyLarge else MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = {
                    if (currentIndex > 0) {
                        currentIndex--
                        isFlipped = false
                    }
                },
                enabled = currentIndex > 0,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(stringResource(R.string.flashcard_prev))
            }
            Button(
                onClick = {
                    if (currentIndex < flashcards.size - 1) {
                        currentIndex++
                        isFlipped = false
                    }
                },
                enabled = currentIndex < flashcards.size - 1,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(stringResource(R.string.flashcard_next))
                Spacer(modifier = Modifier.width(6.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
            }
        }
    }
}
