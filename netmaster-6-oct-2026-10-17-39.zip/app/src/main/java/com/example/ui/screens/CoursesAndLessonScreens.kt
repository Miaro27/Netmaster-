package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SettingsEthernet
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.LessonEntity
import com.example.data.local.ModuleEntity
import com.example.ui.components.NetworkDiagramCard
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.RobotoMonoFontFamily
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TechBluePrimary
import com.example.ui.theme.TerminalBg
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.WarningAmber

fun getModuleIcon(iconType: String): ImageVector = when (iconType) {
    "OSI_NETWORK" -> Icons.Default.Hub
    "BINARY_MATH" -> Icons.Default.Memory
    "IP_SUBNET" -> Icons.Default.Lan
    "IPV6_GLOBE" -> Icons.Default.Public
    "HARDWARE_DEVICES" -> Icons.Default.Cable
    "VLAN_TRUNK" -> Icons.Default.SettingsEthernet
    "PROTOCOLS_PORTS" -> Icons.Default.Dns
    "ROUTING_TABLE" -> Icons.Default.Router
    "SWITCHING_STP" -> Icons.Default.Hub
    "SECURITY_SHIELD" -> Icons.Default.Security
    "WIRELESS_WIFI" -> Icons.Default.Wifi
    "NETWORK_SERVICES" -> Icons.Default.Lock
    "CLOUD_SDN" -> Icons.Default.Cloud
    else -> Icons.Default.Router
}

@Composable
fun HomeCoursesScreen(
    modules: List<ModuleEntity>,
    lessons: List<LessonEntity>,
    lang: String,
    totalXp: Int,
    userLevel: Int,
    onSelectModule: (Int) -> Unit,
    onOpenExamMode: () -> Unit,
    onOpenFlashcards: () -> Unit,
    onOpenFavoritesNotes: () -> Unit
) {
    val completedLessons = lessons.count { it.isCompleted }
    val totalLessons = lessons.size.coerceAtLeast(1)
    val overallProgress = completedLessons.toFloat() / totalLessons.toFloat()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_modules_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Banner Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_hero_network),
                        contentDescription = stringResource(R.string.app_name),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(175.dp),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(175.dp)
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color(0x99071126),
                                        Color(0xE6071126)
                                    )
                                )
                            )
                            .padding(18.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = stringResource(R.string.home_hero_badge),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = CyanAccent,
                                    modifier = Modifier
                                        .background(TechBluePrimary.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                                Text(
                                    text = stringResource(R.string.xp_total_format, totalXp),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column {
                                Text(
                                    text = stringResource(R.string.app_tagline),
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = stringResource(R.string.home_overall_progress),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.White.copy(alpha = 0.85f)
                                    )
                                    Text(
                                        text = "${(overallProgress * 100).toInt()}%",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = CyanAccent,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = { overallProgress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = CyanAccent,
                                    trackColor = Color.White.copy(alpha = 0.2f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Quick Action Row (Exam Mode, Flashcards, Bookmarks/Notes)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(
                    onClick = onOpenExamMode,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_exam_btn"),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Timer, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.quick_exam_btn), style = MaterialTheme.typography.labelLarge, maxLines = 1)
                }
                FilledTonalButton(
                    onClick = onOpenFlashcards,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_flashcards_btn"),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Style, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.quick_flashcards_btn), style = MaterialTheme.typography.labelLarge, maxLines = 1)
                }
                FilledTonalButton(
                    onClick = onOpenFavoritesNotes,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_notes_btn"),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Bookmark, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.quick_notes_btn), style = MaterialTheme.typography.labelLarge, maxLines = 1)
                }
            }
        }

        item {
            Text(
                text = stringResource(R.string.home_modules_header),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        // All 13 Modules
        items(modules, key = { it.id }) { module ->
            val modLessons = lessons.filter { it.moduleId == module.id }
            val doneCount = modLessons.count { it.isCompleted }
            val totalCount = modLessons.size.coerceAtLeast(1)
            val modProgress = doneCount.toFloat() / totalCount.toFloat()

            val levelLabel = when (module.level) {
                1 -> stringResource(R.string.level_beginner)
                2 -> stringResource(R.string.level_intermediate)
                else -> stringResource(R.string.level_advanced)
            }
            val levelColor = when (module.level) {
                1 -> SuccessGreen
                2 -> TechBluePrimary
                else -> WarningAmber
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .clickable { onSelectModule(module.id) }
                    .testTag("module_card_${module.id}"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(TechBluePrimary.copy(alpha = 0.15f), RoundedCornerShape(14.dp))
                                    .border(1.dp, TechBluePrimary.copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = getModuleIcon(module.iconType),
                                    contentDescription = null,
                                    tint = TechBluePrimary,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = stringResource(R.string.module_number_prefix, module.number),
                                        style = MaterialTheme.typography.labelMedium,
                                        color = CyanAccent
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = levelLabel,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = levelColor,
                                        modifier = Modifier
                                            .background(levelColor.copy(alpha = 0.14f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = module.getTitle(lang),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = module.getDescription(lang),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.lessons_count_format, doneCount, modLessons.size),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        val quizBadgeText = if (module.bestQuizScore >= 0) {
                            stringResource(R.string.quiz_best_score_format, module.bestQuizScore, module.totalQuestions)
                        } else {
                            stringResource(R.string.quiz_not_taken)
                        }
                        Text(
                            text = quizBadgeText,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (module.bestQuizScore >= 4) SuccessGreen else MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { modProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = if (doneCount == modLessons.size && modLessons.isNotEmpty()) SuccessGreen else TechBluePrimary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun ModuleDetailScreen(
    module: ModuleEntity,
    lessons: List<LessonEntity>,
    lang: String,
    onBack: () -> Unit,
    onOpenLesson: (Int) -> Unit,
    onStartModuleQuiz: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("module_detail_back")) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.module_number_prefix, module.number),
                    style = MaterialTheme.typography.labelMedium,
                    color = CyanAccent
                )
                Text(
                    text = module.getTitle(lang),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = module.getDescription(lang),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = stringResource(R.string.module_lessons_tab),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(lessons, key = { it.id }) { lesson ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onOpenLesson(lesson.id) }
                        .testTag("lesson_item_${lesson.id}"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (lesson.isCompleted) Icons.Default.CheckCircle else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = if (lesson.isCompleted) SuccessGreen else TechBluePrimary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = lesson.getTitle(lang),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        if (lesson.isBookmarked) {
                            Icon(
                                imageVector = Icons.Default.Bookmark,
                                contentDescription = null,
                                tint = WarningAmber
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Button(
            onClick = { onStartModuleQuiz(module.id) },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("start_module_quiz_btn"),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = TechBluePrimary)
        ) {
            Icon(Icons.Default.Quiz, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = stringResource(R.string.start_module_quiz),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun LessonDetailScreen(
    lesson: LessonEntity,
    moduleLessons: List<LessonEntity>,
    lang: String,
    onBack: () -> Unit,
    onToggleComplete: (Boolean) -> Unit,
    onToggleBookmark: (Boolean) -> Unit,
    onSaveNote: (String) -> Unit,
    onNavigateLesson: (Int) -> Unit
) {
    val context = LocalContext.current
    var noteText by remember(lesson.id, lesson.personalNote) { mutableStateOf(lesson.personalNote) }
    val currentIndex = moduleLessons.indexOfFirst { it.id == lesson.id }
    val prevLesson = if (currentIndex > 0) moduleLessons[currentIndex - 1] else null
    val nextLesson = if (currentIndex in 0 until moduleLessons.size - 1) moduleLessons[currentIndex + 1] else null
    val noteSavedMsg = stringResource(R.string.note_saved_toast)

    LaunchedEffect(lesson.id) {
        noteText = lesson.personalNote
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("lesson_back_btn")) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
            }
            Text(
                text = stringResource(R.string.module_number_prefix, lesson.moduleId),
                style = MaterialTheme.typography.labelLarge,
                color = CyanAccent
            )
            IconButton(
                onClick = { onToggleBookmark(!lesson.isBookmarked) },
                modifier = Modifier.testTag("lesson_bookmark_btn")
            ) {
                Icon(
                    imageVector = if (lesson.isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = if (lesson.isBookmarked) {
                        stringResource(R.string.bookmark_remove)
                    } else {
                        stringResource(R.string.bookmark_add)
                    },
                    tint = if (lesson.isBookmarked) WarningAmber else MaterialTheme.colorScheme.onSurface
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = lesson.getTitle(lang),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Interactive / Visual Diagram Card
        Text(
            text = stringResource(R.string.diagram_section_title),
            style = MaterialTheme.typography.titleMedium,
            color = TechBluePrimary,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(8.dp))
        NetworkDiagramCard(diagramType = lesson.diagramType, lang = lang)

        Spacer(modifier = Modifier.height(18.dp))

        // Main Lesson Content Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Text(
                text = lesson.getContent(lang),
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(18.dp)
            )
        }

        // Commands & Technical Summary Block
        if (lesson.commandsBlock.isNotBlank()) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = stringResource(R.string.key_commands_title),
                style = MaterialTheme.typography.titleMedium,
                color = CyanAccent,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalBg, RoundedCornerShape(14.dp))
                    .border(1.dp, TechBluePrimary.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = lesson.commandsBlock,
                    fontFamily = RobotoMonoFontFamily,
                    color = TerminalGreen,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Mark as Completed Button
        Button(
            onClick = { onToggleComplete(!lesson.isCompleted) },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("mark_lesson_completed_btn"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (lesson.isCompleted) SuccessGreen else TechBluePrimary
            )
        ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (lesson.isCompleted) {
                    stringResource(R.string.lesson_completed)
                } else {
                    stringResource(R.string.mark_as_completed)
                },
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Personal Notes Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.personal_note_title),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    placeholder = { Text(stringResource(R.string.personal_note_hint)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("lesson_note_input"),
                    minLines = 3
                )
                Spacer(modifier = Modifier.height(8.dp))
                FilledTonalButton(
                    onClick = {
                        onSaveNote(noteText)
                        Toast.makeText(context, noteSavedMsg, Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.save))
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Previous / Next Lesson Navigation
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = { prevLesson?.let { onNavigateLesson(it.id) } },
                enabled = prevLesson != null,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(stringResource(R.string.previous_lesson))
            }
            Button(
                onClick = { nextLesson?.let { onNavigateLesson(it.id) } },
                enabled = nextLesson != null,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(stringResource(R.string.next_lesson))
                Spacer(modifier = Modifier.width(6.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}
