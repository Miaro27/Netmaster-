package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.RobotoMonoFontFamily
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TechBluePrimary
import com.example.ui.theme.WarningAmber
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun NetworkDiagramCard(
    diagramType: String,
    lang: String,
    modifier: Modifier = Modifier
) {
    val surfaceColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
    val borderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(surfaceColor, RoundedCornerShape(16.dp))
            .border(1.dp, borderColor, RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        when (diagramType) {
            "OSI_LAYERS" -> OsiModelDiagram(lang)
            "BINARY_WEIGHTS" -> BinaryWeightsDiagram()
            "TCP_HANDSHAKE" -> TcpHandshakeDiagram(lang)
            "VLAN_TRUNK" -> VlanTrunkDiagram(lang)
            "DHCP_DORA" -> DhcpDoraDiagram()
            else -> StarAndRouterCanvasDiagram(diagramType, lang)
        }
    }
}

@Composable
private fun OsiModelDiagram(lang: String) {
    val layers = if (lang == "en") {
        listOf(
            "L7 Application" to "HTTP, DNS, SSH, DHCP (Data)",
            "L6 Presentation" to "TLS/SSL, UTF-8, Encryption",
            "L5 Session" to "Session Control & Dialog",
            "L4 Transport" to "TCP / UDP Ports (Segment)",
            "L3 Network" to "IPv4 / IPv6 Routers (Packet)",
            "L2 Data Link" to "MAC, VLAN, Switch (Frame)",
            "L1 Physical" to "Cables, Fiber, Radio (Bits)"
        )
    } else {
        listOf(
            "C7 Application" to "HTTP, DNS, SSH, DHCP (Données)",
            "C6 Présentation" to "TLS/SSL, UTF-8, Chiffrement",
            "C5 Session" to "Contrôle de session",
            "C4 Transport" to "Ports TCP / UDP (Segment)",
            "C3 Réseau" to "Routeurs IPv4 / IPv6 (Paquet)",
            "C2 Liaison" to "MAC, VLAN, Switch (Trame)",
            "C1 Physique" to "Cuivre, Fibre, Radio (Bits)"
        )
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        layers.forEachIndexed { index, (layer, desc) ->
            val badgeColor = when (index) {
                in 0..2 -> TechBluePrimary
                3 -> CyanAccent
                4 -> SuccessGreen
                else -> WarningAmber
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(badgeColor.copy(alpha = 0.14f), RoundedCornerShape(8.dp))
                    .border(1.dp, badgeColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = layer,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = desc,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun BinaryWeightsDiagram() {
    val weights = listOf(128, 64, 32, 16, 8, 4, 2, 1)
    val bits = listOf(1, 1, 0, 0, 0, 0, 0, 0) // 192 example
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            weights.forEachIndexed { idx, w ->
                val active = bits[idx] == 1
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 2.dp)
                        .background(
                            if (active) TechBluePrimary.copy(alpha = 0.25f)
                            else MaterialTheme.colorScheme.surface,
                            RoundedCornerShape(8.dp)
                        )
                        .border(
                            1.dp,
                            if (active) CyanAccent else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = w.toString(),
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = bits[idx].toString(),
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = if (active) CyanAccent else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
        Text(
            text = "128 + 64 = 192 (11000000₂ = 0xC0)",
            style = MaterialTheme.typography.labelMedium,
            color = TechBluePrimary
        )
    }
}

@Composable
private fun TcpHandshakeDiagram(lang: String) {
    val steps = if (lang == "en") {
        listOf(
            "1. SYN (Seq = 100) ───────────►",
            "◄─────────── 2. SYN-ACK (Seq = 300, Ack = 101)",
            "3. ACK (Seq = 101, Ack = 301) ─► [ESTABLISHED]"
        )
    } else {
        listOf(
            "1. SYN (Seq = 100) ───────────►",
            "◄─────────── 2. SYN-ACK (Seq = 300, Ack = 101)",
            "3. ACK (Seq = 101, Ack = 301) ─► [CONNECTÉ]"
        )
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("CLIENT (192.168.1.10)", style = MaterialTheme.typography.labelLarge, color = TechBluePrimary)
            Text("SERVER (Port 443)", style = MaterialTheme.typography.labelLarge, color = CyanAccent)
        }
        steps.forEach { line ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = line,
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
private fun VlanTrunkDiagram(lang: String) {
    val label = if (lang == "en") {
        "[Switch A: VLAN 10, 20] ═══ 802.1Q Trunk (Tagged) ═══ [Router G0/0.10 & G0/0.20]"
    } else {
        "[Switch A: VLAN 10, 20] ═══ Trunk 802.1Q (Tagué) ═══ [Routeur G0/0.10 & G0/0.20]"
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = label,
            fontFamily = RobotoMonoFontFamily,
            fontSize = 12.sp,
            color = CyanAccent
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(TechBluePrimary.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Text("VLAN 10 (Data)\n192.168.10.0/24", fontFamily = RobotoMonoFontFamily, fontSize = 11.sp)
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(SuccessGreen.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Text("VLAN 20 (Voice)\n192.168.20.0/24", fontFamily = RobotoMonoFontFamily, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun DhcpDoraDiagram() {
    val dora = listOf(
        "D — DHCP Discover (Broadcast 255.255.255.255)",
        "O — DHCP Offer (IP 192.168.1.50/24 proposed)",
        "R — DHCP Request (Client accepts offer)",
        "A — DHCP Acknowledge (Lease confirmed + DNS/Gateway)"
    )
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        dora.forEachIndexed { idx, step ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .background(TechBluePrimary, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = (idx + 1).toString(),
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(text = step, fontFamily = RobotoMonoFontFamily, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun StarAndRouterCanvasDiagram(diagramType: String, lang: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
        ) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = size.minDimension * 0.36f
            val nodeCount = 5
            val dashEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)

            for (i in 0 until nodeCount) {
                val angle = (2 * Math.PI * i / nodeCount) - (Math.PI / 2)
                val nodePos = Offset(
                    x = center.x + (radius * cos(angle)).toFloat(),
                    y = center.y + (radius * sin(angle)).toFloat()
                )
                drawLine(
                    color = TechBluePrimary,
                    start = center,
                    end = nodePos,
                    strokeWidth = 4f,
                    pathEffect = dashEffect
                )
                drawCircle(
                    color = CyanAccent,
                    radius = 16f,
                    center = nodePos
                )
            }

            drawRoundRect(
                color = TechBluePrimary,
                topLeft = Offset(center.x - 32f, center.y - 22f),
                size = Size(64f, 44f),
                cornerRadius = CornerRadius(12f, 12f)
            )
        }
        val caption = when (diagramType) {
            "IPV4_SUBNET" -> "192.168.1.0/24 ──► [.1 First Host ... .254 Last Host] ──► .255 Broadcast"
            "IPV6_HEADER" -> "2001:0db8:0000:0000:0000:ff00:0042:8329 ──► 2001:db8::ff00:42:8329"
            "ROUTING_TOPOLOGY" -> "[LAN A] ──► R1 (OSPF Area 0 / AD 110) ══► R2 ──► [BGP AS 65001]"
            "STP_ETHERCHANNEL" -> "[Root Bridge (Prio 4096)] ══ LACP Port-Channel 1 ══ [Access Switch]"
            "SECURITY_ACL" -> "[Source] ──► Extended ACL 100 ──► [Router VPN IPsec] ──► Standard ACL 10"
            "WIFI_CHANNELS" -> "2.4 GHz (Ch 1, 6, 11) + 5 GHz (802.11ax OFDMA) • WPA3-SAE"
            "SDN_CLOUD" -> "[Apps] ◄─ Northbound REST ─► [SDN Controller] ◄─ Southbound ─► [Switches]"
            else -> if (lang == "en") "Core Switch / Router Star-Mesh Architecture" else "Architecture Réseau Étoile / Commutateur Central"
        }
        Text(
            text = caption,
            fontFamily = RobotoMonoFontFamily,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.primary
        )
    }
}
