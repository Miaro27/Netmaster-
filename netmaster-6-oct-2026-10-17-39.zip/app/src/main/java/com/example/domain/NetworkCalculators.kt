package com.example.domain

import java.util.Locale
import kotlin.math.pow

data class SubnetCalculationResult(
    val isValid: Boolean,
    val ipInput: String = "",
    val cidr: Int = 24,
    val networkAddress: String = "",
    val broadcastAddress: String = "",
    val firstHost: String = "",
    val lastHost: String = "",
    val usableHosts: Long = 0L,
    val subnetMaskDec: String = "",
    val subnetMaskBin: String = "",
    val wildcardMaskDec: String = "",
    val wildcardMaskBin: String = "",
    val ipClassAndScope: String = ""
)

data class VlsmAllocatedBlock(
    val index: Int,
    val neededHosts: Int,
    val allocatedHosts: Int,
    val cidr: Int,
    val subnetMask: String,
    val networkAddress: String,
    val firstHost: String,
    val lastHost: String,
    val broadcastAddress: String
)

object NetworkCalculators {

    fun parseIpv4ToLong(ip: String): Long? {
        val parts = ip.trim().split(".")
        if (parts.size != 4) return null
        var result = 0L
        for (part in parts) {
            val value = part.toIntOrNull() ?: return null
            if (value !in 0..255) return null
            result = (result shl 8) or value.toLong()
        }
        return result and 0xFFFFFFFFL
    }

    fun longToIpv4(value: Long): String {
        val v = value and 0xFFFFFFFFL
        return "${(v ushr 24) and 0xFF}.${(v ushr 16) and 0xFF}.${(v ushr 8) and 0xFF}.${v and 0xFF}"
    }

    fun longToBinaryDotted(value: Long): String {
        val v = value and 0xFFFFFFFFL
        return (3 downTo 0).joinToString(".") { shift ->
            val octet = ((v ushr (shift * 8)) and 0xFF).toInt()
            octet.toString(2).padStart(8, '0')
        }
    }

    fun cidrToMaskLong(cidr: Int): Long {
        val safeCidr = cidr.coerceIn(0, 32)
        return if (safeCidr == 0) 0L else (0xFFFFFFFFL shl (32 - safeCidr)) and 0xFFFFFFFFL
    }

    fun calculateSubnet(ip: String, cidr: Int, lang: String = "fr"): SubnetCalculationResult {
        val ipLong = parseIpv4ToLong(ip) ?: return SubnetCalculationResult(isValid = false)
        val safeCidr = cidr.coerceIn(1, 32)
        val maskLong = cidrToMaskLong(safeCidr)
        val wildcardLong = maskLong.inv() and 0xFFFFFFFFL
        val networkLong = ipLong and maskLong
        val broadcastLong = networkLong or wildcardLong

        val firstHostLong: Long
        val lastHostLong: Long
        val usableHosts: Long

        when (safeCidr) {
            32 -> {
                firstHostLong = networkLong
                lastHostLong = networkLong
                usableHosts = 1L
            }
            31 -> {
                firstHostLong = networkLong
                lastHostLong = broadcastLong
                usableHosts = 2L
            }
            else -> {
                firstHostLong = networkLong + 1L
                lastHostLong = broadcastLong - 1L
                usableHosts = (1L shl (32 - safeCidr)) - 2L
            }
        }

        val firstOctet = ((ipLong ushr 24) and 0xFF).toInt()
        val secondOctet = ((ipLong ushr 16) and 0xFF).toInt()
        val ipClass = when (firstOctet) {
            in 1..126 -> "Class A"
            127 -> "Loopback (127.0.0.0/8)"
            in 128..191 -> "Class B"
            in 192..223 -> "Class C"
            in 224..239 -> "Class D (Multicast)"
            else -> "Class E"
        }
        val isPrivate = (firstOctet == 10) ||
            (firstOctet == 172 && secondOctet in 16..31) ||
            (firstOctet == 192 && secondOctet == 168)

        val scopeText = if (lang == "en") {
            if (isPrivate) "$ipClass • Private (RFC 1918)" else "$ipClass • Public"
        } else {
            if (isPrivate) "$ipClass • Privée (RFC 1918)" else "$ipClass • Publique"
        }

        return SubnetCalculationResult(
            isValid = true,
            ipInput = ip.trim(),
            cidr = safeCidr,
            networkAddress = longToIpv4(networkLong),
            broadcastAddress = longToIpv4(broadcastLong),
            firstHost = longToIpv4(firstHostLong),
            lastHost = longToIpv4(lastHostLong),
            usableHosts = usableHosts,
            subnetMaskDec = longToIpv4(maskLong),
            subnetMaskBin = longToBinaryDotted(maskLong),
            wildcardMaskDec = longToIpv4(wildcardLong),
            wildcardMaskBin = longToBinaryDotted(wildcardLong),
            ipClassAndScope = scopeText
        )
    }

    fun calculateVlsm(
        baseIp: String,
        baseCidr: Int,
        hostsNeeds: List<Int>
    ): Pair<Boolean, List<VlsmAllocatedBlock>> {
        val ipLong = parseIpv4ToLong(baseIp) ?: return false to emptyList()
        val safeBaseCidr = baseCidr.coerceIn(8, 30)
        val baseMask = cidrToMaskLong(safeBaseCidr)
        val baseNetwork = ipLong and baseMask
        val baseBroadcast = baseNetwork or (baseMask.inv() and 0xFFFFFFFFL)

        val sortedNeeds = hostsNeeds.filter { it > 0 }.sortedDescending()
        if (sortedNeeds.isEmpty()) return false to emptyList()

        val blocks = mutableListOf<VlsmAllocatedBlock>()
        var currentAddress = baseNetwork

        for ((idx, needed) in sortedNeeds.withIndex()) {
            var hostBits = 2
            while ((1 shl hostBits) - 2 < needed && hostBits < 24) {
                hostBits++
            }
            val subCidr = 32 - hostBits
            val blockSize = 1L shl hostBits
            val subBroadcast = currentAddress + blockSize - 1L
            if (subBroadcast > baseBroadcast) {
                return false to blocks
            }
            val subMaskLong = cidrToMaskLong(subCidr)
            blocks.add(
                VlsmAllocatedBlock(
                    index = idx + 1,
                    neededHosts = needed,
                    allocatedHosts = (blockSize - 2L).toInt(),
                    cidr = subCidr,
                    subnetMask = longToIpv4(subMaskLong),
                    networkAddress = longToIpv4(currentAddress),
                    firstHost = longToIpv4(currentAddress + 1L),
                    lastHost = longToIpv4(subBroadcast - 1L),
                    broadcastAddress = longToIpv4(subBroadcast)
                )
            )
            currentAddress = subBroadcast + 1L
        }
        return true to blocks
    }

    fun executeCiscoCliCommand(
        rawCommand: String,
        hostname: String,
        mode: String, // "USER", "PRIV", "CONFIG"
        lang: String
    ): Triple<String, String, String> {
        val cmd = rawCommand.trim()
        val lower = cmd.lowercase(Locale.ROOT)
        if (cmd.isEmpty()) return Triple("", hostname, mode)

        return when {
            lower == "enable" || lower == "en" -> {
                Triple("", hostname, "PRIV")
            }
            lower == "disable" -> {
                Triple("", hostname, "USER")
            }
            lower == "configure terminal" || lower == "conf t" -> {
                if (mode == "USER") {
                    val err = if (lang == "en") "% Type 'enable' first to enter privileged EXEC mode."
                    else "% Tapez d'abord 'enable' pour passer en mode privilégié (#)."
                    Triple(err, hostname, mode)
                } else {
                    val msg = "Enter configuration commands, one per line. End with CNTL/Z."
                    Triple(msg, hostname, "CONFIG")
                }
            }
            lower == "exit" || lower == "end" -> {
                val nextMode = if (mode == "CONFIG") "PRIV" else "USER"
                Triple("", hostname, nextMode)
            }
            lower.startsWith("hostname ") && mode == "CONFIG" -> {
                val newHost = cmd.substringAfter(" ").trim().ifEmpty { hostname }
                Triple("", newHost, mode)
            }
            lower == "help" || lower == "?" -> {
                val helpOut = """
                    Available Cisco IOS Commands:
                      enable                       Enter privileged EXEC mode (#)
                      configure terminal (conf t)  Enter global configuration mode
                      hostname <name>              Change router/switch hostname
                      show ip interface brief      Display interface IP status table
                      show ip route                Display Layer 3 routing table
                      show vlan brief              Display Layer 2 VLAN database
                      show mac address-table       Display Switch CAM table
                      show version                 Display IOS XE hardware/software info
                      ping <ip>                    Send 5 ICMP Echo probes
                      exit / end                   Leave current mode
                """.trimIndent()
                Triple(helpOut, hostname, mode)
            }
            lower.startsWith("show ip int") || lower == "sh ip int br" -> {
                val table = """
                    Interface              IP-Address      OK? Method Status                Protocol
                    GigabitEthernet0/0     192.168.1.1     YES NVRAM  up                    up
                    GigabitEthernet0/1     10.0.0.1        YES NVRAM  up                    up
                    GigabitEthernet0/2     172.16.10.1     YES manual up                    up
                    Vlan10                 192.168.10.1    YES NVRAM  up                    up
                    Vlan20                 192.168.20.1    YES NVRAM  up                    up
                """.trimIndent()
                Triple(table, hostname, mode)
            }
            lower.startsWith("show ip route") || lower == "sh ip route" -> {
                val routes = """
                    Codes: L - local, C - connected, S - static, R - RIP, O - OSPF, D - EIGRP, B - BGP
                    Gateway of last resort is 203.0.113.1 to network 0.0.0.0

                    S*    0.0.0.0/0 [1/0] via 203.0.113.1
                    C     10.0.0.0/30 is directly connected, GigabitEthernet0/1
                    O     172.16.20.0/24 [110/20] via 10.0.0.2, 01:42:15, GigabitEthernet0/1
                    C     192.168.1.0/24 is directly connected, GigabitEthernet0/0
                    D     192.168.50.0/24 [90/2816] via 10.0.0.2, 00:54:10, GigabitEthernet0/1
                """.trimIndent()
                Triple(routes, hostname, mode)
            }
            lower.startsWith("show vlan") || lower == "sh vlan br" -> {
                val vlans = """
                    VLAN Name                             Status    Ports
                    ---- -------------------------------- --------- -------------------------------
                    1    default                          active    Gi0/3, Gi0/4
                    10   DATA_USERS                       active    Fa0/1, Fa0/2, Fa0/3, Fa0/4
                    20   VOICE_VOIP                       active    Fa0/5, Fa0/6
                    99   NATIVE_MGMT                      active    Gi0/1, Gi0/2
                """.trimIndent()
                Triple(vlans, hostname, mode)
            }
            lower.startsWith("show mac") || lower == "sh mac address-table" -> {
                val macs = """
                              Mac Address Table
                    -------------------------------------------
                    Vlan    Mac Address       Type        Ports
                    ----    -----------       --------    -----
                      10    0050.7966.6801    DYNAMIC     Fa0/1
                      10    0050.7966.6802    DYNAMIC     Fa0/2
                      20    00e0.b044.12a9    STATIC      Fa0/5
                      99    001b.d5a2.9900    DYNAMIC     Gi0/1
                """.trimIndent()
                Triple(macs, hostname, mode)
            }
            lower.startsWith("show version") || lower == "sh ver" -> {
                val ver = """
                    Cisco IOS XE Software, Version 17.09.04a (NetMaster Lab Simulator)
                    ROM: IOS-XE ROMMON
                    $hostname uptime is 14 days, 6 hours, 32 minutes
                    cisco ISR4331/K9 (1RU) processor with 4194304K bytes of physical memory.
                    3 Gigabit Ethernet interfaces
                    Configuration register is 0x2102
                """.trimIndent()
                Triple(ver, hostname, mode)
            }
            lower.startsWith("ping ") -> {
                val target = cmd.substringAfter(" ").trim().ifEmpty { "192.168.1.1" }
                val pingOut = """
                    Type escape sequence to abort.
                    Sending 5, 100-byte ICMP Echos to $target, timeout is 2 seconds:
                    !!!!!
                    Success rate is 100 percent (5/5), round-trip min/avg/max = 1/2/4 ms
                """.trimIndent()
                Triple(pingOut, hostname, mode)
            }
            else -> {
                val ack = if (mode == "CONFIG") {
                    "[OK] Configuration command applied: $cmd"
                } else {
                    "% Unknown or incomplete command. Type 'help' or '?' for supported IOS commands."
                }
                Triple(ack, hostname, mode)
            }
        }
    }
}
