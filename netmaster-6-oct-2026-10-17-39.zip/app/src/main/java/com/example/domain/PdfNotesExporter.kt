package com.example.domain

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.example.data.local.LessonEntity
import java.io.File
import java.io.FileOutputStream

object PdfNotesExporter {

    fun exportNotesAndBookmarksToPdf(
        context: Context,
        lessons: List<LessonEntity>,
        lang: String
    ): String? {
        val items = lessons.filter { it.isBookmarked || it.personalNote.isNotBlank() }
        if (items.isEmpty()) return null

        val document = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842

        val titlePaint = Paint().apply {
            color = Color.rgb(10, 132, 255)
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val subtitlePaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val bodyPaint = Paint().apply {
            color = Color.rgb(51, 65, 85)
            textSize = 10.5f
            isAntiAlias = true
        }

        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = document.startPage(pageInfo)
        var canvas: Canvas = page.canvas
        var y = 48f

        val headerTitle = if (lang == "en") "NetMaster — Personal Study Notes & Bookmarks"
        else "NetMaster — Notes Personnelles & Leçons Favorites"
        canvas.drawText(headerTitle, 40f, y, titlePaint)
        y += 28f

        for (lesson in items) {
            if (y > pageHeight - 120f) {
                document.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                page = document.startPage(pageInfo)
                canvas = page.canvas
                y = 48f
            }

            canvas.drawText("Module ${lesson.moduleId} — ${lesson.getTitle(lang)}", 40f, y, subtitlePaint)
            y += 18f

            if (lesson.personalNote.isNotBlank()) {
                val notePrefix = if (lang == "en") "Personal Note: " else "Note : "
                val noteLines = (notePrefix + lesson.personalNote).chunked(82)
                for (line in noteLines) {
                    canvas.drawText(line, 48f, y, bodyPaint)
                    y += 15f
                }
            }

            val summaryLines = lesson.getContent(lang)
                .lines()
                .filter { it.isNotBlank() }
                .take(4)
            for (rawLine in summaryLines) {
                for (chunk in rawLine.chunked(85)) {
                    if (y > pageHeight - 60f) break
                    canvas.drawText(chunk, 48f, y, bodyPaint)
                    y += 14f
                }
            }
            y += 16f
        }

        document.finishPage(page)

        val fileName = "NetMaster_Notes_${System.currentTimeMillis() / 1000}.pdf"
        val outFile = File(context.filesDir, fileName)
        return try {
            FileOutputStream(outFile).use { out ->
                document.writeTo(out)
            }
            document.close()
            outFile.name
        } catch (e: Exception) {
            document.close()
            null
        }
    }
}
